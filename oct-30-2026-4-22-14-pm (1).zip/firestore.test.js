const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write watchlist or price_alerts", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("watchlist").doc("AAPL").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("price_alerts").doc("alert_1").get()
  );
});

test("Authenticated user can create, read, update, list, and delete own watchlist stock", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const docRef = aliceDb.collection("users").doc(ALICE_UID).collection("watchlist").doc("AAPL");

  await assertSucceeds(
    docRef.set({
      userId: ALICE_UID,
      symbol: "AAPL",
      companyName: "Apple Inc.",
      arabicName: "شركة أبل",
      sector: "التكنولوجيا",
      notes: "مراقبة نتائج الربع القادم",
      targetPrice: 245.0,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(docRef.get());
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("watchlist")
      .where("userId", "==", ALICE_UID)
      .get()
  );

  await assertSucceeds(
    docRef.update({
      notes: "تحديث السعر المستهدف",
      targetPrice: 250.0,
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(docRef.delete());
});

test("Authenticated user can create, query, trigger, and delete custom price alerts", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const alertRef = aliceDb.collection("users").doc(ALICE_UID).collection("price_alerts").doc("alert_nvda_1");

  await assertSucceeds(
    alertRef.set({
      userId: ALICE_UID,
      symbol: "NVDA",
      companyName: "NVIDIA Corporation",
      arabicName: "إنفيديا",
      targetPrice: 150.0,
      condition: "ABOVE",
      note: "تنبيه اختراق مقاومة 150 دولار",
      isEnabled: true,
      isTriggered: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("price_alerts")
      .where("userId", "==", ALICE_UID)
      .get()
  );

  await assertSucceeds(
    alertRef.update({
      isTriggered: true,
      isEnabled: false,
      triggeredPrice: 151.25,
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(alertRef.delete());
});

test("Price alerts reject invalid condition, non-positive targetPrice, and cross-user access", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date();

  // Invalid condition enum
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("price_alerts").doc("bad_cond").set({
      userId: ALICE_UID,
      symbol: "AAPL",
      companyName: "Apple Inc.",
      targetPrice: 230.0,
      condition: "EQUAL_INVALID",
      isEnabled: true,
      isTriggered: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Non-positive targetPrice
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("price_alerts").doc("bad_price").set({
      userId: ALICE_UID,
      symbol: "AAPL",
      companyName: "Apple Inc.",
      targetPrice: 0,
      condition: "ABOVE",
      isEnabled: true,
      isTriggered: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Seed Bob's alert and ensure Alice cannot read it
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection("users")
      .doc(BOB_UID)
      .collection("price_alerts")
      .doc("bob_alert")
      .set({
        userId: BOB_UID,
        symbol: "TSLA",
        companyName: "Tesla Inc.",
        targetPrice: 260.0,
        condition: "BELOW",
        isEnabled: true,
        isTriggered: false,
        createdAt: now,
        updatedAt: now,
      });
  });

  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("price_alerts").doc("bob_alert").get()
  );
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("price_alerts").doc("bob_alert").get()
  );
});
