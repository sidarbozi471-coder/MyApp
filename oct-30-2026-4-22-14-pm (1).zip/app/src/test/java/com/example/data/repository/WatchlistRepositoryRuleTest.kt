package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.PriceAlert
import com.example.data.model.SavedNewsAnalysis
import com.example.data.model.WatchlistStock
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class WatchlistRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun addAndObserveWatchlistStock_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = WatchlistRepository(firestore)

        val stock = WatchlistStock(
            symbol = "NVDA",
            companyName = "NVIDIA Corporation",
            arabicName = "إنفيديا",
            sector = "أشباه الموصلات",
            notes = "سهم قيادي في الذكاء الاصطناعي",
            targetPrice = 160.0
        )

        val addResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addOrUpdateWatchlistStock(stock)
        }
        assertTrue("Expected addOrUpdateWatchlistStock to succeed", addResult.isSuccess)

        val emittedList = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeWatchlist(uid).first { list -> list.any { it.symbol == "NVDA" } }
        }
        assertTrue(emittedList.any { it.symbol == "NVDA" && it.companyName == "NVIDIA Corporation" })
    }

    @Test
    fun createObserveAndTriggerPriceAlert_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = WatchlistRepository(firestore)
        val alertId = "alert_nvda_${UUID.randomUUID().toString().replace("-", "").take(10)}"

        val alert = PriceAlert(
            id = alertId,
            symbol = "NVDA",
            companyName = "NVIDIA Corporation",
            arabicName = "إنفيديا",
            targetPrice = 155.0,
            condition = "ABOVE",
            note = "تنبيه اختراق مقاومة 155"
        )

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createPriceAlert(alert)
        }
        assertTrue("Expected createPriceAlert to succeed", createResult.isSuccess)

        val emittedAlerts = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observePriceAlerts(uid).first { list -> list.any { it.id == alertId } }
        }
        val createdAlert = emittedAlerts.first { it.id == alertId }
        assertEquals(155.0, createdAlert.targetPrice, 0.001)
        assertTrue(createdAlert.isEnabled && !createdAlert.isTriggered)

        val triggerResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.markPriceAlertTriggered(alertId, 156.40)
        }
        assertTrue("Expected markPriceAlertTriggered to succeed", triggerResult.isSuccess)

        val updatedAlerts = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observePriceAlerts(uid).first { list ->
                list.any { it.id == alertId && it.isTriggered }
            }
        }
        val triggeredAlert = updatedAlerts.first { it.id == alertId }
        assertTrue(triggeredAlert.isTriggered)
        assertEquals(156.40, triggeredAlert.triggeredPrice ?: 0.0, 0.01)
    }

    @Test
    fun saveAndObserveNewsAnalysis_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = WatchlistRepository(firestore)
        val uniqueId = "analysis_${UUID.randomUUID().toString().replace("-", "").take(16)}"

        val analysis = SavedNewsAnalysis(
            id = uniqueId,
            symbol = "AAPL",
            headline = "Apple announces quarterly financial results",
            source = "Reuters",
            publishedAtMillis = 1730200000000L,
            articleUrl = "https://www.reuters.com/technology/apple",
            sentiment = "POSITIVE",
            confidenceScore = 88L,
            arabicSummary = "أعلنت شركة أبل عن نتائج مالية فصلية قوية.",
            marketImpact = "تأثير إيجابي محتمل نتيجة نمو إيرادات الخدمات."
        )

        val saveResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveNewsAnalysis(analysis)
        }
        assertTrue("Expected saveNewsAnalysis to succeed", saveResult.isSuccess)

        val analyses = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSavedAnalyses(uid).first { list -> list.any { it.id == uniqueId } }
        }
        assertTrue(analyses.any { it.id == uniqueId && it.sentiment == "POSITIVE" })
    }

    @Test
    fun getWatchlistAndPriceAlert_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = WatchlistRepository(firestore)
        val alertId = "alert_msft_${UUID.randomUUID().toString().replace("-", "").take(10)}"

        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.addOrUpdateWatchlistStock(
                WatchlistStock(
                    symbol = "MSFT",
                    companyName = "Microsoft Corporation"
                )
            ).getOrThrow()
            aliceRepo.createPriceAlert(
                PriceAlert(
                    id = alertId,
                    symbol = "MSFT",
                    companyName = "Microsoft Corporation",
                    targetPrice = 450.0,
                    condition = "ABOVE"
                )
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = WatchlistRepository(firestore)
        val crossWatchlistResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getWatchlistStockById(aliceUid, "MSFT")
        }
        assertTrue("Expected cross-user watchlist read to fail", crossWatchlistResult.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            crossWatchlistResult.exceptionOrNull()?.unwrapFirestoreException()?.code
        )

        val crossAlertResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getPriceAlertById(aliceUid, alertId)
        }
        assertTrue("Expected cross-user price_alert read to fail", crossAlertResult.isFailure)
        assertEquals(
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            crossAlertResult.exceptionOrNull()?.unwrapFirestoreException()?.code
        )
    }

    @Test
    fun observeWatchlist_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = WatchlistRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeWatchlist(aliceUid).first()
            }
            fail("Expected observeWatchlist to throw exception when unauthenticated")
        } catch (e: Exception) {
            val firestoreEx = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreEx?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@stockpulse.test"
        const val BOB_EMAIL = "bob@stockpulse.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3500L
    }
}
