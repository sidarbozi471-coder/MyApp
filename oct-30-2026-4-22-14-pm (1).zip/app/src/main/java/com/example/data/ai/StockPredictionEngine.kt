package com.example.data.ai

import android.util.Log
import com.example.data.model.CompanyNewsItem
import com.example.data.model.HistoricalCandle
import com.example.data.model.IndicatorSignalDirection
import com.example.data.model.NewsPredictionSection
import com.example.data.model.NewsSentiment
import com.example.data.model.OutOfSampleBacktestReport
import com.example.data.model.PredictionHorizon
import com.example.data.model.StockPredictionReport
import com.example.data.model.StockQuote
import com.example.data.model.TechnicalIndicatorFactor
import com.example.data.model.TechnicalPredictionSection
import com.example.data.model.UsStockCatalog
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sqrt

private const val TAG = "StockPredictionEngine"

class InsufficientHistoricalDataException(
    val availableCandles: Int,
    val requiredCandles: Int,
    override val message: String
) : Exception(message)

class StockPredictionEngine {

    companion object {
        const val MIN_REQUIRED_CANDLES = 55
    }

    private val predictionAiSchema = Schema.obj(
        properties = mapOf(
            "newsSentiment" to Schema.enumeration(
                values = listOf("POSITIVE", "NEGATIVE", "NEUTRAL"),
                description = "Overall sentiment of the provided real company and economic news"
            ),
            "newsBullishScore" to Schema.integer(
                description = "News bullish score from 15 to 85 based strictly on the provided news headlines and summaries (50 if neutral)"
            ),
            "executiveVerdictArabic" to Schema.string(
                description = "Concise 2-sentence Arabic executive summary of the stock outlook combining the quantitative indicators and news without claiming certainty"
            ),
            "technicalSummaryArabic" to Schema.string(
                description = "Clear Arabic explanation (2 sentences) of what RSI, MACD, Moving Averages, and Volume indicate for the selected time horizon"
            ),
            "newsSummaryArabic" to Schema.string(
                description = "Clear Arabic summary (2 sentences) of the company and economic news impact, separated from technical analysis"
            ),
            "technicalReasonsArabic" to Schema.array(
                items = Schema.string(description = "Technical reason in Arabic citing exact indicator values"),
                description = "3 specific Arabic bullet points explaining the technical indicators (RSI, MACD, SMA, Volume)"
            ),
            "newsReasonsArabic" to Schema.array(
                items = Schema.string(description = "News/fundamental reason in Arabic citing real news sources"),
                description = "2 to 3 specific Arabic bullet points explaining the company and economic news impact"
            ),
            "combinedPredictionReasonsArabic" to Schema.array(
                items = Schema.string(description = "Key reason for the final probability forecast in Arabic"),
                description = "3 to 4 concise Arabic reasons explaining why the bullish/bearish probabilities were reached"
            )
        )
    )

    private val predictionGenerativeModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = predictionAiSchema
            }
        )
    }

    suspend fun generatePrediction(
        symbol: String,
        quote: StockQuote?,
        candles: List<HistoricalCandle>,
        companyNews: List<CompanyNewsItem>,
        horizon: PredictionHorizon
    ): Result<StockPredictionReport> {
        val cleanSymbol = symbol.trim().uppercase()
        if (candles.size < MIN_REQUIRED_CANDLES) {
            return Result.failure(
                InsufficientHistoricalDataException(
                    availableCandles = candles.size,
                    requiredCandles = MIN_REQUIRED_CANDLES,
                    message = "البيانات التاريخية المتاحة للسهم $cleanSymbol (${candles.size} جلسة تداول) غير كافية لحساب مؤشرات RSI و MACD والمتوسطات المتحركة (SMA 50) واختبار دقة النموذج خارج العينة (الحد الأدنى المطلوب: $MIN_REQUIRED_CANDLES جلسة)."
                )
            )
        }

        return try {
            val sortedCandles = candles.sortedBy { it.timestampMillis }
            val latestCandle = sortedCandles.last()
            val livePrice = quote?.currentPrice?.takeIf { it > 0.0 } ?: latestCandle.close
            val prevClose = quote?.previousClose?.takeIf { it > 0.0 }
                ?: sortedCandles.getOrNull(sortedCandles.size - 2)?.close
                ?: livePrice
            val priceChangePercent = quote?.changePercent
                ?: if (prevClose > 0.0) ((livePrice - prevClose) / prevClose) * 100.0 else 0.0

            val curated = UsStockCatalog.findBySymbol(cleanSymbol)
            val companyName = quote?.companyName ?: curated?.companyName ?: cleanSymbol
            val arabicName = quote?.arabicName ?: curated?.arabicName ?: cleanSymbol
            val sector = quote?.sector ?: curated?.sector ?: "السوق الأمريكي"
            val dataSource = quote?.dataSource ?: "Yahoo Finance Historical & Live"

            // 1. Run Out-of-Sample Walk-Forward Backtest on unseen historical segments
            val backtestReport = runOutOfSampleBacktest(sortedCandles, horizon)

            // 2. Compute Current Quantitative Technical Indicators
            val baseTechSection = computeCurrentTechnicalSection(
                candles = sortedCandles,
                livePrice = livePrice,
                liveVolume = quote?.volume?.takeIf { it > 0L } ?: latestCandle.volume,
                horizon = horizon
            )

            // 3. Compute deterministic baseline News Analysis from real fetched articles
            val baseNewsSection = computeBaselineNewsSection(
                symbol = cleanSymbol,
                companyNews = companyNews
            )

            // 4. Enhance with Gemini AI synthesis (strictly grounded in the real numbers & news)
            val aiEnhancement = requestGeminiPredictionSynthesis(
                symbol = cleanSymbol,
                companyName = companyName,
                arabicName = arabicName,
                horizon = horizon,
                livePrice = livePrice,
                priceChangePercent = priceChangePercent,
                techSection = baseTechSection,
                baseNewsSection = baseNewsSection,
                backtestReport = backtestReport
            )

            val finalNewsScore = aiEnhancement?.newsBullishScore?.toDouble()
                ?: baseNewsSection.newsBullishScore
            val finalNewsSentiment = aiEnhancement?.newsSentiment
                ?: baseNewsSection.overallNewsSentiment

            val finalTechnicalSection = if (aiEnhancement != null) {
                baseTechSection.copy(
                    technicalSummaryArabic = aiEnhancement.technicalSummaryArabic.ifBlank {
                        baseTechSection.technicalSummaryArabic
                    },
                    technicalReasons = aiEnhancement.technicalReasonsArabic.ifEmpty {
                        baseTechSection.technicalReasons
                    }
                )
            } else {
                baseTechSection
            }

            val finalNewsSection = baseNewsSection.copy(
                newsBullishScore = finalNewsScore,
                overallNewsSentiment = finalNewsSentiment,
                companyAndEconomicNewsSummaryArabic = aiEnhancement?.newsSummaryArabic?.takeIf { it.isNotBlank() }
                    ?: baseNewsSection.companyAndEconomicNewsSummaryArabic,
                newsReasons = aiEnhancement?.newsReasonsArabic?.takeIf { it.isNotEmpty() }
                    ?: baseNewsSection.newsReasons
            )

            // 5. Calculate Deterministic Calibrated Probabilities (Sum == 100%)
            val hasVerifiedNews = companyNews.isNotEmpty()
            val rawCombinedScore = if (hasVerifiedNews) {
                (finalTechnicalSection.technicalBullishScore * 0.68) + (finalNewsScore * 0.32)
            } else {
                finalTechnicalSection.technicalBullishScore
            }

            // Calibrate conviction using out-of-sample historical accuracy (shrink towards 50% if backtest accuracy is low)
            val accuracyShrinkageFactor = ((backtestReport.directionalAccuracyPercent - 45.0) / 35.0)
                .coerceIn(0.45, 1.0)
            val calibratedBullish = 50.0 + (rawCombinedScore - 50.0) * accuracyShrinkageFactor
            val bullishProb = calibratedBullish.roundToInt().coerceIn(12, 88)
            val bearishProb = 100 - bullishProb // Strictly guarantees bullishProb + bearishProb == 100%

            // 6. Calculate Deterministic Confidence Level
            val indicatorAgreement = computeIndicatorAgreementScore(finalTechnicalSection.influentialIndicators)
            val dataRichnessScore = ((sortedCandles.size.coerceAtMost(250).toDouble() / 250.0) * 100.0)
            val newsCoverageScore = if (companyNews.size >= 3) 85.0 else if (companyNews.isNotEmpty()) 65.0 else 45.0
            val confidenceScore = (
                (backtestReport.directionalAccuracyPercent * 0.42) +
                    (indicatorAgreement * 0.33) +
                    (dataRichnessScore * 0.15) +
                    (newsCoverageScore * 0.10)
                ).roundToInt().coerceIn(35, 92)

            val confidenceLabel = when {
                confidenceScore >= 75 -> "مرتفع ($confidenceScore%)"
                confidenceScore >= 60 -> "متوسط إلى مرتفع ($confidenceScore%)"
                confidenceScore >= 48 -> "متوسط ($confidenceScore%)"
                else -> "حذر - تذبذب سعري مرتفع ($confidenceScore%)"
            }

            // 7. Expected Horizon Price Range (1 standard deviation move adjusted by directional bias)
            val dailyVol = (finalTechnicalSection.annualizedVolatilityPercent / 100.0) / sqrt(252.0)
            val horizonStdMove = dailyVol * sqrt(horizon.tradingDaysLookahead.toDouble())
                .coerceIn(0.012, 0.25)
            val directionalSkew = ((bullishProb - 50) / 100.0) * horizonStdMove * 0.55
            val expectedLow = (livePrice * (1.0 - horizonStdMove + directionalSkew)).coerceAtLeast(0.01)
            val expectedHigh = (livePrice * (1.0 + horizonStdMove + directionalSkew)).coerceAtLeast(expectedLow)

            val synthesizedReasons = aiEnhancement?.combinedReasonsArabic?.takeIf { it.isNotEmpty() }
                ?: (finalTechnicalSection.technicalReasons.take(2) + finalNewsSection.newsReasons.take(2))

            val executiveVerdict = aiEnhancement?.executiveVerdictArabic?.takeIf { it.isNotBlank() }
                ?: buildFallbackExecutiveVerdict(
                    arabicName = arabicName,
                    symbol = cleanSymbol,
                    horizon = horizon,
                    bullishProb = bullishProb,
                    bearishProb = bearishProb,
                    backtestAccuracy = backtestReport.directionalAccuracyPercent
                )

            Result.success(
                StockPredictionReport(
                    symbol = cleanSymbol,
                    companyName = companyName,
                    arabicName = arabicName,
                    sector = sector,
                    horizon = horizon,
                    currentPrice = livePrice,
                    priceChangePercent = priceChangePercent,
                    dataSource = dataSource,
                    historicalCandlesCount = sortedCandles.size,
                    bullishProbabilityPercent = bullishProb,
                    bearishProbabilityPercent = bearishProb,
                    confidenceScorePercent = confidenceScore,
                    confidenceLabelArabic = confidenceLabel,
                    expectedPriceRangeLow = expectedLow,
                    expectedPriceRangeHigh = expectedHigh,
                    technicalSection = finalTechnicalSection,
                    newsSection = finalNewsSection,
                    backtestReport = backtestReport,
                    aiSynthesizedReasons = synthesizedReasons,
                    aiExecutiveVerdictArabic = executiveVerdict,
                    isAiEnhanced = aiEnhancement != null,
                    generatedAtMillis = System.currentTimeMillis()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to generate stock prediction for $cleanSymbol", e)
            Result.failure(e)
        }
    }

    /**
     * Walk-Forward Out-of-Sample Backtester:
     * Uses only past data [0..t] to compute technical indicators at index t,
     * and tests the predicted direction against the unseen future close at [t + lookahead]
     * on the holdout test split (last 35% of historical candles that never entered weight calibration).
     */
    private fun runOutOfSampleBacktest(
        candles: List<HistoricalCandle>,
        horizon: PredictionHorizon
    ): OutOfSampleBacktestReport {
        val lookahead = horizon.tradingDaysLookahead
        val minWarmup = 50
        val maxEvaluatableIndex = candles.size - 1 - lookahead
        val splitIndex = maxOf(minWarmup, (candles.size * 0.62).toInt())

        val startTestIndex = if (splitIndex <= maxEvaluatableIndex - 5) {
            splitIndex
        } else {
            minWarmup
        }

        var testCount = 0
        var correctCount = 0
        var totalAbsRealizedMovePct = 0.0

        for (t in startTestIndex..maxEvaluatableIndex) {
            val scoreAtT = computeRawTechnicalScoreAtIndex(candles, t, horizon)
            val predictedUp = scoreAtT >= 50.0
            val priceAtT = candles[t].close
            val futurePrice = candles[t + lookahead].close
            if (priceAtT <= 0.0) continue

            val realizedReturnPct = ((futurePrice - priceAtT) / priceAtT) * 100.0
            val actualUp = realizedReturnPct >= 0.0

            testCount++
            if (predictedUp == actualUp) {
                correctCount++
            }
            totalAbsRealizedMovePct += abs(realizedReturnPct)
        }

        val accuracyPct = if (testCount > 0) {
            (correctCount.toDouble() / testCount.toDouble()) * 100.0
        } else {
            50.0
        }
        val avgMovePct = if (testCount > 0) {
            totalAbsRealizedMovePct / testCount.toDouble()
        } else {
            0.0
        }

        return OutOfSampleBacktestReport(
            trainingCandlesCount = startTestIndex,
            outOfSampleTestCount = testCount,
            correctPredictionsCount = correctCount,
            directionalAccuracyPercent = accuracyPct,
            avgRealizedMovePercent = avgMovePct,
            methodologyNoteArabic = "تم اختبار النموذج بطريقة Walk-Forward خارج العينة على $testCount نافذة زمنية تاريخية حقيقية لم تدخل في معايرة المؤشرات ($startTestIndex جلسة سابقة للمعايرة)، ومقارنة كل توقع بالاتجاه الفعلي المحقق بعد ${horizon.arabicLabel}."
        )
    }

    private fun computeRawTechnicalScoreAtIndex(
        candles: List<HistoricalCandle>,
        endIndex: Int,
        horizon: PredictionHorizon
    ): Double {
        val subList = candles.subList(0, endIndex + 1)
        val closes = subList.map { it.close }
        val latestClose = closes.last()

        val rsi14 = calculateRsi14(closes)
        val (_, _, macdHist) = calculateMacd(closes)
        val sma20 = calculateSma(closes, 20)
        val sma50 = calculateSma(closes, 50)
        val ema20 = calculateEma(closes, 20)

        val recentVolumes = subList.takeLast(20).map { it.volume.toDouble() }
        val avgVol20 = recentVolumes.average().coerceAtLeast(1.0)
        val currentVol = subList.last().volume.toDouble()
        val volRatio = (currentVol / avgVol20).coerceIn(0.2, 4.0)

        val prevClose = closes.getOrNull(closes.size - 2) ?: latestClose
        val lastDayUp = latestClose >= prevClose

        // 1. RSI Score (0..100)
        // RSI < 32 is oversold bounce potential (+), RSI 52..66 is healthy bullish momentum (+), RSI > 74 is overbought pullback risk (-)
        val rsiScore = when {
            rsi14 < 30.0 -> 68.0 + ((30.0 - rsi14) * 0.6).coerceAtMost(14.0)
            rsi14 in 30.0..45.0 -> 46.0 + ((rsi14 - 30.0) / 15.0) * 6.0
            rsi14 in 45.0..66.0 -> 52.0 + ((rsi14 - 45.0) / 21.0) * 18.0
            rsi14 in 66.0..75.0 -> 58.0 - ((rsi14 - 66.0) / 9.0) * 14.0
            else -> (38.0 - (rsi14 - 75.0) * 0.7).coerceAtLeast(20.0)
        }

        // 2. MACD Score (0..100)
        val normalizedHist = (macdHist / (latestClose * 0.012).coerceAtLeast(0.01)).coerceIn(-2.5, 2.5)
        val macdScore = (50.0 + normalizedHist * 14.0).coerceIn(18.0, 82.0)

        // 3. Moving Average Trend Score (SMA20, SMA50, EMA20)
        var maScore = 50.0
        if (latestClose > sma20) maScore += 10.0 else maScore -= 10.0
        if (latestClose > sma50) maScore += 10.0 else maScore -= 10.0
        if (sma20 > sma50) maScore += 8.0 else maScore -= 8.0
        if (latestClose > ema20) maScore += 5.0 else maScore -= 5.0
        maScore = maScore.coerceIn(15.0, 85.0)

        // 4. Volume & Price Momentum Score
        val volConfirmation = if (lastDayUp) {
            50.0 + ((volRatio - 1.0) * 16.0)
        } else {
            50.0 - ((volRatio - 1.0) * 16.0)
        }.coerceIn(22.0, 78.0)

        return when (horizon) {
            PredictionHorizon.HOURS_24 -> {
                (rsiScore * 0.30) + (macdScore * 0.30) + (maScore * 0.20) + (volConfirmation * 0.20)
            }
            PredictionHorizon.DAYS_7 -> {
                (rsiScore * 0.25) + (macdScore * 0.32) + (maScore * 0.28) + (volConfirmation * 0.15)
            }
            PredictionHorizon.DAYS_30 -> {
                (rsiScore * 0.18) + (macdScore * 0.28) + (maScore * 0.42) + (volConfirmation * 0.12)
            }
        }.coerceIn(15.0, 85.0)
    }

    private fun computeCurrentTechnicalSection(
        candles: List<HistoricalCandle>,
        livePrice: Double,
        liveVolume: Long,
        horizon: PredictionHorizon
    ): TechnicalPredictionSection {
        val closes = candles.dropLast(1).map { it.close } + livePrice
        val rsi14 = calculateRsi14(closes)
        val (macdLine, macdSignal, macdHistogram) = calculateMacd(closes)
        val sma20 = calculateSma(closes, 20)
        val sma50 = calculateSma(closes, 50)
        val ema20 = calculateEma(closes, 20)

        val avgVol20 = candles.takeLast(20).map { it.volume }.average().toLong().coerceAtLeast(1L)
        val volumeRatio = if (liveVolume > 0L) {
            liveVolume.toDouble() / avgVol20.toDouble()
        } else {
            candles.last().volume.toDouble() / avgVol20.toDouble()
        }

        val close5dAgo = closes.getOrElse((closes.size - 6).coerceAtLeast(0)) { livePrice }
        val close20dAgo = closes.getOrElse((closes.size - 21).coerceAtLeast(0)) { livePrice }
        val return5dPct = if (close5dAgo > 0.0) ((livePrice - close5dAgo) / close5dAgo) * 100.0 else 0.0
        val return20dPct = if (close20dAgo > 0.0) ((livePrice - close20dAgo) / close20dAgo) * 100.0 else 0.0

        val annualizedVolPct = calculateAnnualizedVolatilityPercent(closes)
        val techScore = computeRawTechnicalScoreAtIndex(candles, candles.size - 1, horizon)

        // Build Influential Indicators List
        val rsiSignal = when {
            rsi14 < 33.0 -> IndicatorSignalDirection.BULLISH
            rsi14 in 50.0..68.0 -> IndicatorSignalDirection.BULLISH
            rsi14 > 72.0 -> IndicatorSignalDirection.BEARISH
            rsi14 in 33.0..46.0 -> IndicatorSignalDirection.BEARISH
            else -> IndicatorSignalDirection.NEUTRAL
        }
        val rsiInterpretation = when {
            rsi14 > 70.0 -> "في منطقة تشبع شرائي (${String.format(Locale.US, "%.1f", rsi14)}) ما قد يزيد احتمالية جني الأرباح."
            rsi14 < 30.0 -> "في منطقة تشبع بيعي (${String.format(Locale.US, "%.1f", rsi14)}) ما يدعم احتمالية ارتداد فني صاعد."
            rsi14 >= 52.0 -> "زخم شرائي إيجابي متوازن (${String.format(Locale.US, "%.1f", rsi14)}) دون تشبع مفرط."
            else -> "زخم هادئ يميل للحياد أو الضغوط البيعية الطفيفة (${String.format(Locale.US, "%.1f", rsi14)})."
        }

        val macdSignalDir = when {
            macdHistogram > 0.0 && macdLine > macdSignal -> IndicatorSignalDirection.BULLISH
            macdHistogram < 0.0 && macdLine < macdSignal -> IndicatorSignalDirection.BEARISH
            else -> IndicatorSignalDirection.NEUTRAL
        }
        val macdInterpretation = if (macdHistogram >= 0.0) {
            "خط الماكد (${String.format(Locale.US, "%.2f", macdLine)}) أعلى من خط الإشارة (${String.format(Locale.US, "%.2f", macdSignal)}) بهيستوجرام إيجابي."
        } else {
            "خط الماكد (${String.format(Locale.US, "%.2f", macdLine)}) أدنى من خط الإشارة (${String.format(Locale.US, "%.2f", macdSignal)}) بهيستوجرام سلبي."
        }

        val maSignalDir = when {
            livePrice > sma20 && livePrice > sma50 -> IndicatorSignalDirection.BULLISH
            livePrice < sma20 && livePrice < sma50 -> IndicatorSignalDirection.BEARISH
            else -> IndicatorSignalDirection.NEUTRAL
        }
        val maInterpretation = buildString {
            append("السعر الحالي (${String.format(Locale.US, "$%.2f", livePrice)}) ")
            append(if (livePrice >= sma20) "يتداول أعلى من" else "يتداول أدنى من")
            append(" متوسط 20 يوم (${String.format(Locale.US, "$%.2f", sma20)}) ")
            append(if (livePrice >= sma50) "وأعلى من" else "وأدنى من")
            append(" متوسط 50 يوم (${String.format(Locale.US, "$%.2f", sma50)}).")
        }

        val volSignalDir = when {
            volumeRatio >= 1.15 && return5dPct >= 0.0 -> IndicatorSignalDirection.BULLISH
            volumeRatio >= 1.15 && return5dPct < 0.0 -> IndicatorSignalDirection.BEARISH
            else -> IndicatorSignalDirection.NEUTRAL
        }
        val volInterpretation = "حجم التداول يبلغ ${String.format(Locale.US, "%.2fx", volumeRatio)} مقارنة بمتوسط 20 جلسة، مع تغير سعري لـ 5 أيام بنسبة ${String.format(Locale.US, "%+.2f%%", return5dPct)}."

        val weights = when (horizon) {
            PredictionHorizon.HOURS_24 -> listOf(30, 30, 20, 20)
            PredictionHorizon.DAYS_7 -> listOf(25, 32, 28, 15)
            PredictionHorizon.DAYS_30 -> listOf(18, 28, 42, 12)
        }

        val indicators = listOf(
            TechnicalIndicatorFactor(
                code = "RSI",
                name = "مؤشر القوة النسبية RSI (14)",
                formattedValue = String.format(Locale.US, "%.1f", rsi14),
                signal = rsiSignal,
                impactWeightPercent = weights[0],
                arabicInterpretation = rsiInterpretation
            ),
            TechnicalIndicatorFactor(
                code = "MACD",
                name = "مؤشر الماكد MACD (12, 26, 9)",
                formattedValue = String.format(Locale.US, "Hist: %+.2f", macdHistogram),
                signal = macdSignalDir,
                impactWeightPercent = weights[1],
                arabicInterpretation = macdInterpretation
            ),
            TechnicalIndicatorFactor(
                code = "MA",
                name = "المتوسطات المتحركة (SMA 20 / SMA 50)",
                formattedValue = String.format(Locale.US, "$%.1f / $%.1f", sma20, sma50),
                signal = maSignalDir,
                impactWeightPercent = weights[2],
                arabicInterpretation = maInterpretation
            ),
            TechnicalIndicatorFactor(
                code = "VOLUME",
                name = "سيولة وحجم التداول (Volume Ratio)",
                formattedValue = String.format(Locale.US, "%.2fx المتوسط", volumeRatio),
                signal = volSignalDir,
                impactWeightPercent = weights[3],
                arabicInterpretation = volInterpretation
            )
        )

        val defaultReasons = listOf(
            rsiInterpretation,
            macdInterpretation,
            maInterpretation,
            volInterpretation
        )

        val summaryArabic = "بناءً على تحليل ${candles.size} جلسة تداول تاريخية لمدة ${horizon.arabicLabel}، يسجل المؤشر الفني الكمي ${String.format(Locale.US, "%.1f", techScore)} من 100 مع تذبذب سنوي تاريخي يبلغ ${String.format(Locale.US, "%.1f%%", annualizedVolPct)}."

        return TechnicalPredictionSection(
            rsi14 = rsi14,
            macdLine = macdLine,
            macdSignal = macdSignal,
            macdHistogram = macdHistogram,
            sma20 = sma20,
            sma50 = sma50,
            ema20 = ema20,
            currentVolume = if (liveVolume > 0L) liveVolume else candles.last().volume,
            avgVolume20 = avgVol20,
            volumeRatio = volumeRatio,
            return5dPercent = return5dPct,
            return20dPercent = return20dPct,
            annualizedVolatilityPercent = annualizedVolPct,
            technicalBullishScore = techScore,
            influentialIndicators = indicators,
            technicalReasons = defaultReasons,
            technicalSummaryArabic = summaryArabic
        )
    }

    private fun computeBaselineNewsSection(
        symbol: String,
        companyNews: List<CompanyNewsItem>
    ): NewsPredictionSection {
        val relevant = companyNews.sortedByDescending { it.publishedAtMillis }.take(8)
        if (relevant.isEmpty()) {
            return NewsPredictionSection(
                analyzedArticlesCount = 0,
                positiveArticlesCount = 0,
                negativeArticlesCount = 0,
                neutralArticlesCount = 0,
                newsBullishScore = 50.0,
                overallNewsSentiment = NewsSentiment.NEUTRAL,
                companyAndEconomicNewsSummaryArabic = "لا توجد أخبار منشورة حديثاً للسهم $symbol في المصادر الإخبارية اللحظية؛ لذلك يعتمد التوقع الحالي بشكل أساسي على المؤشرات الفنية وحركة السيولة.",
                newsReasons = listOf(
                    "لم ترد أخبار جوهرية جديدة للشركة في التغذية الإخبارية المباشرة، ما يجعل التأثير الإخباري محايداً (50%)."
                ),
                topReferencedHeadlines = emptyList()
            )
        }

        var pos = 0
        var neg = 0
        var neu = 0

        val positiveKeywords = listOf(
            "beat", "surge", "jump", "upgrade", "growth", "record", "profit", "bull",
            "gain", "rally", "partnership", "launch", "strong", "buy", "outperform", "ai"
        )
        val negativeKeywords = listOf(
            "miss", "drop", "fall", "downgrade", "loss", "lawsuit", "probe", "cut",
            "decline", "weak", "warn", "risk", "sell", "underperform", "tariff", "inflation"
        )

        relevant.forEach { item ->
            val existingSentiment = item.aiAnalysis?.sentiment
            if (existingSentiment != null) {
                when (existingSentiment) {
                    NewsSentiment.POSITIVE -> pos++
                    NewsSentiment.NEGATIVE -> neg++
                    NewsSentiment.NEUTRAL -> neu++
                }
            } else {
                val text = "${item.headline} ${item.summary}".lowercase(Locale.US)
                val posHits = positiveKeywords.count { text.contains(it) }
                val negHits = negativeKeywords.count { text.contains(it) }
                when {
                    posHits > negHits -> pos++
                    negHits > posHits -> neg++
                    else -> neu++
                }
            }
        }

        val total = relevant.size.coerceAtLeast(1)
        val netRatio = (pos - neg).toDouble() / total.toDouble()
        val score = (50.0 + netRatio * 28.0).coerceIn(20.0, 80.0)
        val overallSentiment = when {
            score >= 56.0 -> NewsSentiment.POSITIVE
            score <= 44.0 -> NewsSentiment.NEGATIVE
            else -> NewsSentiment.NEUTRAL
        }

        val reasons = relevant.take(3).map { article ->
            "المصدر (${article.source}): ${article.aiAnalysis?.arabicHeadline ?: article.headline}"
        }

        return NewsPredictionSection(
            analyzedArticlesCount = relevant.size,
            positiveArticlesCount = pos,
            negativeArticlesCount = neg,
            neutralArticlesCount = neu,
            newsBullishScore = score,
            overallNewsSentiment = overallSentiment,
            companyAndEconomicNewsSummaryArabic = "تم رصد وتحليل ${relevant.size} أخبار حقيقية للشركة والقطاع ($pos إيجابية، $neg سلبية، $neu محايدة) من المصادر المالية المعتمدة.",
            newsReasons = reasons,
            topReferencedHeadlines = relevant.take(4)
        )
    }

    private data class GeminiSynthesisOutput(
        val newsSentiment: NewsSentiment,
        val newsBullishScore: Int,
        val executiveVerdictArabic: String,
        val technicalSummaryArabic: String,
        val newsSummaryArabic: String,
        val technicalReasonsArabic: List<String>,
        val newsReasonsArabic: List<String>,
        val combinedReasonsArabic: List<String>
    )

    private suspend fun requestGeminiPredictionSynthesis(
        symbol: String,
        companyName: String,
        arabicName: String,
        horizon: PredictionHorizon,
        livePrice: Double,
        priceChangePercent: Double,
        techSection: TechnicalPredictionSection,
        baseNewsSection: NewsPredictionSection,
        backtestReport: OutOfSampleBacktestReport
    ): GeminiSynthesisOutput? {
        val prompt = buildString {
            appendLine("أنت محلل كمي ومالي محترف في وول ستريت.")
            appendLine("قم بتحليل بيانات السهم الحقيقية التالية لإعداد تقرير توقع اتجاه السهم لمدة (${horizon.arabicLabel}) بدقة وموضوعية تامة، مع الفصل الصارم بين التحليل الفني وتحليل الأخبار، وعدم اختلاق أي أسعار أو أخبار غير واردة أدناه:")
            appendLine()
            appendLine("السهم: $symbol ($companyName - $arabicName)")
            appendLine(String.format(Locale.US, "السعر الحالي: $%.2f (التغير اليومي: %+.2f%%)", livePrice, priceChangePercent))
            appendLine("المدة الزمنية للتوقع: ${horizon.arabicLabel} (${horizon.arabicSubtitle})")
            appendLine()
            appendLine("أولاً: المؤشرات الفنية الحقيقية المحسوبة من السلسلة التاريخية:")
            appendLine(String.format(Locale.US, "- RSI (14): %.2f", techSection.rsi14))
            appendLine(String.format(Locale.US, "- MACD (12,26,9): Line=%.2f, Signal=%.2f, Histogram=%+.2f", techSection.macdLine, techSection.macdSignal, techSection.macdHistogram))
            appendLine(String.format(Locale.US, "- المتوسط المتحرك البسيط SMA(20): $%.2f | SMA(50): $%.2f | EMA(20): $%.2f", techSection.sma20, techSection.sma50, techSection.ema20))
            appendLine(String.format(Locale.US, "- نسبة حجم التداول الحالي إلى متوسط 20 جلسة (Volume Ratio): %.2fx", techSection.volumeRatio))
            appendLine(String.format(Locale.US, "- العائد خلال 5 جلسات: %+.2f%% | العائد خلال 20 جلسة: %+.2f%% | التذبذب السنوي: %.1f%%", techSection.return5dPercent, techSection.return20dPercent, techSection.annualizedVolatilityPercent))
            appendLine(String.format(Locale.US, "- دقة النموذج التاريخية خارج العينة (Out-of-Sample Accuracy): %.1f%% عبر %d اختبار تاريخي", backtestReport.directionalAccuracyPercent, backtestReport.outOfSampleTestCount))
            appendLine()
            appendLine("ثانياً: أخبار الشركة والأخبار الاقتصادية الحقيقية المرصودة:")
            if (baseNewsSection.topReferencedHeadlines.isEmpty()) {
                appendLine("- لا توجد أخبار منشورة حديثاً في التغذية الحالية.")
            } else {
                baseNewsSection.topReferencedHeadlines.forEachIndexed { idx, item ->
                    appendLine("${idx + 1}. [${item.source}] ${item.headline}")
                    if (item.summary.isNotBlank()) {
                        appendLine("   ملخص: ${item.summary.take(280)}")
                    }
                }
            }
            appendLine()
            appendLine("المطلوب في JSON باللغة العربية الاحترافية:")
            appendLine("- لا تعتبر التوقع حقيقة مؤكدة بل تحليل احتمالي.")
            appendLine("- افصل تماماً بين أسباب التحليل الفني (technicalReasonsArabic) وأسباب تحليل الأخبار (newsReasonsArabic).")
        }

        return try {
            val response = withTimeout(45_000L) {
                predictionGenerativeModel.generateContent(prompt)
            }
            val text = response.text ?: return null
            val json = JSONObject(text)

            val sentiment = NewsSentiment.fromCode(json.optString("newsSentiment", baseNewsSection.overallNewsSentiment.englishCode))
            val newsScore = json.optInt("newsBullishScore", baseNewsSection.newsBullishScore.roundToInt()).coerceIn(15, 85)
            val executive = json.optString("executiveVerdictArabic", "").trim()
            val techSummary = json.optString("technicalSummaryArabic", "").trim()
            val newsSummary = json.optString("newsSummaryArabic", "").trim()

            fun parseStringArray(key: String): List<String> {
                val arr = json.optJSONArray(key) ?: return emptyList()
                val list = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    val v = arr.optString(i).trim()
                    if (v.isNotEmpty()) list.add(v)
                }
                return list
            }

            GeminiSynthesisOutput(
                newsSentiment = sentiment,
                newsBullishScore = if (baseNewsSection.topReferencedHeadlines.isEmpty()) 50 else newsScore,
                executiveVerdictArabic = executive,
                technicalSummaryArabic = techSummary,
                newsSummaryArabic = newsSummary,
                technicalReasonsArabic = parseStringArray("technicalReasonsArabic"),
                newsReasonsArabic = parseStringArray("newsReasonsArabic"),
                combinedReasonsArabic = parseStringArray("combinedPredictionReasonsArabic")
            )
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "Gemini prediction synthesis timed out; using deterministic quantitative report", e)
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Gemini prediction synthesis unavailable; using deterministic quantitative report", e)
            null
        }
    }

    private fun computeIndicatorAgreementScore(indicators: List<TechnicalIndicatorFactor>): Double {
        if (indicators.isEmpty()) return 50.0
        val bullishCount = indicators.count { it.signal == IndicatorSignalDirection.BULLISH }
        val bearishCount = indicators.count { it.signal == IndicatorSignalDirection.BEARISH }
        val dominant = maxOf(bullishCount, bearishCount)
        return 45.0 + (dominant.toDouble() / indicators.size.toDouble()) * 45.0
    }

    private fun buildFallbackExecutiveVerdict(
        arabicName: String,
        symbol: String,
        horizon: PredictionHorizon,
        bullishProb: Int,
        bearishProb: Int,
        backtestAccuracy: Double
    ): String {
        val bias = if (bullishProb >= 55) {
            "يميل نحو الإيجابية بنسبة صعود متوقعة $bullishProb%"
        } else if (bearishProb >= 55) {
            "يميل نحو الحذر والضغط البيعي بنسبة هبوط متوقعة $bearishProb%"
        } else {
            "يشير إلى توازن نسبي بين القوى الشرائية ($bullishProb%) والبيعية ($bearishProb%)"
        }
        return "التحليل الكمي لسهم $arabicName ($symbol) خلال أفق ${horizon.arabicLabel} $bias، استناداً إلى قراءات RSI و MACD والمتوسطات المتحركة مع دقة تاريخية خارج العينة بلغت ${String.format(Locale.US, "%.1f%%", backtestAccuracy)}. هذا التوقع احتمالي وليس توصية استثمارية مؤكدة."
    }

    /**
     * Wilder's 14-period Relative Strength Index (RSI).
     */
    private fun calculateRsi14(closes: List<Double>, period: Int = 14): Double {
        if (closes.size <= period) return 50.0
        var avgGain = 0.0
        var avgLoss = 0.0

        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change > 0) avgGain += change else avgLoss += abs(change)
        }
        avgGain /= period.toDouble()
        avgLoss /= period.toDouble()

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) abs(change) else 0.0
            avgGain = ((avgGain * (period - 1)) + gain) / period.toDouble()
            avgLoss = ((avgLoss * (period - 1)) + loss) / period.toDouble()
        }

        if (avgLoss <= 1e-9) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    /**
     * Standard MACD (12, 26, 9) returning Triple(macdLine, signalLine, histogram).
     */
    private fun calculateMacd(
        closes: List<Double>,
        fastPeriod: Int = 12,
        slowPeriod: Int = 26,
        signalPeriod: Int = 9
    ): Triple<Double, Double, Double> {
        if (closes.size < slowPeriod + signalPeriod) return Triple(0.0, 0.0, 0.0)
        val emaFastSeries = calculateEmaSeries(closes, fastPeriod)
        val emaSlowSeries = calculateEmaSeries(closes, slowPeriod)
        val macdSeries = closes.indices.map { i -> emaFastSeries[i] - emaSlowSeries[i] }
        val signalSeries = calculateEmaSeries(macdSeries, signalPeriod)

        val macdLine = macdSeries.last()
        val signalLine = signalSeries.last()
        val histogram = macdLine - signalLine
        return Triple(macdLine, signalLine, histogram)
    }

    private fun calculateSma(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        return values.takeLast(period.coerceAtMost(values.size)).average()
    }

    private fun calculateEma(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        return calculateEmaSeries(values, period).last()
    }

    private fun calculateEmaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1.0)
        val result = ArrayList<Double>(values.size)
        var currentEma = values.first()
        result.add(currentEma)
        for (i in 1 until values.size) {
            currentEma = (values[i] * k) + (currentEma * (1.0 - k))
            result.add(currentEma)
        }
        return result
    }

    private fun calculateAnnualizedVolatilityPercent(closes: List<Double>): Double {
        val recent = closes.takeLast(30)
        if (recent.size < 5) return 25.0
        val logReturns = mutableListOf<Double>()
        for (i in 1 until recent.size) {
            if (recent[i - 1] > 0.0 && recent[i] > 0.0) {
                logReturns.add(ln(recent[i] / recent[i - 1]))
            }
        }
        if (logReturns.size < 2) return 25.0
        val mean = logReturns.average()
        val variance = logReturns.sumOf { (it - mean) * (it - mean) } / (logReturns.size - 1).toDouble()
        val dailyStd = sqrt(variance.coerceAtLeast(0.0))
        return (dailyStd * sqrt(252.0) * 100.0).coerceIn(5.0, 150.0)
    }
}
