package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

enum class NewsSentiment(
    val arabicLabel: String,
    val englishCode: String
) {
    POSITIVE("إيجابي", "POSITIVE"),
    NEGATIVE("سلبي", "NEGATIVE"),
    NEUTRAL("محايد", "NEUTRAL");

    companion object {
        fun fromCode(code: String?): NewsSentiment {
            return when (code?.trim()?.uppercase()) {
                "POSITIVE" -> POSITIVE
                "NEGATIVE" -> NEGATIVE
                else -> NEUTRAL
            }
        }
    }
}

enum class AlertCondition(
    val englishCode: String,
    val arabicLabel: String,
    val shortArabicSymbol: String
) {
    ABOVE("ABOVE", "صعوداً إلى أو أعلى من (≥)", "≥"),
    BELOW("BELOW", "هبوطاً إلى أو أقل من (≤)", "≤");

    companion object {
        fun fromCode(code: String?): AlertCondition {
            return when (code?.trim()?.uppercase()) {
                "BELOW" -> BELOW
                else -> ABOVE
            }
        }
    }
}

@IgnoreExtraProperties
data class WatchlistStock(
    @DocumentId val id: String = "",
    val userId: String = "",
    val symbol: String = "",
    val companyName: String = "",
    val arabicName: String? = null,
    val sector: String? = null,
    val notes: String? = null,
    val targetPrice: Double? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreatePayload(uid: String): Map<String, Any> {
        return mapOf<String, Any?>(
            "userId" to uid,
            "symbol" to symbol.trim().uppercase(),
            "companyName" to companyName.trim(),
            "arabicName" to arabicName?.trim()?.takeIf { it.isNotEmpty() },
            "sector" to sector?.trim()?.takeIf { it.isNotEmpty() },
            "notes" to notes?.trim()?.takeIf { it.isNotEmpty() },
            "targetPrice" to targetPrice?.takeIf { it >= 0.0 },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }
            .mapValues { it.value!! }
    }
}

@IgnoreExtraProperties
data class PriceAlert(
    @DocumentId val id: String = "",
    val userId: String = "",
    val symbol: String = "",
    val companyName: String = "",
    val arabicName: String? = null,
    val targetPrice: Double = 0.0,
    val condition: String = "ABOVE",
    val note: String? = null,
    @get:PropertyName("isEnabled")
    @field:PropertyName("isEnabled")
    val isEnabled: Boolean = true,
    @get:PropertyName("isTriggered")
    @field:PropertyName("isTriggered")
    val isTriggered: Boolean = false,
    val triggeredPrice: Double? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val conditionEnum: AlertCondition
        get() = AlertCondition.fromCode(condition)

    fun shouldTrigger(livePrice: Double): Boolean {
        if (!isEnabled || isTriggered || livePrice <= 0.0 || targetPrice <= 0.0) return false
        return when (conditionEnum) {
            AlertCondition.ABOVE -> livePrice >= targetPrice
            AlertCondition.BELOW -> livePrice <= targetPrice
        }
    }

    fun toCreatePayload(uid: String): Map<String, Any> {
        return mapOf<String, Any?>(
            "userId" to uid,
            "symbol" to symbol.trim().uppercase(),
            "companyName" to companyName.trim().take(120),
            "arabicName" to arabicName?.trim()?.take(120)?.takeIf { it.isNotEmpty() },
            "targetPrice" to targetPrice,
            "condition" to AlertCondition.fromCode(condition).englishCode,
            "note" to note?.trim()?.take(300)?.takeIf { it.isNotEmpty() },
            "isEnabled" to isEnabled,
            "isTriggered" to isTriggered,
            "triggeredPrice" to triggeredPrice?.takeIf { it >= 0.0 },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }
            .mapValues { it.value!! }
    }
}

@IgnoreExtraProperties
data class SavedNewsAnalysis(
    @DocumentId val id: String = "",
    val userId: String = "",
    val symbol: String = "",
    val headline: String = "",
    val source: String = "",
    val publishedAtMillis: Long = 0L,
    val articleUrl: String = "",
    val sentiment: String = "NEUTRAL",
    val confidenceScore: Long = 80L,
    val arabicSummary: String = "",
    val marketImpact: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val sentimentEnum: NewsSentiment
        get() = NewsSentiment.fromCode(sentiment)

    fun toCreatePayload(uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "symbol" to symbol.trim().uppercase(),
            "headline" to headline.take(500),
            "source" to source.take(120),
            "publishedAtMillis" to publishedAtMillis.coerceAtLeast(1L),
            "articleUrl" to articleUrl.ifBlank { "https://finance.yahoo.com" }.take(1000),
            "sentiment" to NewsSentiment.fromCode(sentiment).englishCode,
            "confidenceScore" to confidenceScore.coerceIn(0L, 100L),
            "arabicSummary" to arabicSummary.take(2000),
            "marketImpact" to marketImpact.take(2000),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}

@IgnoreExtraProperties
data class PortfolioHolding(
    @DocumentId val id: String = "",
    val userId: String = "",
    val symbol: String = "",
    val companyName: String = "",
    val arabicName: String? = null,
    val sector: String? = null,
    val sharesCount: Double = 0.0,
    val buyPrice: Double = 0.0,
    val notes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val totalCostBasis: Double
        get() = (sharesCount * buyPrice).coerceAtLeast(0.0)

    fun marketValue(livePrice: Double?): Double? {
        if (livePrice == null || livePrice <= 0.0) return null
        return sharesCount * livePrice
    }

    fun profitLossUsd(livePrice: Double?): Double? {
        val currentVal = marketValue(livePrice) ?: return null
        return currentVal - totalCostBasis
    }

    fun profitLossPercent(livePrice: Double?): Double? {
        val pnl = profitLossUsd(livePrice) ?: return null
        val cost = totalCostBasis
        if (cost <= 0.0) return null
        return (pnl / cost) * 100.0
    }

    fun dayProfitLossUsd(quote: StockQuote?): Double? {
        if (quote == null) return null
        return sharesCount * quote.change
    }

    fun toCreatePayload(uid: String): Map<String, Any> {
        return mapOf<String, Any?>(
            "userId" to uid,
            "symbol" to symbol.trim().uppercase(),
            "companyName" to companyName.trim().take(120),
            "arabicName" to arabicName?.trim()?.take(120)?.takeIf { it.isNotEmpty() },
            "sector" to sector?.trim()?.take(80)?.takeIf { it.isNotEmpty() },
            "sharesCount" to sharesCount,
            "buyPrice" to buyPrice,
            "notes" to notes?.trim()?.take(500)?.takeIf { it.isNotEmpty() },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }
            .mapValues { it.value!! }
    }
}

data class StockQuote(
    val symbol: String,
    val companyName: String,
    val arabicName: String,
    val sector: String,
    val currentPrice: Double,
    val change: Double,
    val changePercent: Double,
    val dayHigh: Double,
    val dayLow: Double,
    val openPrice: Double,
    val previousClose: Double,
    val volume: Long,
    val exchangeName: String,
    val currency: String,
    val quoteTimestampMillis: Long,
    val dataSource: String,
    val sparklinePoints: List<Double> = emptyList()
) {
    val isPositive: Boolean get() = change > 0.0
    val isNegative: Boolean get() = change < 0.0
}

data class CompanyNewsItem(
    val id: String,
    val symbol: String,
    val headline: String,
    val summary: String,
    val source: String,
    val publishedAtMillis: Long,
    val url: String,
    val imageUrl: String? = null,
    val aiAnalysis: AiNewsAnalysisResult? = null,
    val isAnalyzing: Boolean = false,
    val analysisError: String? = null
)

data class AiNewsAnalysisResult(
    val sentiment: NewsSentiment,
    val confidenceScore: Int,
    val arabicHeadline: String,
    val arabicSummary: String,
    val marketImpact: String,
    val keyDrivers: List<String>
)

data class CompanyDailyHighlight(
    val symbol: String,
    val arabicName: String,
    val sentiment: NewsSentiment,
    val summary: String,
    val source: String
)

data class DailyWatchlistSummary(
    val overallSentiment: NewsSentiment,
    val welcomeHeadline: String,
    val executiveSummary: String,
    val keyMarketTakeaway: String,
    val companyHighlights: List<CompanyDailyHighlight>,
    val watchlistSymbols: List<String>,
    val articlesCount: Int,
    val generatedAtMillis: Long = System.currentTimeMillis()
)

data class CuratedUsStock(
    val symbol: String,
    val companyName: String,
    val arabicName: String,
    val sector: String
)

object UsStockCatalog {
    val majorUsStocks: List<CuratedUsStock> = listOf(
        CuratedUsStock("NVDA", "NVIDIA Corporation", "إنفيديا", "أشباه الموصلات والذكاء الاصطناعي"),
        CuratedUsStock("AAPL", "Apple Inc.", "أبل", "التكنولوجيا الاستهلاكية"),
        CuratedUsStock("MSFT", "Microsoft Corporation", "مايكروسوفت", "الحوسبة السحابية والبرمجيات"),
        CuratedUsStock("GOOGL", "Alphabet Inc.", "ألفابت (جوجل)", "الإنترنت والذكاء الاصطناعي"),
        CuratedUsStock("AMZN", "Amazon.com Inc.", "أمازون", "التجارة الإلكترونية والسحابة"),
        CuratedUsStock("META", "Meta Platforms Inc.", "ميتا", "التواصل الاجتماعي والذكاء الاصطناعي"),
        CuratedUsStock("TSLA", "Tesla Inc.", "تسلا", "المركبات الكهربائية والطاقة"),
        CuratedUsStock("AMD", "Advanced Micro Devices", "إيه إم دي", "أشباه الموصلات"),
        CuratedUsStock("AVGO", "Broadcom Inc.", "برودكوم", "الشبكات والرقائق"),
        CuratedUsStock("NFLX", "Netflix Inc.", "نتفليكس", "البث الرقمي والترفيه"),
        CuratedUsStock("JPM", "JPMorgan Chase & Co.", "جي بي مورغان", "الخدمات المصرفية والمالية"),
        CuratedUsStock("V", "Visa Inc.", "فيزا", "المدفوعات الرقمية"),
        CuratedUsStock("LLY", "Eli Lilly and Company", "إيلي ليلي", "الرعاية الصحية والأدوية"),
        CuratedUsStock("BRK-B", "Berkshire Hathaway", "بيركشاير هاثاواي", "الاستثمار القابض"),
        CuratedUsStock("ORCL", "Oracle Corporation", "أوراكل", "قواعد البيانات والسحابة")
    )

    fun findBySymbol(symbol: String): CuratedUsStock? {
        val clean = symbol.trim().uppercase()
        return majorUsStocks.find { it.symbol.equals(clean, ignoreCase = true) }
    }
}
