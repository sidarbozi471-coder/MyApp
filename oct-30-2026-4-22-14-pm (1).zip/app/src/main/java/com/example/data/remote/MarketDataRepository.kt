package com.example.data.remote

import android.util.Log
import android.util.Xml
import com.example.BuildConfig
import com.example.data.model.CompanyNewsItem
import com.example.data.model.CuratedUsStock
import com.example.data.model.HistoricalCandle
import com.example.data.model.StockQuote
import com.example.data.model.UsStockCatalog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

private const val TAG = "MarketDataRepository"

/**
 * Fetches 100% authentic, live US stock quotes, intraday sparklines, symbol search results,
 * and real-time company news with verified sources and timestamps.
 *
 * Strictly adheres to "عدم اختلاق أسعار أو أخبار غير حقيقية":
 * Never generates mock, random, or simulated prices or news articles.
 */
class MarketDataRepository(
    private val httpClient: OkHttpClient = defaultOkHttpClient()
) {
    private val finnhubApiKey: String
        get() = try {
            BuildConfig.FINNHUB_API_KEY.trim()
        } catch (e: Exception) {
            ""
        }

    val isFinnhubConfigured: Boolean
        get() = finnhubApiKey.isNotEmpty() &&
            finnhubApiKey != "YOUR_FINNHUB_API_KEY" &&
            !finnhubApiKey.startsWith("MY_")

    suspend fun fetchQuotesForSymbols(symbols: List<String>): Result<List<StockQuote>> =
        withContext(Dispatchers.IO) {
            val cleanSymbols = symbols.map { it.trim().uppercase() }.distinct()
            if (cleanSymbols.isEmpty()) return@withContext Result.success(emptyList())

            try {
                val results = coroutineScope {
                    cleanSymbols.map { symbol ->
                        async {
                            fetchSingleQuote(symbol).getOrNull()
                        }
                    }.awaitAll().filterNotNull()
                }

                if (results.isEmpty()) {
                    Result.failure(
                        IllegalStateException(
                            "تعذر جلب أسعار الأسهم الحية من مزود البيانات حالياً. يرجى التحقق من اتصال الإنترنت والمحاولة مجدداً."
                        )
                    )
                } else {
                    Result.success(results)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching batch quotes", e)
                Result.failure(e)
            }
        }

    suspend fun fetchSingleQuote(symbol: String): Result<StockQuote> =
        withContext(Dispatchers.IO) {
            val cleanSymbol = symbol.trim().uppercase()
            val curated = UsStockCatalog.findBySymbol(cleanSymbol)

            // 1. If Finnhub API key is configured in AI Studio Secrets, try Finnhub first + Yahoo sparkline
            if (isFinnhubConfigured) {
                val finnhubResult = fetchQuoteFromFinnhub(cleanSymbol, curated)
                if (finnhubResult.isSuccess) {
                    val quote = finnhubResult.getOrThrow()
                    val sparkline = fetchYahooQuoteAndSparkline(cleanSymbol, curated)
                        .getOrNull()?.sparklinePoints.orEmpty()
                    return@withContext Result.success(
                        if (sparkline.isNotEmpty()) quote.copy(sparklinePoints = sparkline) else quote
                    )
                }
            }

            // 2. Fetch live quote + intraday chart points from Yahoo Finance public v8 chart endpoint
            val yahooResult = fetchYahooQuoteAndSparkline(cleanSymbol, curated)
            if (yahooResult.isSuccess) {
                return@withContext yahooResult
            }

            Result.failure(
                yahooResult.exceptionOrNull()
                    ?: IllegalStateException("بيانات السعر الحقيقي للسهم $cleanSymbol غير متوفرة حالياً من المصدر.")
            )
        }

    private fun fetchQuoteFromFinnhub(
        symbol: String,
        curated: CuratedUsStock?
    ): Result<StockQuote> {
        val encoded = URLEncoder.encode(symbol, "UTF-8")
        val url = "https://finnhub.io/api/v1/quote?symbol=$encoded&token=$finnhubApiKey"
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", USER_AGENT)
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return Result.failure(IllegalStateException("Finnhub HTTP ${response.code}"))
                }
                val body = response.body?.string().orEmpty()
                val json = JSONObject(body)
                val currentPrice = json.optDouble("c", 0.0)
                val prevClose = json.optDouble("pc", 0.0)
                if (currentPrice <= 0.0 && prevClose <= 0.0) {
                    return Result.failure(IllegalStateException("لا توجد بيانات تداول حقيقية للرمز $symbol"))
                }
                val change = json.optDouble("d", currentPrice - prevClose)
                val changePercent = json.optDouble(
                    "dp",
                    if (prevClose > 0) ((currentPrice - prevClose) / prevClose) * 100.0 else 0.0
                )
                val high = json.optDouble("h", currentPrice)
                val low = json.optDouble("l", currentPrice)
                val open = json.optDouble("o", prevClose)
                val timestampSec = json.optLong("t", 0L)
                val timestampMillis = if (timestampSec > 0L) timestampSec * 1000L else System.currentTimeMillis()

                Result.success(
                    StockQuote(
                        symbol = symbol,
                        companyName = curated?.companyName ?: symbol,
                        arabicName = curated?.arabicName ?: symbol,
                        sector = curated?.sector ?: "السوق الأمريكي",
                        currentPrice = currentPrice,
                        change = change,
                        changePercent = changePercent,
                        dayHigh = high,
                        dayLow = low,
                        openPrice = open,
                        previousClose = prevClose,
                        volume = 0L,
                        exchangeName = "US Market",
                        currency = "USD",
                        quoteTimestampMillis = timestampMillis,
                        dataSource = "Finnhub Live"
                    )
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Finnhub quote fetch failed for $symbol", e)
            Result.failure(e)
        }
    }

    private fun fetchYahooQuoteAndSparkline(
        symbol: String,
        curated: CuratedUsStock?
    ): Result<StockQuote> {
        val encoded = URLEncoder.encode(symbol, "UTF-8")
        val hosts = listOf("query1.finance.yahoo.com", "query2.finance.yahoo.com")
        var lastException: Exception? = null

        for (host in hosts) {
            val url = "https://$host/v8/finance/chart/$encoded?interval=5m&range=1d"
            val request = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header("User-Agent", USER_AGENT)
                .build()

            try {
                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        lastException = IllegalStateException("HTTP ${response.code} from $host")
                        return@use
                    }
                    val body = response.body?.string().orEmpty()
                    val root = JSONObject(body)
                    val chart = root.optJSONObject("chart")
                    val results = chart?.optJSONArray("result")
                    if (results == null || results.length() == 0) {
                        lastException = IllegalStateException("لم يتم العثور على بيانات السهم $symbol")
                        return@use
                    }
                    val resultObj = results.getJSONObject(0)
                    val meta = resultObj.getJSONObject("meta")

                    val currentPrice = meta.optDouble("regularMarketPrice", Double.NaN)
                    val prevClose = meta.optDouble(
                        "chartPreviousClose",
                        meta.optDouble("previousClose", Double.NaN)
                    )
                    if (currentPrice.isNaN() || currentPrice <= 0.0) {
                        lastException = IllegalStateException("سعر السوق غير متوفر حالياً لـ $symbol")
                        return@use
                    }

                    val validPrevClose = if (!prevClose.isNaN() && prevClose > 0.0) prevClose else currentPrice
                    val change = currentPrice - validPrevClose
                    val changePercent = if (validPrevClose > 0.0) (change / validPrevClose) * 100.0 else 0.0

                    val dayHigh = meta.optDouble("regularMarketDayHigh", currentPrice)
                        .let { if (it.isNaN() || it <= 0.0) currentPrice else it }
                    val dayLow = meta.optDouble("regularMarketDayLow", currentPrice)
                        .let { if (it.isNaN() || it <= 0.0) currentPrice else it }
                    val volume = meta.optLong("regularMarketVolume", 0L)
                    val marketTimeSec = meta.optLong("regularMarketTime", 0L)
                    val quoteTimestampMillis =
                        if (marketTimeSec > 0L) marketTimeSec * 1000L else System.currentTimeMillis()
                    val exchangeName = meta.optString("exchangeName", "NASDAQ/NYSE")
                    val currency = meta.optString("currency", "USD")
                    val longName = meta.optString("longName", "")
                        .ifBlank { meta.optString("shortName", "") }
                        .ifBlank { curated?.companyName ?: symbol }

                    // Extract real intraday close points for sparkline chart
                    val sparkline = mutableListOf<Double>()
                    val indicators = resultObj.optJSONObject("indicators")
                    val quoteArray = indicators?.optJSONArray("quote")
                    if (quoteArray != null && quoteArray.length() > 0) {
                        val closeArray = quoteArray.getJSONObject(0).optJSONArray("close")
                        if (closeArray != null) {
                            for (i in 0 until closeArray.length()) {
                                if (!closeArray.isNull(i)) {
                                    val pricePoint = closeArray.optDouble(i, Double.NaN)
                                    if (!pricePoint.isNaN() && pricePoint > 0.0) {
                                        sparkline.add(pricePoint)
                                    }
                                }
                            }
                        }
                    }

                    val openPrice = sparkline.firstOrNull() ?: validPrevClose

                    return Result.success(
                        StockQuote(
                            symbol = symbol,
                            companyName = curated?.companyName ?: longName,
                            arabicName = curated?.arabicName ?: longName,
                            sector = curated?.sector ?: "الأسهم الأمريكية",
                            currentPrice = currentPrice,
                            change = change,
                            changePercent = changePercent,
                            dayHigh = dayHigh,
                            dayLow = dayLow,
                            openPrice = openPrice,
                            previousClose = validPrevClose,
                            volume = volume,
                            exchangeName = exchangeName,
                            currency = currency,
                            quoteTimestampMillis = quoteTimestampMillis,
                            dataSource = "Yahoo Finance Live",
                            sparklinePoints = sparkline.takeLast(60)
                        )
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Yahoo Finance quote fetch failed on $host for $symbol", e)
                lastException = e
            }
        }

        return Result.failure(
            lastException ?: IllegalStateException("تعذر جلب سعر السهم $symbol من المصدر الحي.")
        )
    }

    /**
     * Fetches real-time / latest authentic news for one or more US stock symbols.
     * Combines Finnhub Company News (if API key configured), Yahoo Finance RSS feed, and Yahoo Finance News Search.
     * Never fabricates or invents news articles.
     */
    suspend fun fetchCompanyNews(symbols: List<String>): Result<List<CompanyNewsItem>> =
        withContext(Dispatchers.IO) {
            val cleanSymbols = symbols.map { it.trim().uppercase() }.filter { it.isNotEmpty() }.distinct()
            val targetSymbols = cleanSymbols.ifEmpty { listOf("NVDA", "AAPL", "MSFT", "TSLA") }.take(6)

            try {
                val allArticles = coroutineScope {
                    targetSymbols.map { symbol ->
                        async {
                            fetchNewsForSingleSymbol(symbol)
                        }
                    }.awaitAll().flatten()
                }

                val deduplicated = allArticles
                    .filter { it.headline.isNotBlank() && it.source.isNotBlank() && it.publishedAtMillis > 0L }
                    .distinctBy { it.headline.lowercase().trim() }
                    .sortedByDescending { it.publishedAtMillis }

                if (deduplicated.isEmpty()) {
                    Result.failure(
                        IllegalStateException(
                            "لا تتوفر أخبار منشورة حالياً من المصادر الإخبارية لهذه الشركات، أو تعذر الاتصال بالمصدر."
                        )
                    )
                } else {
                    Result.success(deduplicated)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Failed to fetch live company news", e)
                Result.failure(e)
            }
        }

    private fun fetchNewsForSingleSymbol(symbol: String): List<CompanyNewsItem> {
        // 1. Try Finnhub company-news if API key is configured
        if (isFinnhubConfigured) {
            val finnhubNews = fetchFinnhubCompanyNews(symbol)
            if (finnhubNews.isNotEmpty()) {
                return finnhubNews
            }
        }

        // 2. Try Yahoo Finance Search News JSON endpoint (includes publisher, exact Unix timestamp, link, thumbnail)
        val searchNews = fetchYahooSearchNews(symbol)
        if (searchNews.isNotEmpty()) {
            return searchNews
        }

        // 3. Try Yahoo Finance Official RSS Headline Feed for the symbol
        return fetchYahooRssNews(symbol)
    }

    private fun fetchFinnhubCompanyNews(symbol: String): List<CompanyNewsItem> {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val now = System.currentTimeMillis()
        val sevenDaysAgo = now - TimeUnit.DAYS.toMillis(7)
        val fromDate = dateFormat.format(Date(sevenDaysAgo))
        val toDate = dateFormat.format(Date(now))
        val encoded = URLEncoder.encode(symbol, "UTF-8")
        val url = "https://finnhub.io/api/v1/company-news?symbol=$encoded&from=$fromDate&to=$toDate&token=$finnhubApiKey"

        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", USER_AGENT)
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val body = response.body?.string().orEmpty()
                val array = JSONArray(body)
                val items = mutableListOf<CompanyNewsItem>()
                for (i in 0 until minOf(array.length(), 12)) {
                    val obj = array.getJSONObject(i)
                    val headline = obj.optString("headline", "").trim()
                    val summary = obj.optString("summary", "").trim()
                    val source = obj.optString("source", "").trim().ifBlank { "Finnhub News" }
                    val datetimeSec = obj.optLong("datetime", 0L)
                    val articleUrl = obj.optString("url", "").trim()
                    val imageUrl = obj.optString("image", "").trim().takeIf { it.startsWith("http") }
                    val id = obj.optLong("id", datetimeSec).toString()

                    if (headline.isNotBlank() && datetimeSec > 0L && articleUrl.isNotBlank()) {
                        items.add(
                            CompanyNewsItem(
                                id = "${symbol}_fh_$id",
                                symbol = symbol,
                                headline = headline,
                                summary = summary,
                                source = source,
                                publishedAtMillis = datetimeSec * 1000L,
                                url = articleUrl,
                                imageUrl = imageUrl
                            )
                        )
                    }
                }
                items
            }
        } catch (e: Exception) {
            Log.w(TAG, "Finnhub company news failed for $symbol", e)
            emptyList()
        }
    }

    private fun fetchYahooSearchNews(symbol: String): List<CompanyNewsItem> {
        val encoded = URLEncoder.encode(symbol, "UTF-8")
        val url = "https://query1.finance.yahoo.com/v1/finance/search?q=$encoded&quotesCount=1&newsCount=10"
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", USER_AGENT)
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val body = response.body?.string().orEmpty()
                val root = JSONObject(body)
                val newsArray = root.optJSONArray("news") ?: return emptyList()
                val items = mutableListOf<CompanyNewsItem>()

                for (i in 0 until newsArray.length()) {
                    val obj = newsArray.getJSONObject(i)
                    val uuid = obj.optString("uuid", "$i")
                    val title = obj.optString("title", "").trim()
                    val publisher = obj.optString("publisher", "").trim().ifBlank { "Yahoo Finance" }
                    val link = obj.optString("link", "").trim()
                    val publishTimeSec = obj.optLong("providerPublishTime", 0L)

                    var thumbUrl: String? = null
                    val thumbnail = obj.optJSONObject("thumbnail")
                    val resolutions = thumbnail?.optJSONArray("resolutions")
                    if (resolutions != null && resolutions.length() > 0) {
                        thumbUrl = resolutions.getJSONObject(0).optString("url", "").takeIf { it.isNotBlank() }
                    }

                    if (title.isNotBlank() && publishTimeSec > 0L && link.isNotBlank()) {
                        items.add(
                            CompanyNewsItem(
                                id = "${symbol}_yf_$uuid",
                                symbol = symbol,
                                headline = title,
                                summary = "خبر منشور عبر $publisher حول سهم $symbol في السوق الأمريكي.",
                                source = publisher,
                                publishedAtMillis = publishTimeSec * 1000L,
                                url = link,
                                imageUrl = thumbUrl
                            )
                        )
                    }
                }
                items
            }
        } catch (e: Exception) {
            Log.w(TAG, "Yahoo search news failed for $symbol", e)
            emptyList()
        }
    }

    private fun fetchYahooRssNews(symbol: String): List<CompanyNewsItem> {
        val encoded = URLEncoder.encode(symbol, "UTF-8")
        val url = "https://feeds.finance.yahoo.com/rss/2.0/headline?s=$encoded&region=US&lang=en-US"
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/rss+xml, application/xml, text/xml")
            .header("User-Agent", USER_AGENT)
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val xmlBody = response.body?.string().orEmpty()
                if (xmlBody.isBlank()) return emptyList()
                parseRssItems(xmlBody, symbol)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Yahoo RSS news failed for $symbol", e)
            emptyList()
        }
    }

    private fun parseRssItems(xml: String, symbol: String): List<CompanyNewsItem> {
        val items = mutableListOf<CompanyNewsItem>()
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xml))

        var eventType = parser.eventType
        var insideItem = false
        var title = ""
        var description = ""
        var link = ""
        var pubDate = ""
        var guid = ""
        var sourceName = "Yahoo Finance"

        val rfc822Formats = listOf(
            SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US),
            SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US),
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
        )

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    val tagName = parser.name.lowercase(Locale.US)
                    if (tagName == "item") {
                        insideItem = true
                        title = ""
                        description = ""
                        link = ""
                        pubDate = ""
                        guid = ""
                        sourceName = "Yahoo Finance"
                    } else if (insideItem) {
                        when (tagName) {
                            "title" -> title = parser.nextText().trim()
                            "description" -> description = parser.nextText().trim()
                            "link" -> link = parser.nextText().trim()
                            "pubdate" -> pubDate = parser.nextText().trim()
                            "guid" -> guid = parser.nextText().trim()
                            "source" -> sourceName = parser.nextText().trim().ifBlank { "Yahoo Finance" }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true) && insideItem) {
                        insideItem = false
                        val publishedMillis = rfc822Formats.firstNotNullOfOrNull { fmt ->
                            try {
                                fmt.parse(pubDate)?.time
                            } catch ( ignored: Exception) {
                                null
                            }
                        } ?: 0L

                        if (title.isNotBlank() && publishedMillis > 0L && link.isNotBlank()) {
                            items.add(
                                CompanyNewsItem(
                                    id = "${symbol}_rss_${guid.ifBlank { publishedMillis.toString() }.hashCode()}",
                                    symbol = symbol,
                                    headline = title,
                                    summary = description.replace(Regex("<[^>]*>"), "").trim(),
                                    source = sourceName,
                                    publishedAtMillis = publishedMillis,
                                    url = link
                                )
                            )
                        }
                    }
                }
            }
            eventType = parser.next()
        }
        return items
    }

    /**
     * Searches live US stocks by symbol or company name using Yahoo Finance / Finnhub search.
     */
    suspend fun searchUsStocks(query: String): Result<List<CuratedUsStock>> =
        withContext(Dispatchers.IO) {
            val cleanQuery = query.trim()
            if (cleanQuery.isBlank()) {
                return@withContext Result.success(UsStockCatalog.majorUsStocks)
            }

            // Local match first for instant Arabic & English matching
            val localMatches = UsStockCatalog.majorUsStocks.filter {
                it.symbol.contains(cleanQuery, ignoreCase = true) ||
                    it.companyName.contains(cleanQuery, ignoreCase = true) ||
                    it.arabicName.contains(cleanQuery, ignoreCase = true) ||
                    it.sector.contains(cleanQuery, ignoreCase = true)
            }

            // Also query Yahoo Finance live symbol search for any US stock ticker
            val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
            val url = "https://query1.finance.yahoo.com/v1/finance/search?q=$encoded&quotesCount=10&newsCount=0"
            val request = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header("User-Agent", USER_AGENT)
                .build()

            try {
                val remoteMatches = httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@use emptyList<CuratedUsStock>()
                    val body = response.body?.string().orEmpty()
                    val root = JSONObject(body)
                    val quotesArray = root.optJSONArray("quotes") ?: return@use emptyList()
                    val list = mutableListOf<CuratedUsStock>()
                    for (i in 0 until quotesArray.length()) {
                        val obj = quotesArray.getJSONObject(i)
                        val quoteType = obj.optString("quoteType", "")
                        val symbol = obj.optString("symbol", "").trim().uppercase()
                        val exchange = obj.optString("exchange", "")
                        if (quoteType == "EQUITY" && symbol.isNotBlank() && !symbol.contains(".")) {
                            val name = obj.optString("longname", "")
                                .ifBlank { obj.optString("shortname", symbol) }
                            val sector = obj.optString("sectorDisp", "")
                                .ifBlank { obj.optString("industryDisp", exchange.ifBlank { "السوق الأمريكي" }) }
                            val curated = UsStockCatalog.findBySymbol(symbol)
                            list.add(
                                CuratedUsStock(
                                    symbol = symbol,
                                    companyName = name,
                                    arabicName = curated?.arabicName ?: name,
                                    sector = curated?.sector ?: sector
                                )
                            )
                        }
                    }
                    list
                }

                val combined = (localMatches + remoteMatches).distinctBy { it.symbol }
                Result.success(combined)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Live stock search fallback to local catalog", e)
                Result.success(localMatches)
            }
        }

    /**
     * Fetches real historical daily OHLCV candles (1 year / ~252 trading days) from Yahoo Finance
     * for quantitative technical indicators (RSI, MACD, Moving Averages) and out-of-sample backtesting.
     * Never fabricates or mocks any historical candles.
     */
    suspend fun fetchHistoricalDailyCandles(
        symbol: String,
        range: String = "1y"
    ): Result<List<HistoricalCandle>> = withContext(Dispatchers.IO) {
        val cleanSymbol = symbol.trim().uppercase()
        if (cleanSymbol.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("رمز السهم غير صالح"))
        }

        val encoded = URLEncoder.encode(cleanSymbol, "UTF-8")
        val hosts = listOf("query1.finance.yahoo.com", "query2.finance.yahoo.com")
        var lastException: Exception? = null

        for (host in hosts) {
            val url = "https://$host/v8/finance/chart/$encoded?interval=1d&range=$range"
            val request = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header("User-Agent", USER_AGENT)
                .build()

            try {
                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        lastException = IllegalStateException("HTTP ${response.code} from $host")
                        return@use
                    }
                    val body = response.body?.string().orEmpty()
                    val root = JSONObject(body)
                    val chart = root.optJSONObject("chart")
                    val results = chart?.optJSONArray("result")
                    if (results == null || results.length() == 0) {
                        lastException = IllegalStateException("لم يتم العثور على بيانات تاريخية للسهم $cleanSymbol")
                        return@use
                    }

                    val resultObj = results.getJSONObject(0)
                    val timestamps = resultObj.optJSONArray("timestamp")
                    val indicators = resultObj.optJSONObject("indicators")
                    val quoteArray = indicators?.optJSONArray("quote")

                    if (timestamps == null || quoteArray == null || quoteArray.length() == 0) {
                        lastException = IllegalStateException("السلاسل الزمنية التاريخية غير متوفرة للسهم $cleanSymbol")
                        return@use
                    }

                    val quoteObj = quoteArray.getJSONObject(0)
                    val opens = quoteObj.optJSONArray("open")
                    val highs = quoteObj.optJSONArray("high")
                    val lows = quoteObj.optJSONArray("low")
                    val closes = quoteObj.optJSONArray("close")
                    val volumes = quoteObj.optJSONArray("volume")

                    if (closes == null) {
                        lastException = IllegalStateException("أسعار الإغلاق التاريخية غير متوفرة للسهم $cleanSymbol")
                        return@use
                    }

                    val candles = mutableListOf<HistoricalCandle>()
                    val count = minOf(timestamps.length(), closes.length())
                    for (i in 0 until count) {
                        if (closes.isNull(i)) continue
                        val closeVal = closes.optDouble(i, Double.NaN)
                        if (closeVal.isNaN() || closeVal <= 0.0) continue

                        val tsSec = timestamps.optLong(i, 0L)
                        if (tsSec <= 0L) continue

                        val openVal = opens?.optDouble(i, closeVal)?.let {
                            if (it.isNaN() || it <= 0.0) closeVal else it
                        } ?: closeVal
                        val highVal = highs?.optDouble(i, closeVal)?.let {
                            if (it.isNaN() || it <= 0.0) closeVal else it
                        } ?: closeVal
                        val lowVal = lows?.optDouble(i, closeVal)?.let {
                            if (it.isNaN() || it <= 0.0) closeVal else it
                        } ?: closeVal
                        val volVal = volumes?.optLong(i, 0L)?.coerceAtLeast(0L) ?: 0L

                        candles.add(
                            HistoricalCandle(
                                timestampMillis = tsSec * 1000L,
                                open = openVal,
                                high = highVal,
                                low = lowVal,
                                close = closeVal,
                                volume = volVal
                            )
                        )
                    }

                    if (candles.isNotEmpty()) {
                        return@withContext Result.success(candles.sortedBy { it.timestampMillis })
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Error fetching historical candles from $host for $cleanSymbol", e)
                lastException = e
            }
        }

        Result.failure(
            lastException
                ?: IllegalStateException("تعذر جلب البيانات التاريخية للسهم $cleanSymbol من المصدر الموثوق.")
        )
    }

    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

        fun defaultOkHttpClient(): OkHttpClient {
            return OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .callTimeout(20, TimeUnit.SECONDS)
                .build()
        }
    }
}
