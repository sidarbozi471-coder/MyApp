package com.example.data.model

enum class PredictionHorizon(
    val arabicLabel: String,
    val arabicSubtitle: String,
    val tradingDaysLookahead: Int
) {
    HOURS_24(
        arabicLabel = "24 ساعة",
        arabicSubtitle = "التوقع لجلسة التداول القادمة (يوم واحد)",
        tradingDaysLookahead = 1
    ),
    DAYS_7(
        arabicLabel = "7 أيام",
        arabicSubtitle = "التوقع لأسبوع تداول كامل (5 جلسات)",
        tradingDaysLookahead = 5
    ),
    DAYS_30(
        arabicLabel = "30 يومًا",
        arabicSubtitle = "التوقع لشهر تداول كامل (21 جلسة)",
        tradingDaysLookahead = 21
    )
}

enum class IndicatorSignalDirection(
    val arabicLabel: String
) {
    BULLISH("إشارة صاعدة ↑"),
    BEARISH("إشارة هابطة ↓"),
    NEUTRAL("إشارة محايدة ↔")
}

data class HistoricalCandle(
    val timestampMillis: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
)

data class TechnicalIndicatorFactor(
    val code: String,
    val name: String,
    val formattedValue: String,
    val signal: IndicatorSignalDirection,
    val impactWeightPercent: Int,
    val arabicInterpretation: String
)

data class OutOfSampleBacktestReport(
    val trainingCandlesCount: Int,
    val outOfSampleTestCount: Int,
    val correctPredictionsCount: Int,
    val directionalAccuracyPercent: Double,
    val avgRealizedMovePercent: Double,
    val methodologyNoteArabic: String
)

data class TechnicalPredictionSection(
    val rsi14: Double,
    val macdLine: Double,
    val macdSignal: Double,
    val macdHistogram: Double,
    val sma20: Double,
    val sma50: Double,
    val ema20: Double,
    val currentVolume: Long,
    val avgVolume20: Long,
    val volumeRatio: Double,
    val return5dPercent: Double,
    val return20dPercent: Double,
    val annualizedVolatilityPercent: Double,
    val technicalBullishScore: Double,
    val influentialIndicators: List<TechnicalIndicatorFactor>,
    val technicalReasons: List<String>,
    val technicalSummaryArabic: String
)

data class NewsPredictionSection(
    val analyzedArticlesCount: Int,
    val positiveArticlesCount: Int,
    val negativeArticlesCount: Int,
    val neutralArticlesCount: Int,
    val newsBullishScore: Double,
    val overallNewsSentiment: NewsSentiment,
    val companyAndEconomicNewsSummaryArabic: String,
    val newsReasons: List<String>,
    val topReferencedHeadlines: List<CompanyNewsItem>
)

data class StockPredictionReport(
    val symbol: String,
    val companyName: String,
    val arabicName: String,
    val sector: String,
    val horizon: PredictionHorizon,
    val currentPrice: Double,
    val priceChangePercent: Double,
    val dataSource: String,
    val historicalCandlesCount: Int,
    val bullishProbabilityPercent: Int,
    val bearishProbabilityPercent: Int,
    val confidenceScorePercent: Int,
    val confidenceLabelArabic: String,
    val expectedPriceRangeLow: Double,
    val expectedPriceRangeHigh: Double,
    val technicalSection: TechnicalPredictionSection,
    val newsSection: NewsPredictionSection,
    val backtestReport: OutOfSampleBacktestReport,
    val aiSynthesizedReasons: List<String>,
    val aiExecutiveVerdictArabic: String,
    val isAiEnhanced: Boolean,
    val generatedAtMillis: Long = System.currentTimeMillis()
)

sealed interface StockPredictionUiState {
    data object Idle : StockPredictionUiState
    data class Loading(
        val symbol: String,
        val horizon: PredictionHorizon
    ) : StockPredictionUiState

    data class InsufficientData(
        val symbol: String,
        val reasonArabic: String,
        val availableCandles: Int,
        val requiredCandles: Int
    ) : StockPredictionUiState

    data class Success(
        val report: StockPredictionReport
    ) : StockPredictionUiState

    data class Error(
        val symbol: String,
        val messageArabic: String
    ) : StockPredictionUiState
}
