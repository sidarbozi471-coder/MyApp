package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firestore.OperationType
import com.example.data.firestore.handleFirestoreError
import com.example.data.model.PortfolioHolding
import com.example.data.model.PriceAlert
import com.example.data.model.SavedNewsAnalysis
import com.example.data.model.WatchlistStock
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class WatchlistRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth get() = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول بحساب Google للوصول إلى البيانات السحابية.")
    }

    fun observeWatchlist(userId: String = requireUserId()): Flow<List<WatchlistStock>> = flow {
        val path = "users/$userId/watchlist"
        emitAll(
            db.collection("users")
                .document(userId)
                .collection("watchlist")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(
                            WatchlistStock::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }.sortedBy { it.symbol }
                }
                .catch { error ->
                    if (error is Exception) {
                        handleFirestoreError(error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observePriceAlerts(userId: String = requireUserId()): Flow<List<PriceAlert>> = flow {
        val path = "users/$userId/price_alerts"
        emitAll(
            db.collection("users")
                .document(userId)
                .collection("price_alerts")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toPriceAlert()
                    }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    if (error is Exception) {
                        handleFirestoreError(error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeSavedAnalyses(userId: String = requireUserId()): Flow<List<SavedNewsAnalysis>> = flow {
        val path = "users/$userId/saved_analyses"
        emitAll(
            db.collection("users")
                .document(userId)
                .collection("saved_analyses")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(
                            SavedNewsAnalysis::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }.sortedByDescending { it.publishedAtMillis }
                }
                .catch { error ->
                    if (error is Exception) {
                        handleFirestoreError(error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observePortfolioHoldings(userId: String = requireUserId()): Flow<List<PortfolioHolding>> = flow {
        val path = "users/$userId/portfolio"
        emitAll(
            db.collection("users")
                .document(userId)
                .collection("portfolio")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(
                            PortfolioHolding::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }.sortedByDescending { it.totalCostBasis }
                }
                .catch { error ->
                    if (error is Exception) {
                        handleFirestoreError(error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun addOrUpdateWatchlistStock(stock: WatchlistStock): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanSymbol = stock.symbol.trim().uppercase()
        require(cleanSymbol.isNotBlank()) { "رمز السهم مطلوب" }
        val docRef = db.collection("users")
            .document(uid)
            .collection("watchlist")
            .document(cleanSymbol)

        return try {
            val payload = stock.copy(symbol = cleanSymbol).toCreatePayload(uid)
            docRef.set(payload).await()
            Result.success(cleanSymbol)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateWatchlistNotesAndTarget(
        symbol: String,
        notes: String?,
        targetPrice: Double?
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanSymbol = symbol.trim().uppercase()
        val docRef = db.collection("users")
            .document(uid)
            .collection("watchlist")
            .document(cleanSymbol)

        return try {
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!notes.isNullOrBlank()) {
                updates["notes"] = notes.trim().take(500)
            } else {
                updates["notes"] = FieldValue.delete()
            }
            if (targetPrice != null && targetPrice >= 0.0) {
                updates["targetPrice"] = targetPrice
            } else {
                updates["targetPrice"] = FieldValue.delete()
            }
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun removeWatchlistStock(symbol: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanSymbol = symbol.trim().uppercase()
        val docRef = db.collection("users")
            .document(uid)
            .collection("watchlist")
            .document(cleanSymbol)

        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun getWatchlistStockById(targetUserId: String, symbol: String): Result<WatchlistStock?> {
        val cleanSymbol = symbol.trim().uppercase()
        val docRef = db.collection("users")
            .document(targetUserId)
            .collection("watchlist")
            .document(cleanSymbol)

        return try {
            val snapshot = docRef.get().await()
            Result.success(
                snapshot.toObject(
                    WatchlistStock::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun createPriceAlert(alert: PriceAlert): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanSymbol = alert.symbol.trim().uppercase()
        require(cleanSymbol.isNotBlank()) { "رمز السهم مطلوب" }
        require(alert.targetPrice > 0.0) { "السعر المستهدف يجب أن يكون أكبر من صفر" }

        val alertId = alert.id.ifBlank {
            "alert_${cleanSymbol}_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        }
        val docRef = db.collection("users")
            .document(uid)
            .collection("price_alerts")
            .document(alertId)

        return try {
            val payload = alert.copy(
                id = alertId,
                symbol = cleanSymbol,
                isEnabled = true,
                isTriggered = false,
                triggeredPrice = null
            ).toCreatePayload(uid)
            docRef.set(payload).await()
            Result.success(alertId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun setPriceAlertEnabled(
        alertId: String,
        isEnabled: Boolean,
        resetTriggered: Boolean = false
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection("users")
            .document(uid)
            .collection("price_alerts")
            .document(alertId)

        return try {
            val updates = mutableMapOf<String, Any>(
                "isEnabled" to isEnabled,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (resetTriggered) {
                updates["isTriggered"] = false
                updates["triggeredPrice"] = FieldValue.delete()
            }
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updatePriceAlert(
        alertId: String,
        targetPrice: Double,
        conditionCode: String,
        note: String?
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        require(targetPrice > 0.0) { "السعر المستهدف يجب أن يكون أكبر من صفر" }
        val docRef = db.collection("users")
            .document(uid)
            .collection("price_alerts")
            .document(alertId)

        return try {
            val updates = mutableMapOf<String, Any>(
                "targetPrice" to targetPrice,
                "condition" to conditionCode,
                "isEnabled" to true,
                "isTriggered" to false,
                "triggeredPrice" to FieldValue.delete(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!note.isNullOrBlank()) {
                updates["note"] = note.trim().take(300)
            } else {
                updates["note"] = FieldValue.delete()
            }
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun markPriceAlertTriggered(
        alertId: String,
        triggeredPrice: Double
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection("users")
            .document(uid)
            .collection("price_alerts")
            .document(alertId)

        return try {
            val updates = mapOf(
                "isTriggered" to true,
                "isEnabled" to false,
                "triggeredPrice" to triggeredPrice,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deletePriceAlert(alertId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection("users")
            .document(uid)
            .collection("price_alerts")
            .document(alertId)

        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun getPriceAlertById(targetUserId: String, alertId: String): Result<PriceAlert?> {
        val docRef = db.collection("users")
            .document(targetUserId)
            .collection("price_alerts")
            .document(alertId)

        return try {
            val snapshot = docRef.get().await()
            Result.success(snapshot.toPriceAlert())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    private fun DocumentSnapshot.toPriceAlert(): PriceAlert? {
        if (!exists()) return null
        val base = toObject(
            PriceAlert::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
        ) ?: return null
        return base.copy(
            id = id,
            isEnabled = getBoolean("isEnabled") ?: base.isEnabled,
            isTriggered = getBoolean("isTriggered") ?: base.isTriggered,
            triggeredPrice = getDouble("triggeredPrice") ?: base.triggeredPrice
        )
    }

    suspend fun saveNewsAnalysis(analysis: SavedNewsAnalysis): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docId = analysis.id.ifBlank {
            "${analysis.symbol.trim().uppercase()}_${analysis.publishedAtMillis}"
                .replace(Regex("[^a-zA-Z0-9_\\-.]"), "_")
                .take(100)
        }
        val docRef = db.collection("users")
            .document(uid)
            .collection("saved_analyses")
            .document(docId)

        return try {
            docRef.set(analysis.toCreatePayload(uid)).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteSavedAnalysis(analysisId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = db.collection("users")
            .document(uid)
            .collection("saved_analyses")
            .document(analysisId)

        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun savePortfolioHolding(holding: PortfolioHolding): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanSymbol = holding.symbol.trim().uppercase()
        require(cleanSymbol.isNotBlank()) { "رمز السهم مطلوب" }
        require(holding.sharesCount > 0.0) { "عدد الأسهم يجب أن يكون أكبر من صفر" }
        require(holding.buyPrice > 0.0) { "سعر الشراء يجب أن يكون أكبر من صفر" }

        val docRef = db.collection("users")
            .document(uid)
            .collection("portfolio")
            .document(cleanSymbol)

        return try {
            val payload = holding.copy(symbol = cleanSymbol).toCreatePayload(uid)
            docRef.set(payload).await()
            Result.success(cleanSymbol)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun removePortfolioHolding(symbol: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanSymbol = symbol.trim().uppercase()
        val docRef = db.collection("users")
            .document(uid)
            .collection("portfolio")
            .document(cleanSymbol)

        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }
}
