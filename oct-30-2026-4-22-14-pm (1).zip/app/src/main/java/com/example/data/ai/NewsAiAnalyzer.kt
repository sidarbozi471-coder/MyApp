package com.example.data.ai

import android.util.Log
import com.example.data.model.AiNewsAnalysisResult
import com.example.data.model.CompanyDailyHighlight
import com.example.data.model.CompanyNewsItem
import com.example.data.model.DailyWatchlistSummary
import com.example.data.model.NewsSentiment
import com.example.data.model.StockQuote
import com.example.data.model.UsStockCatalog
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.Locale

private const val TAG = "NewsAiAnalyzer"

class NewsAiAnalyzer {

    private val analysisSchema = Schema.obj(
        properties = mapOf(
            "sentiment" to Schema.enumeration(
                values = listOf("POSITIVE", "NEGATIVE", "NEUTRAL"),
                description = "Overall financial sentiment of the news for the company stock: POSITIVE, NEGATIVE, or NEUTRAL"
            ),
            "confidenceScore" to Schema.integer(
                description = "Confidence score between 0 and 100"
            ),
            "arabicHeadline" to Schema.string(
                description = "Accurate, professional Arabic financial translation of the original news headline"
            ),
            "arabicSummary" to Schema.string(
                description = "Clear Arabic summary (2-3 sentences) strictly based on the provided news headline and summary without inventing any numbers or facts"
            ),
            "marketImpact" to Schema.string(
                description = "Analytical explanation in Arabic of why this news is classified as positive, negative, or neutral for the stock"
            ),
            "keyDrivers" to Schema.array(
                items = Schema.string(description = "Key point in Arabic"),
                description = "2 to 3 concise bullet points in Arabic highlighting the main catalysts or risks mentioned in the news"
            )
        )
    )

    private val dailySummarySchema = Schema.obj(
        properties = mapOf(
            "overallSentiment" to Schema.enumeration(
                values = listOf("POSITIVE", "NEGATIVE", "NEUTRAL"),
                description = "Overall sentiment across the user's favorite stocks news today"
            ),
            "welcomeHeadline" to Schema.string(
                description = "Concise, welcoming Arabic headline for today's watchlist briefing (max 12 words)"
            ),
            "executiveSummary" to Schema.string(
                description = "Comprehensive Arabic summary (2-4 sentences) synthesizing the most important verified news across the user's favorite companies without inventing any facts or prices"
            ),
            "keyMarketTakeaway" to Schema.string(
                description = "One actionable analytical takeaway in Arabic summarizing the dominant theme or catalyst today"
            ),
            "companyHighlights" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "symbol" to Schema.string(description = "Stock ticker symbol (e.g. NVDA, AAPL)"),
                        "sentiment" to Schema.enumeration(
                            values = listOf("POSITIVE", "NEGATIVE", "NEUTRAL"),
                            description = "Sentiment for this company's news today"
                        ),
                        "summary" to Schema.string(
                            description = "Concise 1-sentence Arabic summary of this company's key news item"
                        ),
                        "source" to Schema.string(
                            description = "Original verified news source name from the provided input"
                        )
                    )
                ),
                description = "Per-company news highlights for the favorite stocks that have news"
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = analysisSchema
            }
        )
    }

    private val dailySummaryModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = dailySummarySchema
            }
        )
    }

    suspend fun analyzeNewsItem(newsItem: CompanyNewsItem): Result<AiNewsAnalysisResult> {
        val prompt = buildString {
            appendLine("أنت محلل مالي محترف متخصص في سوق الأسهم الأمريكية (Wall Street).")
            appendLine("قم بتحليل الخبر الحقيقي التالي بدقة وموضوعية تامة دون اختلاق أي أرقام أو معلومات غير واردة في النص:")
            appendLine("رمز السهم: ${newsItem.symbol}")
            appendLine("المصدر: ${newsItem.source}")
            appendLine("عنوان الخبر الأصلي: ${newsItem.headline}")
            if (newsItem.summary.isNotBlank()) {
                appendLine("ملخص الخبر الأصلي: ${newsItem.summary}")
            }
            appendLine()
            appendLine("المطلوب في مخرجات JSON:")
            appendLine("1. تصنيف الخبر (sentiment) إلى POSITIVE (إيجابي) أو NEGATIVE (سلبي) أو NEUTRAL (محايد) بناءً على أثره المالي على السهم.")
            appendLine("2. درجة الثقة في التصنيف (confidenceScore) من 0 إلى 100.")
            appendLine("3. ترجمة احترافية لعنوان الخبر إلى العربية (arabicHeadline).")
            appendLine("4. ملخص دقيق باللغة العربية لما ورد في الخبر فقط (arabicSummary).")
            appendLine("5. تحليل التأثير المتوقع على السهم وأسباب هذا التصنيف باللغة العربية (marketImpact).")
            appendLine("6. أهم النقاط المحورية في الخبر (keyDrivers).")
        }

        return try {
            val response = withTimeout(60_000L) {
                model.generateContent(prompt)
            }
            val jsonString = response.text
                ?: return Result.failure(IllegalStateException("لم يُرجع نموذج الذكاء الاصطناعي استجابة نصية."))

            val json = JSONObject(jsonString)
            val sentimentCode = json.optString("sentiment", "NEUTRAL")
            val confidence = json.optInt("confidenceScore", 80).coerceIn(0, 100)
            val arabicHeadline = json.optString("arabicHeadline", newsItem.headline)
            val arabicSummary = json.optString("arabicSummary", "")
            val marketImpact = json.optString("marketImpact", "")
            val driversArray = json.optJSONArray("keyDrivers")
            val keyDrivers = mutableListOf<String>()
            if (driversArray != null) {
                for (i in 0 until driversArray.length()) {
                    val item = driversArray.optString(i).trim()
                    if (item.isNotEmpty()) keyDrivers.add(item)
                }
            }

            if (arabicSummary.isBlank() || marketImpact.isBlank()) {
                return Result.failure(IllegalStateException("استجابة التحليل غير مكتملة."))
            }

            Result.success(
                AiNewsAnalysisResult(
                    sentiment = NewsSentiment.fromCode(sentimentCode),
                    confidenceScore = confidence,
                    arabicHeadline = arabicHeadline,
                    arabicSummary = arabicSummary,
                    marketImpact = marketImpact,
                    keyDrivers = keyDrivers
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI news analysis timed out after 60 seconds", e)
            Result.failure(Exception("انتهت مهلة تحليل الخبر بالذكاء الاصطناعي (60 ثانية). يرجى المحاولة مرة أخرى."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI news analysis failed", e)
            Result.failure(Exception(e.localizedMessage ?: "تعذر إجراء تحليل الذكاء الاصطناعي للخبر حالياً."))
        }
    }

    suspend fun generateDailyWatchlistSummary(
        targetSymbols: List<String>,
        newsItems: List<CompanyNewsItem>,
        quotes: Map<String, StockQuote>
    ): Result<DailyWatchlistSummary> {
        val normalizedSymbols = targetSymbols.map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct()
        val relevantNews = newsItems
            .filter { normalizedSymbols.contains(it.symbol.uppercase()) }
            .sortedByDescending { it.publishedAtMillis }
            .take(12)

        if (relevantNews.isEmpty()) {
            return Result.failure(IllegalStateException("لا تتوفر أخبار منشورة حالياً من المصادر المعتمدة للشركات المحددة."))
        }

        val prompt = buildString {
            appendLine("أنت كبير المحللين الماليين في تطبيق 'نبض الأسهم الأمريكية'.")
            appendLine("قم بإعداد 'ملخص اليوم' باللغة العربية لأهم أخبار الشركات في القائمة المفضلة للمستخدم، بالاعتماد حصرياً على الأخبار الحقيقية والأسعار المرفقة أدناه دون اختلاق أي أخبار أو أسعار أو توقعات غير مسندة:")
            appendLine()
            appendLine("الشركات المستهدفة: ${normalizedSymbols.joinToString(", ")}")
            appendLine()
            appendLine("الأسعار الحية المسجلة حالياً (للسياق الواقعي فقط):")
            normalizedSymbols.forEach { sym ->
                val quote = quotes[sym]
                if (quote != null) {
                    val sign = if (quote.change >= 0) "+" else ""
                    appendLine(
                        String.format(
                            Locale.US,
                            "- %s (%s): $%.2f (%s%.2f%%)",
                            sym,
                            quote.arabicName,
                            quote.currentPrice,
                            sign,
                            quote.changePercent
                        )
                    )
                }
            }
            appendLine()
            appendLine("الأخبار الحقيقية الواردة اليوم من المصادر:")
            relevantNews.forEachIndexed { index, item ->
                appendLine("${index + 1}. [${item.symbol}] المصدر: ${item.source}")
                appendLine("   العنوان: ${item.headline}")
                if (item.summary.isNotBlank()) {
                    appendLine("   التفاصيل: ${item.summary.take(350)}")
                }
            }
            appendLine()
            appendLine("المطلوب في مخرجات JSON:")
            appendLine("- overallSentiment: الاتجاه العام لأخبار القائمة المفضلة اليوم (POSITIVE أو NEGATIVE أو NEUTRAL).")
            appendLine("- welcomeHeadline: عنوان ترحيبي موجز واحترافي لملخص اليوم باللغة العربية.")
            appendLine("- executiveSummary: فقرة موجزة (2-4 جمل) تلخص أهم التطورات والأخبار الجوهرية للشركات المفضلة بدقة.")
            appendLine("- keyMarketTakeaway: خلاصة تحليلية سريعة (جملة واحدة) توضح أبرز محرك للسوق أو لأسهم المفضلة اليوم.")
            appendLine("- companyHighlights: قائمة بأهم نقطة لكل شركة وردت لها أخبار، مع رمز السهم (symbol) والاتجاه (sentiment) وملخص من جملة واحدة (summary) واسم المصدر الحقيقي (source).")
        }

        return try {
            val response = withTimeout(60_000L) {
                dailySummaryModel.generateContent(prompt)
            }
            val jsonString = response.text
                ?: return Result.failure(IllegalStateException("لم يُرجع نموذج Gemini استجابة لملخص اليوم."))

            val json = JSONObject(jsonString)
            val overallSentiment = NewsSentiment.fromCode(json.optString("overallSentiment", "NEUTRAL"))
            val welcomeHeadline = json.optString("welcomeHeadline", "ملخص اليوم لأخبار شركاتك المفضلة")
            val executiveSummary = json.optString("executiveSummary", "")
            val keyMarketTakeaway = json.optString("keyMarketTakeaway", "")

            val highlightsArray = json.optJSONArray("companyHighlights")
            val highlights = mutableListOf<CompanyDailyHighlight>()
            if (highlightsArray != null) {
                for (i in 0 until highlightsArray.length()) {
                    val itemObj = highlightsArray.optJSONObject(i) ?: continue
                    val sym = itemObj.optString("symbol", "").trim().uppercase()
                    val summaryText = itemObj.optString("summary", "").trim()
                    if (sym.isNotEmpty() && summaryText.isNotEmpty()) {
                        val curated = UsStockCatalog.findBySymbol(sym)
                        highlights.add(
                            CompanyDailyHighlight(
                                symbol = sym,
                                arabicName = curated?.arabicName ?: sym,
                                sentiment = NewsSentiment.fromCode(itemObj.optString("sentiment", "NEUTRAL")),
                                summary = summaryText,
                                source = itemObj.optString("source", "مصدر مالي معتمد")
                            )
                        )
                    }
                }
            }

            if (executiveSummary.isBlank()) {
                return Result.failure(IllegalStateException("استجابة ملخص اليوم غير مكتملة."))
            }

            Result.success(
                DailyWatchlistSummary(
                    overallSentiment = overallSentiment,
                    welcomeHeadline = welcomeHeadline,
                    executiveSummary = executiveSummary,
                    keyMarketTakeaway = keyMarketTakeaway,
                    companyHighlights = highlights,
                    watchlistSymbols = normalizedSymbols,
                    articlesCount = relevantNews.size,
                    generatedAtMillis = System.currentTimeMillis()
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini daily summary timed out after 60 seconds", e)
            Result.failure(Exception("انتهت مهلة توليد ملخص اليوم (60 ثانية). يرجى المحاولة مرة أخرى."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini daily summary generation failed", e)
            Result.failure(Exception(e.localizedMessage ?: "تعذر توليد ملخص اليوم باستخدام Gemini حالياً."))
        }
    }
}
