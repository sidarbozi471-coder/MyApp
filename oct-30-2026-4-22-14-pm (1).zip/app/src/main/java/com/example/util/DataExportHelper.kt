package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import com.example.data.model.PortfolioHolding
import com.example.data.model.PriceAlert
import com.example.data.model.SavedNewsAnalysis
import com.example.data.model.StockQuote
import com.example.data.model.WatchlistStock
import com.example.ui.components.formatExactDateTime
import com.example.ui.components.formatUsdPrice
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class ExportDataFormat(
    val arabicTitle: String,
    val subtitle: String,
    val mimeType: String
) {
    ARABIC_REPORT(
        arabicTitle = "تقرير مالي شامل (نص منسق بالعربية)",
        subtitle = "مناسب للمشاركة الفورية أو الحفظ كمذكرة مالية",
        mimeType = "text/plain"
    ),
    CSV(
        arabicTitle = "جدول بيانات CSV (Excel / Google Sheets)",
        subtitle = "لتصدير المحفظة والمفضلة والتنبيهات إلى جداول البيانات",
        mimeType = "text/csv"
    ),
    JSON(
        arabicTitle = "بيانات مهيكلة (JSON Backup)",
        subtitle = "نسخة احتياطية كاملة لجميع بيانات حسابك وأسعار الأسهم",
        mimeType = "application/json"
    )
}

object DataExportHelper {

    fun buildExportContent(
        format: ExportDataFormat,
        portfolio: List<PortfolioHolding>,
        watchlist: List<WatchlistStock>,
        alerts: List<PriceAlert>,
        savedAnalyses: List<SavedNewsAnalysis>,
        quotes: Map<String, StockQuote>
    ): String {
        return when (format) {
            ExportDataFormat.ARABIC_REPORT -> buildArabicSummaryReport(
                portfolio = portfolio,
                watchlist = watchlist,
                alerts = alerts,
                savedAnalyses = savedAnalyses,
                quotes = quotes
            )
            ExportDataFormat.CSV -> buildCsvExport(
                portfolio = portfolio,
                watchlist = watchlist,
                alerts = alerts,
                quotes = quotes
            )
            ExportDataFormat.JSON -> buildJsonExport(
                portfolio = portfolio,
                watchlist = watchlist,
                alerts = alerts,
                savedAnalyses = savedAnalyses,
                quotes = quotes
            )
        }
    }

    private fun buildArabicSummaryReport(
        portfolio: List<PortfolioHolding>,
        watchlist: List<WatchlistStock>,
        alerts: List<PriceAlert>,
        savedAnalyses: List<SavedNewsAnalysis>,
        quotes: Map<String, StockQuote>
    ): String {
        val nowMillis = System.currentTimeMillis()
        val sb = StringBuilder()
        sb.appendLine("==========================================")
        sb.appendLine("تقرير نبض الأسهم الأمريكية (تصدير البيانات)")
        sb.appendLine("تاريخ التصدير: ${formatExactDateTime(nowMillis)}")
        sb.appendLine("==========================================")
        sb.appendLine()

        // 1. Portfolio Section
        sb.appendLine("أولاً: المحفظة الافتراضية (${portfolio.size} مراكز):")
        if (portfolio.isEmpty()) {
            sb.appendLine("- لا توجد أسهم مسجلة في المحفظة حالياً.")
        } else {
            var totalCost = 0.0
            var totalValue = 0.0
            portfolio.forEach { h ->
                val quote = quotes[h.symbol.uppercase()]
                val livePrice = quote?.currentPrice
                val cost = h.totalCostBasis
                val currentVal = h.marketValue(livePrice) ?: cost
                val pnl = h.profitLossUsd(livePrice) ?: 0.0
                val pnlPct = h.profitLossPercent(livePrice) ?: 0.0
                totalCost += cost
                totalValue += currentVal

                val sign = if (pnl > 0) "+" else ""
                sb.appendLine(
                    "• ${h.symbol} (${h.arabicName ?: h.companyName}): " +
                        "${String.format(Locale.US, "%.2f", h.sharesCount)} سهم × سعر شراء ${formatUsdPrice(h.buyPrice)} | " +
                        "السعر الحالي: ${livePrice?.let { formatUsdPrice(it) } ?: "غير متاح"} | " +
                        "الربح/الخسارة: $sign${formatUsdPrice(pnl)} ($sign${String.format(Locale.US, "%.2f%%", pnlPct)})"
                )
            }
            val totalPnl = totalValue - totalCost
            val totalPnlSign = if (totalPnl > 0) "+" else ""
            sb.appendLine("-> إجمالي تكلفة الشراء: ${formatUsdPrice(totalCost)}")
            sb.appendLine("-> إجمالي القيمة السوقية الحالية: ${formatUsdPrice(totalValue)}")
            sb.appendLine("-> صافي الربح/الخسارة الكلي: $totalPnlSign${formatUsdPrice(totalPnl)}")
        }
        sb.appendLine()

        // 2. Watchlist Section
        sb.appendLine("ثانياً: قائمة الأسهم المفضلة (${watchlist.size} أسهم):")
        if (watchlist.isEmpty()) {
            sb.appendLine("- القائمة المفضلة فارغة.")
        } else {
            watchlist.forEach { w ->
                val quote = quotes[w.symbol.uppercase()]
                val priceStr = quote?.let {
                    val sign = if (it.change > 0) "+" else ""
                    "${formatUsdPrice(it.currentPrice)} ($sign${String.format(Locale.US, "%.2f%%", it.changePercent)})"
                } ?: "بانتظار التحديث"
                sb.appendLine("• ${w.symbol} (${w.arabicName ?: w.companyName}) - السعر: $priceStr")
            }
        }
        sb.appendLine()

        // 3. Price Alerts Section
        sb.appendLine("ثالثاً: التنبيهات السعرية المخصصة (${alerts.size} تنبيهات):")
        if (alerts.isEmpty()) {
            sb.appendLine("- لا توجد تنبيهات سعرية مسجلة.")
        } else {
            alerts.forEach { a ->
                val status = when {
                    a.isTriggered -> "تم الوصول للهدف"
                    a.isEnabled -> "نشط"
                    else -> "متوقف"
                }
                sb.appendLine(
                    "• ${a.symbol}: ${a.conditionEnum.arabicLabel} ${formatUsdPrice(a.targetPrice)} [$status]"
                )
            }
        }
        sb.appendLine()

        // 4. Saved News Analyses
        sb.appendLine("رابعاً: تحليلات الأخبار المحفوظة (${savedAnalyses.size} تحليلات):")
        if (savedAnalyses.isEmpty()) {
            sb.appendLine("- لا توجد تحليلات أخبار محفوظة.")
        } else {
            savedAnalyses.take(10).forEach { n ->
                sb.appendLine("• [${n.symbol}] (${n.sentimentEnum.arabicLabel}) ${n.headline}")
                sb.appendLine("  الملخص: ${n.arabicSummary}")
            }
        }

        return sb.toString().trim()
    }

    private fun buildCsvExport(
        portfolio: List<PortfolioHolding>,
        watchlist: List<WatchlistStock>,
        alerts: List<PriceAlert>,
        quotes: Map<String, StockQuote>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("Category,Symbol,CompanyName,ArabicName,Shares,BuyPriceUSD,CurrentPriceUSD,ChangePercent,TotalCostUSD,MarketValueUSD,ProfitLossUSD,AlertTargetUSD,AlertCondition,Notes")

        portfolio.forEach { h ->
            val q = quotes[h.symbol.uppercase()]
            val live = q?.currentPrice
            val chgPct = q?.changePercent
            val mktVal = h.marketValue(live)
            val pnl = h.profitLossUsd(live)
            sb.appendLine(
                listOf(
                    "PORTFOLIO",
                    csvEscape(h.symbol),
                    csvEscape(h.companyName),
                    csvEscape(h.arabicName.orEmpty()),
                    String.format(Locale.US, "%.4f", h.sharesCount),
                    String.format(Locale.US, "%.2f", h.buyPrice),
                    live?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    chgPct?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    String.format(Locale.US, "%.2f", h.totalCostBasis),
                    mktVal?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    pnl?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    "",
                    "",
                    csvEscape(h.notes.orEmpty())
                ).joinToString(",")
            )
        }

        watchlist.forEach { w ->
            val q = quotes[w.symbol.uppercase()]
            sb.appendLine(
                listOf(
                    "WATCHLIST",
                    csvEscape(w.symbol),
                    csvEscape(w.companyName),
                    csvEscape(w.arabicName.orEmpty()),
                    "",
                    "",
                    q?.currentPrice?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    q?.changePercent?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    "",
                    "",
                    "",
                    w.targetPrice?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    "",
                    csvEscape(w.notes.orEmpty())
                ).joinToString(",")
            )
        }

        alerts.forEach { a ->
            val q = quotes[a.symbol.uppercase()]
            sb.appendLine(
                listOf(
                    "PRICE_ALERT",
                    csvEscape(a.symbol),
                    csvEscape(a.companyName),
                    csvEscape(a.arabicName.orEmpty()),
                    "",
                    "",
                    q?.currentPrice?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    q?.changePercent?.let { String.format(Locale.US, "%.2f", it) }.orEmpty(),
                    "",
                    "",
                    "",
                    String.format(Locale.US, "%.2f", a.targetPrice),
                    a.condition,
                    csvEscape(a.note.orEmpty())
                ).joinToString(",")
            )
        }

        return sb.toString().trim()
    }

    private fun buildJsonExport(
        portfolio: List<PortfolioHolding>,
        watchlist: List<WatchlistStock>,
        alerts: List<PriceAlert>,
        savedAnalyses: List<SavedNewsAnalysis>,
        quotes: Map<String, StockQuote>
    ): String {
        val root = JSONObject()
        root.put("exportedAtMillis", System.currentTimeMillis())
        root.put("exportedAtFormatted", formatExactDateTime(System.currentTimeMillis()))

        val portfolioArray = JSONArray()
        portfolio.forEach { h ->
            val q = quotes[h.symbol.uppercase()]
            val live = q?.currentPrice
            val obj = JSONObject().apply {
                put("symbol", h.symbol)
                put("companyName", h.companyName)
                put("arabicName", h.arabicName ?: "")
                put("sharesCount", h.sharesCount)
                put("buyPriceUsd", h.buyPrice)
                put("totalCostBasisUsd", h.totalCostBasis)
                if (live != null) {
                    put("currentPriceUsd", live)
                    put("marketValueUsd", h.marketValue(live))
                    put("profitLossUsd", h.profitLossUsd(live))
                    put("profitLossPercent", h.profitLossPercent(live))
                }
                put("notes", h.notes ?: "")
            }
            portfolioArray.put(obj)
        }
        root.put("portfolio", portfolioArray)

        val watchlistArray = JSONArray()
        watchlist.forEach { w ->
            val q = quotes[w.symbol.uppercase()]
            val obj = JSONObject().apply {
                put("symbol", w.symbol)
                put("companyName", w.companyName)
                put("arabicName", w.arabicName ?: "")
                put("sector", w.sector ?: "")
                if (q != null) {
                    put("currentPriceUsd", q.currentPrice)
                    put("changePercent", q.changePercent)
                }
                put("targetPriceUsd", w.targetPrice)
                put("notes", w.notes ?: "")
            }
            watchlistArray.put(obj)
        }
        root.put("watchlist", watchlistArray)

        val alertsArray = JSONArray()
        alerts.forEach { a ->
            val obj = JSONObject().apply {
                put("symbol", a.symbol)
                put("companyName", a.companyName)
                put("targetPriceUsd", a.targetPrice)
                put("condition", a.condition)
                put("isEnabled", a.isEnabled)
                put("isTriggered", a.isTriggered)
                put("note", a.note ?: "")
            }
            alertsArray.put(obj)
        }
        root.put("priceAlerts", alertsArray)

        val analysesArray = JSONArray()
        savedAnalyses.forEach { s ->
            val obj = JSONObject().apply {
                put("symbol", s.symbol)
                put("headline", s.headline)
                put("source", s.source)
                put("sentiment", s.sentiment)
                put("arabicSummary", s.arabicSummary)
                put("marketImpact", s.marketImpact)
                put("articleUrl", s.articleUrl)
            }
            analysesArray.put(obj)
        }
        root.put("savedNewsAnalyses", analysesArray)

        return root.toString(2)
    }

    private fun csvEscape(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return if (clean.contains(",") || clean.contains("\n") || clean.contains("\"")) {
            "\"$clean\""
        } else {
            clean
        }
    }

    fun copyToClipboard(context: Context, text: String, label: String = "StockPulse Export") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    fun shareExportText(context: Context, content: String, format: ExportDataFormat) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "تصدير بيانات نبض الأسهم الأمريكية - ${format.arabicTitle}")
            putExtra(Intent.EXTRA_TEXT, content)
        }
        val chooser = Intent.createChooser(sendIntent, "تصدير ومشاركة البيانات (${format.arabicTitle})")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(chooser)
        } catch (ignored: Exception) {
        }
    }
}
