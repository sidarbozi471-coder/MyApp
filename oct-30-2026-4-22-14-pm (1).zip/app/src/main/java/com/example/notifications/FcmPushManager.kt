package com.example.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.tasks.await

private const val TAG = "FcmPushManager"
private const val GLOBAL_ALERTS_TOPIC = "stock_price_alerts"

data class FcmSubscriptionState(
    val fcmToken: String? = null,
    val subscribedTopics: Set<String> = emptySet(),
    val isSyncing: Boolean = false,
    val isConnected: Boolean = false
) {
    val tokenPreview: String
        get() = fcmToken?.takeIf { it.length >= 10 }?.let { "${it.take(10)}..." } ?: "قيد التهيئة"
}

object FcmPushManager {

    private val _state = MutableStateFlow(FcmSubscriptionState())
    val state: StateFlow<FcmSubscriptionState> = _state.asStateFlow()

    fun topicForSymbol(symbol: String): String {
        val clean = symbol.trim().uppercase().replace(Regex("[^A-Z0-9_\\-.]"), "_")
        return "stock_alert_$clean"
    }

    fun onNewTokenReceived(token: String) {
        _state.update {
            it.copy(
                fcmToken = token,
                isConnected = token.isNotBlank()
            )
        }
    }

    suspend fun initializeAndFetchToken(): String? {
        _state.update { it.copy(isSyncing = true) }
        return try {
            val messaging = FirebaseMessaging.getInstance()
            messaging.isAutoInitEnabled = true
            val token = messaging.token.await()
            messaging.subscribeToTopic(GLOBAL_ALERTS_TOPIC).await()
            _state.update { current ->
                current.copy(
                    fcmToken = token,
                    subscribedTopics = current.subscribedTopics + GLOBAL_ALERTS_TOPIC,
                    isSyncing = false,
                    isConnected = token.isNotBlank()
                )
            }
            token
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "FCM token initialization encountered non-fatal error", e)
            _state.update { it.copy(isSyncing = false) }
            null
        }
    }

    suspend fun syncStockAlertTopics(activeSymbols: Set<String>) {
        _state.update { it.copy(isSyncing = true) }
        try {
            val messaging = FirebaseMessaging.getInstance()
            if (_state.value.fcmToken.isNullOrBlank()) {
                runCatching {
                    val token = messaging.token.await()
                    _state.update { it.copy(fcmToken = token, isConnected = token.isNotBlank()) }
                }
            }

            val desiredSymbolTopics = activeSymbols
                .map { it.trim().uppercase() }
                .filter { it.isNotBlank() }
                .map { topicForSymbol(it) }
                .toSet()

            val currentSymbolTopics = _state.value.subscribedTopics
                .filter { it.startsWith("stock_alert_") }
                .toSet()

            val toSubscribe = desiredSymbolTopics - currentSymbolTopics
            val toUnsubscribe = currentSymbolTopics - desiredSymbolTopics

            for (topic in toSubscribe) {
                runCatching {
                    messaging.subscribeToTopic(topic).await()
                    Log.i(TAG, "Subscribed to FCM topic: $topic")
                }
            }

            for (topic in toUnsubscribe) {
                runCatching {
                    messaging.unsubscribeFromTopic(topic).await()
                    Log.i(TAG, "Unsubscribed from FCM topic: $topic")
                }
            }

            val finalTopics = setOf(GLOBAL_ALERTS_TOPIC) + desiredSymbolTopics
            _state.update {
                it.copy(
                    subscribedTopics = finalTopics,
                    isSyncing = false,
                    isConnected = !it.fcmToken.isNullOrBlank() || finalTopics.isNotEmpty()
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Error syncing FCM stock alert topics", e)
            _state.update { it.copy(isSyncing = false) }
        }
    }
}
