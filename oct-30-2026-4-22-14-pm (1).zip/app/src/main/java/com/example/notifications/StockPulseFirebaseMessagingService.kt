package com.example.notifications

import android.util.Log
import com.example.data.model.PriceAlert
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

private const val TAG = "StockPulseFCMService"

class StockPulseFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i(TAG, "FCM registration token updated: ${token.take(12)}...")
        FcmPushManager.onNewTokenReceived(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.i(TAG, "FCM message received from: ${remoteMessage.from}")

        val data = remoteMessage.data
        val symbol = data["symbol"]?.trim()?.uppercase()
        val targetPrice = data["targetPrice"]?.toDoubleOrNull()
        val currentPrice = data["currentPrice"]?.toDoubleOrNull()

        if (!symbol.isNullOrBlank() && targetPrice != null && targetPrice > 0.0 && currentPrice != null && currentPrice > 0.0) {
            val alert = PriceAlert(
                id = data["alertId"] ?: "fcm_${symbol}_${System.currentTimeMillis()}",
                symbol = symbol,
                companyName = data["companyName"] ?: symbol,
                arabicName = data["arabicName"],
                targetPrice = targetPrice,
                condition = data["condition"] ?: "ABOVE",
                note = data["note"],
                isEnabled = false,
                isTriggered = true,
                triggeredPrice = currentPrice
            )
            PriceAlertNotificationHelper.sendPriceAlertNotification(
                context = applicationContext,
                alert = alert,
                currentPrice = currentPrice
            )
            return
        }

        val notification = remoteMessage.notification
        val title = data["title"]
            ?: notification?.title
            ?: if (!symbol.isNullOrBlank()) "تنبيه سعر السهم: $symbol" else "تنبيه نبض الأسهم الأمريكية"
        val body = data["body"]
            ?: notification?.body
            ?: "وصل السهم إلى الحد السعري المحدد في التنبيهات."

        PriceAlertNotificationHelper.sendFcmRemoteAlertNotification(
            context = applicationContext,
            title = title,
            body = body,
            symbol = symbol
        )
    }
}
