package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.AlertCondition
import com.example.data.model.PriceAlert
import java.util.Locale

private const val TAG = "PriceAlertNotifier"
private const val CHANNEL_ID = "stock_price_alerts_channel"
private const val CHANNEL_NAME = "تنبيهات أسعار الأسهم"
private const val CHANNEL_DESC = "إشعارات فورية عند وصول أسعار الأسهم الأمريكية إلى الحدود السعرية المحددة"

object PriceAlertNotificationHelper {

    fun ensureChannelCreated(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CHANNEL_DESC
                    enableVibration(true)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun sendPriceAlertNotification(
        context: Context,
        alert: PriceAlert,
        currentPrice: Double
    ): Boolean {
        ensureChannelCreated(context)

        if (!hasNotificationPermission(context)) {
            Log.w(TAG, "POST_NOTIFICATIONS permission not granted; skipping system notification for ${alert.symbol}")
            return false
        }

        val conditionEnum = alert.conditionEnum
        val directionLabel = when (conditionEnum) {
            AlertCondition.ABOVE -> "تجاوز المستوى المستهدف صعوداً (≥)"
            AlertCondition.BELOW -> "وصل إلى المستوى المستهدف هبوطاً (≤)"
        }
        val formattedTarget = String.format(Locale.US, "$%,.2f", alert.targetPrice)
        val formattedCurrent = String.format(Locale.US, "$%,.2f", currentPrice)
        val displayCompany = alert.arabicName?.takeIf { it.isNotBlank() } ?: alert.companyName

        val title = "تنبيه سعر السهم: ${alert.symbol} ($displayCompany)"
        val body = buildString {
            append("$directionLabel $formattedTarget • السعر الحالي الآن: $formattedCurrent")
            if (!alert.note.isNullOrBlank()) {
                append("\nملاحظتك: ${alert.note}")
            }
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            alert.id.hashCode(),
            launchIntent,
            pendingIntentFlags
        )

        val fcmTopic = "stock_alert_${alert.symbol.trim().uppercase()}"
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setSubText("FCM • $fcmTopic")
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(alert.id.hashCode(), notification)
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException sending price alert notification", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to post price alert notification", e)
            false
        }
    }

    fun sendFcmRemoteAlertNotification(
        context: Context,
        title: String,
        body: String,
        symbol: String?,
        notificationId: Int = System.currentTimeMillis().toInt()
    ): Boolean {
        ensureChannelCreated(context)
        if (!hasNotificationPermission(context)) {
            Log.w(TAG, "POST_NOTIFICATIONS permission not granted; skipping FCM remote notification")
            return false
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (!symbol.isNullOrBlank()) {
                putExtra("alert_symbol", symbol)
            }
        }
        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            launchIntent,
            pendingIntentFlags
        )

        val subText = if (!symbol.isNullOrBlank()) {
            "Firebase Messaging • stock_alert_${symbol.uppercase()}"
        } else {
            "Firebase Messaging • تنبيهات الأسعار"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setSubText(subText)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException sending FCM notification", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to post FCM notification", e)
            false
        }
    }
}
