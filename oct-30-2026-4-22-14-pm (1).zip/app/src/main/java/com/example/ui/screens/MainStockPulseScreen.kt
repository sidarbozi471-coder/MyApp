package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.auth.signOut
import com.example.data.ai.NewsAiAnalyzer
import com.example.data.model.AlertCondition
import com.example.data.model.CompanyNewsItem
import com.example.data.model.NewsSentiment
import com.example.data.model.PriceAlert
import com.example.data.model.SavedNewsAnalysis
import com.example.data.model.StockQuote
import com.example.data.model.UsStockCatalog
import com.example.data.model.WatchlistStock
import com.example.data.remote.MarketDataRepository
import com.example.data.repository.WatchlistRepository
import com.example.notifications.FcmPushManager
import com.example.notifications.FcmSubscriptionState
import com.example.notifications.PriceAlertNotificationHelper
import com.example.ui.components.DailySummaryWelcomeCard
import com.example.ui.components.DarkModeQuickControlBar
import com.example.ui.components.CategorizedWatchlistItem
import com.example.ui.components.IntradaySparkline
import com.example.ui.components.NewsArticleCard
import com.example.ui.components.SentimentBadge
import com.example.ui.components.StockQuoteCard
import com.example.ui.components.WatchlistCategorySectionHeader
import com.example.ui.components.WatchlistPerformanceOverviewCard
import com.example.ui.components.WatchlistPerformanceTierBadge
import com.example.ui.components.WatchlistSortAndCategoryMode
import com.example.ui.components.evaluateWatchlistPerformance
import com.example.ui.components.formatExactDateTime
import com.example.ui.components.formatSignedChange
import com.example.ui.components.formatUsdPrice
import com.example.ui.theme.AppThemeSettings
import com.example.ui.theme.BearishCrimson
import com.example.ui.theme.BearishCrimsonLight
import com.example.ui.theme.BearishCrimsonSurface
import com.example.ui.theme.BullishEmerald
import com.example.ui.theme.BullishEmeraldLight
import com.example.ui.theme.BullishEmeraldSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.NeutralAmberLight
import com.example.ui.theme.NeutralAmberSurface
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState
import com.example.ui.viewmodel.MarketUiState
import com.example.ui.viewmodel.SentimentFilter
import com.example.ui.viewmodel.StockPulseViewModel
import com.example.util.DataExportHelper
import com.example.util.ExportDataFormat
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import java.util.Locale

enum class MainDestination(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    MARKET("الأسهم", Icons.AutoMirrored.Filled.ShowChart, "nav_tab_market"),
    PREDICTION("توقعات AI", Icons.Default.AutoAwesome, "nav_tab_prediction"),
    PORTFOLIO("المحفظة", Icons.Default.AccountBalanceWallet, "nav_tab_portfolio"),
    NEWS("الأخبار و AI", Icons.Default.Newspaper, "nav_tab_news"),
    WATCHLIST("المفضلة والتنبيهات", Icons.Default.Star, "nav_tab_watchlist"),
    SAVED("تحليلات محفوظة", Icons.Default.Bookmarks, "nav_tab_saved")
}

private data class NewAlertTargetStock(
    val symbol: String = "",
    val companyName: String = "",
    val arabicName: String? = null,
    val editingAlert: PriceAlert? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainStockPulseScreen(
    currentUserId: String,
    userEmail: String?
) {
    val viewModel: StockPulseViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                StockPulseViewModel(
                    watchlistRepository = WatchlistRepository(db),
                    marketDataRepository = MarketDataRepository(),
                    newsAiAnalyzer = NewsAiAnalyzer(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val watchlistState by viewModel.watchlistState.collectAsStateWithLifecycle()
    val portfolioState by viewModel.portfolioState.collectAsStateWithLifecycle()
    val priceAlertsState by viewModel.priceAlertsState.collectAsStateWithLifecycle()
    val savedAnalysesState by viewModel.savedAnalysesState.collectAsStateWithLifecycle()
    val fcmState by viewModel.fcmState.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }

    var hasNotifPermission by remember {
        mutableStateOf(PriceAlertNotificationHelper.hasNotificationPermission(context))
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotifPermission = granted
        if (!granted) {
            scope.launch {
                snackbarHostState.showSnackbar("تم حفظ التنبيه سحابياً، لكن يرجى السماح بالإشعارات لتلقي تنبيهات النظام.")
            }
        }
    }

    LaunchedEffect(Unit) {
        PriceAlertNotificationHelper.ensureChannelCreated(context)
    }

    // Dispatch local system notifications whenever a price alert threshold is reached
    LaunchedEffect(uiState.pendingAlertNotifications) {
        uiState.pendingAlertNotifications.forEach { event ->
            PriceAlertNotificationHelper.sendPriceAlertNotification(
                context = context,
                alert = event.alert,
                currentPrice = event.currentPrice
            )
            viewModel.consumeAlertNotificationEvent(event.eventId)
        }
    }

    var currentTab by rememberSaveable { mutableStateOf(MainDestination.MARKET) }
    var editingWatchlistStock by remember { mutableStateOf<WatchlistStock?>(null) }
    var portfolioDialogDraft by remember { mutableStateOf<PortfolioDialogDraft?>(null) }
    var alertDialogStock by remember { mutableStateOf<NewAlertTargetStock?>(null) }
    var showSettingsDialog by rememberSaveable { mutableStateOf(false) }
    var showExportDialog by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = uiState.selectedStockSymbol != null || currentTab != MainDestination.MARKET) {
        if (uiState.selectedStockSymbol != null) {
            viewModel.selectStockForDetails(null)
        } else {
            currentTab = MainDestination.MARKET
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        val msg = uiState.snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val favoriteSymbols = remember(watchlistState) {
        (watchlistState as? CloudUiState.Success)?.data?.map { it.symbol }?.toSet().orEmpty()
    }

    val activeAlertsBySymbol = remember(priceAlertsState) {
        (priceAlertsState as? CloudUiState.Success)?.data
            ?.filter { it.isEnabled && !it.isTriggered }
            ?.groupBy { it.symbol.uppercase() }
            .orEmpty()
    }

    val openCreateAlertDialog: (String, String, String?) -> Unit = { sym, name, arabic ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotifPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (sym.isNotBlank()) {
            viewModel.fetchQuoteForSingleSymbol(sym)
        }
        alertDialogStock = NewAlertTargetStock(sym, name, arabic, editingAlert = null)
    }

    val openEditAlertDialog: (PriceAlert) -> Unit = { alert ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotifPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        viewModel.fetchQuoteForSingleSymbol(alert.symbol)
        alertDialogStock = NewAlertTargetStock(
            symbol = alert.symbol,
            companyName = alert.companyName,
            arabicName = alert.arabicName,
            editingAlert = alert
        )
    }

    val openExternalUrl: (String) -> Unit = { url ->
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (ignored: Exception) {
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpandedScreen = maxWidth >= 700.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                containerColor = ObsidianBackground,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ObsidianSurface,
                            titleContentColor = TextPrimary
                        ),
                        title = {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "نبض الأسهم الأمريكية",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = BullishEmeraldSurface,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "LIVE",
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BullishEmeraldLight,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = if (uiState.lastQuotesRefreshMillis > 0L) {
                                        "آخر تحديث للأسعار: ${formatExactDateTime(uiState.lastQuotesRefreshMillis)}"
                                    } else {
                                        "بيانات حية من المصادر المعتمدة • لا يتم اختلاق أي أسعار أو أخبار"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    val nextDark = !AppThemeSettings.isDarkMode
                                    AppThemeSettings.setDarkMode(context, nextDark)
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (nextDark) {
                                                "تم تفعيل الوضع الليلي (Dark Mode) لراحة العين في الإضاءة المنخفضة"
                                            } else {
                                                "تم التبديل إلى الوضع النهاري الفاتح"
                                            }
                                        )
                                    }
                                },
                                modifier = Modifier.testTag("top_bar_dark_mode_toggle")
                            ) {
                                Icon(
                                    imageVector = if (AppThemeSettings.isDarkMode) {
                                        Icons.Default.DarkMode
                                    } else {
                                        Icons.Default.LightMode
                                    },
                                    contentDescription = if (AppThemeSettings.isDarkMode) {
                                        "الوضع الليلي مفعل - اضغط للتبديل للوضع النهاري"
                                    } else {
                                        "الوضع النهاري مفعل - اضغط لتفعيل الوضع الليلي"
                                    },
                                    tint = if (AppThemeSettings.isDarkMode) GoldAccent else NeutralAmber
                                )
                            }
                            IconButton(
                                onClick = {
                                    viewModel.refreshMarketQuotes()
                                    viewModel.refreshCompanyNews()
                                },
                                modifier = Modifier.testTag("refresh_all_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "تحديث البيانات الفورية",
                                    tint = ElectricCyan
                                )
                            }
                            IconButton(
                                onClick = { showExportDialog = true },
                                modifier = Modifier.testTag("top_bar_export_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.IosShare,
                                    contentDescription = "تصدير ومشاركة البيانات والتقارير (Export)",
                                    tint = GoldAccent
                                )
                            }
                            IconButton(
                                onClick = { showSettingsDialog = true },
                                modifier = Modifier.testTag("app_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "إعدادات التطبيق والوضع الليلي",
                                    tint = if (AppThemeSettings.isDarkMode) BullishEmeraldLight else TextSecondary
                                )
                            }
                            IconButton(
                                onClick = {
                                    signOut(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onSignOutComplete = {},
                                        scope = scope
                                    )
                                },
                                modifier = Modifier.testTag("sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                    contentDescription = "تسجيل الخروج",
                                    tint = TextSecondary
                                )
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!isExpandedScreen) {
                        NavigationBar(
                            containerColor = ObsidianSurface,
                            tonalElevation = 8.dp
                        ) {
                            MainDestination.entries.forEach { dest ->
                                val selected = currentTab == dest
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentTab = dest },
                                    icon = {
                                        Icon(
                                            imageVector = dest.icon,
                                            contentDescription = dest.title
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = dest.title,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF032219),
                                        selectedTextColor = BullishEmeraldLight,
                                        indicatorColor = BullishEmerald,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    ),
                                    modifier = Modifier.testTag(dest.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isExpandedScreen) {
                        NavigationRail(
                            containerColor = ObsidianSurface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            Spacer(modifier = Modifier.height(12.dp))
                            MainDestination.entries.forEach { dest ->
                                val selected = currentTab == dest
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { currentTab = dest },
                                    icon = {
                                        Icon(
                                            imageVector = dest.icon,
                                            contentDescription = dest.title
                                        )
                                    },
                                    label = { Text(dest.title) },
                                    modifier = Modifier.testTag(dest.testTag)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        when (currentTab) {
                            MainDestination.MARKET -> MarketTabContent(
                                uiState = uiState,
                                favoriteSymbols = favoriteSymbols,
                                activeAlertsBySymbol = activeAlertsBySymbol,
                                onSearchQueryChanged = viewModel::onSearchQueryChanged,
                                onToggleFavorite = { stock ->
                                    viewModel.toggleWatchlistStock(
                                        symbol = stock.symbol,
                                        companyName = stock.companyName,
                                        arabicName = stock.arabicName,
                                        sector = stock.sector
                                    )
                                },
                                onCreateAlertForStock = { stock ->
                                    openCreateAlertDialog(
                                        stock.symbol,
                                        stock.companyName,
                                        stock.arabicName
                                    )
                                },
                                onSelectStock = { symbol ->
                                    viewModel.selectStockForDetails(symbol)
                                },
                                onRetryQuotes = { viewModel.refreshMarketQuotes() },
                                onRefreshDailySummary = { viewModel.generateDailySummary(useMajorMarketFallback = false) },
                                onGenerateMarketFallbackSummary = { viewModel.generateDailySummary(useMajorMarketFallback = true) },
                                onDismissDailySummary = viewModel::dismissDailySummaryCard,
                                onReopenDailySummary = viewModel::showDailySummaryCard
                            )

                            MainDestination.NEWS -> NewsAndAiTabContent(
                                uiState = uiState,
                                favoriteSymbols = favoriteSymbols,
                                savedAnalysesState = savedAnalysesState,
                                onSelectSymbolFilter = { symbol ->
                                    viewModel.refreshCompanyNews(symbol)
                                },
                                onSelectSentimentFilter = viewModel::setSentimentFilter,
                                onBatchAnalyze = viewModel::analyzeTopUnanalyzedNews,
                                onAnalyzeSingle = viewModel::analyzeSingleNews,
                                onSaveAnalysis = viewModel::saveNewsAnalysisToCloud,
                                onOpenUrl = openExternalUrl,
                                onRetryNews = { viewModel.refreshCompanyNews() }
                            )

                            MainDestination.WATCHLIST -> WatchlistTabContent(
                                watchlistState = watchlistState,
                                priceAlertsState = priceAlertsState,
                                quotes = uiState.quotes,
                                fcmState = fcmState,
                                onSyncFcm = viewModel::syncFcmPushSubscriptions,
                                hasNotificationPermission = hasNotifPermission,
                                onRequestNotificationPermission = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                },
                                onSelectStock = { symbol ->
                                    viewModel.selectStockForDetails(symbol)
                                },
                                onEditStock = { stock ->
                                    editingWatchlistStock = stock
                                },
                                onCreateCustomAlertGeneral = {
                                    openCreateAlertDialog("", "", null)
                                },
                                onCreateAlertForStock = { stock ->
                                    openCreateAlertDialog(
                                        stock.symbol,
                                        stock.companyName,
                                        stock.arabicName
                                    )
                                },
                                onEditAlert = { alert ->
                                    openEditAlertDialog(alert)
                                },
                                onToggleAlertEnabled = viewModel::togglePriceAlertEnabled,
                                onDeleteAlert = viewModel::deletePriceAlert,
                                onRemoveStock = { stock ->
                                    viewModel.toggleWatchlistStock(
                                        symbol = stock.symbol,
                                        companyName = stock.companyName,
                                        arabicName = stock.arabicName,
                                        sector = stock.sector
                                    )
                                },
                                onExploreStocks = {
                                    currentTab = MainDestination.MARKET
                                }
                            )

                            MainDestination.PORTFOLIO -> PortfolioTabContent(
                                portfolioState = portfolioState,
                                quotes = uiState.quotes,
                                isLoadingQuotes = uiState.isLoadingQuotes,
                                onAddHoldingClick = {
                                    portfolioDialogDraft = PortfolioDialogDraft()
                                },
                                onEditHoldingClick = { holding ->
                                    portfolioDialogDraft = PortfolioDialogDraft(
                                        symbol = holding.symbol,
                                        companyName = holding.companyName,
                                        arabicName = holding.arabicName,
                                        sector = holding.sector,
                                        initialSharesCount = holding.sharesCount,
                                        initialBuyPrice = holding.buyPrice,
                                        initialNotes = holding.notes,
                                        isEditingExisting = true
                                    )
                                },
                                onDeleteHoldingClick = { symbol ->
                                    viewModel.deletePortfolioPosition(symbol)
                                },
                                onSelectStock = { symbol ->
                                    viewModel.selectStockForDetails(symbol)
                                },
                                onCreateAlertForHolding = { holding ->
                                    openCreateAlertDialog(
                                        holding.symbol,
                                        holding.companyName,
                                        holding.arabicName
                                    )
                                },
                                onRefreshQuotes = {
                                    viewModel.refreshMarketQuotes()
                                }
                            )

                            MainDestination.PREDICTION -> StockPredictionTabContent(
                                selectedSymbol = uiState.predictionSymbol,
                                selectedHorizon = uiState.predictionHorizon,
                                predictionState = uiState.predictionState,
                                favoriteSymbols = favoriteSymbols,
                                onSelectSymbol = viewModel::selectStockForPrediction,
                                onSelectHorizon = viewModel::changePredictionHorizon,
                                onRefreshPrediction = {
                                    viewModel.runStockPrediction(
                                        symbol = uiState.predictionSymbol,
                                        horizon = uiState.predictionHorizon,
                                        forceRefresh = true
                                    )
                                },
                                onOpenStockDetails = { sym ->
                                    viewModel.selectStockForDetails(sym)
                                },
                                onOpenNewsUrl = openExternalUrl
                            )

                            MainDestination.SAVED -> SavedAnalysesTabContent(
                                savedAnalysesState = savedAnalysesState,
                                onDeleteAnalysis = viewModel::deleteSavedAnalysis,
                                onOpenUrl = openExternalUrl
                            )
                        }
                    }
                }
            }

            // Stock Detail Bottom Sheet
            val selectedSymbol = uiState.selectedStockSymbol
            if (selectedSymbol != null) {
                val curated = UsStockCatalog.findBySymbol(selectedSymbol)
                val quote = uiState.quotes[selectedSymbol]
                val isFav = favoriteSymbols.contains(selectedSymbol)
                val existingPortfolioHolding = remember(portfolioState, selectedSymbol) {
                    (portfolioState as? CloudUiState.Success)?.data?.find {
                        it.symbol.equals(selectedSymbol, ignoreCase = true)
                    }
                }
                val stockNews = uiState.newsItems.filter {
                    it.symbol.equals(selectedSymbol, ignoreCase = true)
                }

                ModalBottomSheet(
                    onDismissRequest = { viewModel.selectStockForDetails(null) },
                    containerColor = ObsidianSurface,
                    contentColor = TextPrimary
                ) {
                    StockDetailSheetContent(
                        symbol = selectedSymbol,
                        companyName = quote?.companyName ?: curated?.companyName ?: selectedSymbol,
                        arabicName = quote?.arabicName ?: curated?.arabicName ?: selectedSymbol,
                        sector = quote?.sector ?: curated?.sector ?: "السوق الأمريكي",
                        quote = quote,
                        isFavorite = isFav,
                        hasPortfolioHolding = existingPortfolioHolding != null,
                        relatedNews = stockNews,
                        onToggleFavorite = {
                            viewModel.toggleWatchlistStock(
                                symbol = selectedSymbol,
                                companyName = quote?.companyName ?: curated?.companyName ?: selectedSymbol,
                                arabicName = quote?.arabicName ?: curated?.arabicName,
                                sector = quote?.sector ?: curated?.sector
                            )
                        },
                        onCreatePriceAlert = {
                            openCreateAlertDialog(
                                selectedSymbol,
                                quote?.companyName ?: curated?.companyName ?: selectedSymbol,
                                quote?.arabicName ?: curated?.arabicName
                            )
                        },
                        onAddOrEditPortfolioHolding = {
                            portfolioDialogDraft = PortfolioDialogDraft(
                                symbol = selectedSymbol,
                                companyName = quote?.companyName ?: curated?.companyName ?: selectedSymbol,
                                arabicName = quote?.arabicName ?: curated?.arabicName,
                                sector = quote?.sector ?: curated?.sector,
                                initialSharesCount = existingPortfolioHolding?.sharesCount,
                                initialBuyPrice = existingPortfolioHolding?.buyPrice ?: quote?.currentPrice,
                                initialNotes = existingPortfolioHolding?.notes,
                                isEditingExisting = existingPortfolioHolding != null
                            )
                        },
                        onViewAllCompanyNews = {
                            viewModel.selectStockForDetails(null)
                            viewModel.refreshCompanyNews(selectedSymbol)
                            currentTab = MainDestination.NEWS
                        },
                        onOpenAiPrediction = {
                            viewModel.selectStockForDetails(null)
                            viewModel.selectStockForPrediction(selectedSymbol)
                            currentTab = MainDestination.PREDICTION
                        },
                        onAnalyzeNews = viewModel::analyzeSingleNews,
                        onSaveAnalysis = viewModel::saveNewsAnalysisToCloud,
                        onOpenUrl = openExternalUrl
                    )
                }
            }

            // Edit Watchlist Notes & Target Price Dialog
            val stockToEdit = editingWatchlistStock
            if (stockToEdit != null) {
                EditWatchlistDialog(
                    stock = stockToEdit,
                    onDismiss = { editingWatchlistStock = null },
                    onConfirm = { notes, targetPrice ->
                        viewModel.updateWatchlistNotesAndTarget(
                            symbol = stockToEdit.symbol,
                            notes = notes,
                            targetPrice = targetPrice
                        )
                        editingWatchlistStock = null
                    }
                )
            }

            // Add or Edit Virtual Portfolio Holding Dialog
            val currentPortfolioDraft = portfolioDialogDraft
            if (currentPortfolioDraft != null) {
                AddOrEditPortfolioHoldingDialog(
                    draft = currentPortfolioDraft,
                    quotes = uiState.quotes,
                    onRequestQuoteForSymbol = viewModel::fetchQuoteForSingleSymbol,
                    onDismiss = { portfolioDialogDraft = null },
                    onConfirm = { sym, compName, arabName, sec, shares, buyPrice, notes ->
                        viewModel.savePortfolioPosition(
                            symbol = sym,
                            companyName = compName,
                            arabicName = arabName,
                            sector = sec,
                            sharesCount = shares,
                            buyPrice = buyPrice,
                            notes = notes
                        )
                        portfolioDialogDraft = null
                    }
                )
            }

            // Create or Edit Custom Price Alert Dialog
            val targetAlertStock = alertDialogStock
            if (targetAlertStock != null) {
                val watchlistStocks = (watchlistState as? CloudUiState.Success)?.data.orEmpty()
                CreatePriceAlertDialog(
                    initialSymbol = targetAlertStock.symbol,
                    initialCompanyName = targetAlertStock.companyName,
                    initialArabicName = targetAlertStock.arabicName,
                    editingAlert = targetAlertStock.editingAlert,
                    quotes = uiState.quotes,
                    watchlistStocks = watchlistStocks,
                    onRequestQuoteForSymbol = viewModel::fetchQuoteForSingleSymbol,
                    onDismiss = { alertDialogStock = null },
                    onConfirm = { resolvedSymbol, resolvedCompany, resolvedArabic, targetPrice, condition, note ->
                        val editing = targetAlertStock.editingAlert
                        if (editing != null) {
                            viewModel.updatePriceAlert(
                                alert = editing,
                                targetPrice = targetPrice,
                                condition = condition,
                                note = note
                            )
                        } else {
                            viewModel.createPriceAlert(
                                symbol = resolvedSymbol,
                                companyName = resolvedCompany,
                                arabicName = resolvedArabic,
                                targetPrice = targetPrice,
                                condition = condition,
                                note = note
                            )
                        }
                        alertDialogStock = null
                    }
                )
            }

            // App Settings & Dark Mode Dialog
            if (showSettingsDialog) {
                AppSettingsDialog(
                    isDarkMode = AppThemeSettings.isDarkMode,
                    isEyeCareMode = AppThemeSettings.isEyeCareNightMode,
                    isReadingBoostEnabled = AppThemeSettings.isLowLightReadingBoost,
                    userEmail = userEmail,
                    fcmConnected = fcmState.isConnected,
                    onToggleDarkMode = { enabled ->
                        AppThemeSettings.setDarkMode(context, enabled)
                    },
                    onToggleEyeCareMode = { enabled ->
                        AppThemeSettings.setEyeCareNightMode(context, enabled)
                    },
                    onToggleReadingBoost = { enabled ->
                        AppThemeSettings.setLowLightReadingBoost(context, enabled)
                    },
                    onOpenExportDialog = {
                        showSettingsDialog = false
                        showExportDialog = true
                    },
                    onDismiss = { showSettingsDialog = false }
                )
            }

            // Export Data & Financial Reports Dialog
            if (showExportDialog) {
                val portfolioList = (portfolioState as? CloudUiState.Success)?.data.orEmpty()
                val watchlistItems = (watchlistState as? CloudUiState.Success)?.data.orEmpty()
                val alertItems = (priceAlertsState as? CloudUiState.Success)?.data.orEmpty()
                val savedAnalysisItems = (savedAnalysesState as? CloudUiState.Success)?.data.orEmpty()

                ExportDataDialog(
                    portfolio = portfolioList,
                    watchlist = watchlistItems,
                    alerts = alertItems,
                    savedAnalyses = savedAnalysisItems,
                    quotes = uiState.quotes,
                    onCopySuccess = { formatTitle ->
                        scope.launch {
                            snackbarHostState.showSnackbar("تم نسخ بيانات التصدير ($formatTitle) إلى الحافظة بنجاح")
                        }
                    },
                    onDismiss = { showExportDialog = false }
                )
            }
        }
    }
}

@Composable
private fun MarketTabContent(
    uiState: MarketUiState,
    favoriteSymbols: Set<String>,
    activeAlertsBySymbol: Map<String, List<PriceAlert>>,
    onSearchQueryChanged: (String) -> Unit,
    onToggleFavorite: (com.example.data.model.CuratedUsStock) -> Unit,
    onCreateAlertForStock: (com.example.data.model.CuratedUsStock) -> Unit,
    onSelectStock: (String) -> Unit,
    onRetryQuotes: () -> Unit,
    onRefreshDailySummary: () -> Unit,
    onGenerateMarketFallbackSummary: () -> Unit,
    onDismissDailySummary: () -> Unit,
    onReopenDailySummary: () -> Unit
) {
    val context = LocalContext.current
    val loadedQuotes = uiState.quotes.values.toList()
    val gainersCount = loadedQuotes.count { it.change > 0 }
    val losersCount = loadedQuotes.count { it.change < 0 }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Quick Dark Mode & Low-Light Comfort Bar for Price Tracking
        item(key = "market_dark_mode_quick_bar") {
            DarkModeQuickControlBar(
                isDarkMode = AppThemeSettings.isDarkMode,
                isEyeCareMode = AppThemeSettings.isEyeCareNightMode,
                isReadingBoostEnabled = AppThemeSettings.isLowLightReadingBoost,
                onToggleDarkMode = { enabled ->
                    AppThemeSettings.setDarkMode(context, enabled)
                },
                onToggleEyeCareMode = { enabled ->
                    AppThemeSettings.setEyeCareNightMode(context, enabled)
                },
                onToggleReadingBoost = { enabled ->
                    AppThemeSettings.setLowLightReadingBoost(context, enabled)
                },
                contextLabel = "متابعة أسعار الأسهم الفورية بدون إجهاد للعين في الإضاءة المنخفضة"
            )
        }

        // Welcome Daily Summary Card (Gemini AI)
        item {
            DailySummaryWelcomeCard(
                dailySummaryState = uiState.dailySummaryState,
                isVisible = uiState.isDailySummaryVisible,
                onRefreshSummary = onRefreshDailySummary,
                onGenerateMarketFallback = onGenerateMarketFallbackSummary,
                onDismiss = onDismissDailySummary,
                onReopen = onReopenDailySummary,
                onSelectStock = onSelectStock
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_market_hero_banner_1793352744123),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(155.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(155.dp)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        ObsidianBackground.copy(alpha = 0.92f),
                                        ObsidianBackground.copy(alpha = 0.65f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "مؤشر نبض السوق الأمريكي",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "تحديثات مباشرة لأسعار الأسهم في NASDAQ و NYSE",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            if (uiState.isLoadingQuotes) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    strokeWidth = 2.dp,
                                    color = BullishEmeraldLight
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MarketStatPill(
                                label = "أسهم صاعدة",
                                value = "$gainersCount",
                                color = BullishEmeraldLight,
                                modifier = Modifier.weight(1f)
                            )
                            MarketStatPill(
                                label = "أسهم هابطة",
                                value = "$losersCount",
                                color = BearishCrimsonLight,
                                modifier = Modifier.weight(1f)
                            )
                            MarketStatPill(
                                label = "في المفضلة",
                                value = "${favoriteSymbols.size}",
                                color = GoldAccent,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChanged,
                placeholder = {
                    Text(
                        text = "ابحث برمز السهم أو اسم الشركة (مثال: NVDA, AAPL, تسلا)...",
                        color = TextSecondary
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "بحث",
                        tint = ElectricCyan
                    )
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "مسح البحث",
                                tint = TextSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = ObsidianCard,
                    unfocusedContainerColor = ObsidianCard,
                    focusedBorderColor = ElectricCyan,
                    unfocusedBorderColor = ObsidianBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stock_search_input")
            )
        }

        if (uiState.quotesError != null && uiState.quotes.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BearishCrimsonSurface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = uiState.quotesError,
                            style = MaterialTheme.typography.bodyMedium,
                            color = BearishCrimsonLight
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onRetryQuotes,
                            colors = ButtonDefaults.buttonColors(containerColor = BearishCrimson)
                        ) {
                            Text("إعادة المحاولة")
                        }
                    }
                }
            }
        }

        items(
            items = uiState.searchResults,
            key = { it.symbol }
        ) { stock ->
            val quote = uiState.quotes[stock.symbol]
            val isFavorite = favoriteSymbols.contains(stock.symbol)
            StockQuoteCard(
                symbol = stock.symbol,
                companyName = quote?.companyName ?: stock.companyName,
                arabicName = stock.arabicName,
                sector = stock.sector,
                quote = quote,
                isFavorite = isFavorite,
                onToggleFavorite = { onToggleFavorite(stock) },
                onClick = { onSelectStock(stock.symbol) },
                activeAlerts = activeAlertsBySymbol[stock.symbol.uppercase()].orEmpty(),
                onCreateAlertClick = { onCreateAlertForStock(stock) }
            )
        }
    }
}

@Composable
private fun MarketStatPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ObsidianCardElevated.copy(alpha = 0.85f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = color
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewsAndAiTabContent(
    uiState: MarketUiState,
    favoriteSymbols: Set<String>,
    savedAnalysesState: CloudUiState<List<SavedNewsAnalysis>>,
    onSelectSymbolFilter: (String?) -> Unit,
    onSelectSentimentFilter: (SentimentFilter) -> Unit,
    onBatchAnalyze: () -> Unit,
    onAnalyzeSingle: (String) -> Unit,
    onSaveAnalysis: (CompanyNewsItem) -> Unit,
    onOpenUrl: (String) -> Unit,
    onRetryNews: () -> Unit
) {
    val savedUrls = remember(savedAnalysesState) {
        (savedAnalysesState as? CloudUiState.Success)?.data?.map { it.articleUrl }?.toSet().orEmpty()
    }

    val filteredNews = remember(uiState.newsItems, uiState.selectedSentimentFilter) {
        when (uiState.selectedSentimentFilter) {
            SentimentFilter.ALL -> uiState.newsItems
            SentimentFilter.POSITIVE -> uiState.newsItems.filter {
                it.aiAnalysis?.sentiment == NewsSentiment.POSITIVE
            }
            SentimentFilter.NEGATIVE -> uiState.newsItems.filter {
                it.aiAnalysis?.sentiment == NewsSentiment.NEGATIVE
            }
            SentimentFilter.NEUTRAL -> uiState.newsItems.filter {
                it.aiAnalysis?.sentiment == NewsSentiment.NEUTRAL
            }
        }
    }

    val positiveCount = uiState.newsItems.count { it.aiAnalysis?.sentiment == NewsSentiment.POSITIVE }
    val negativeCount = uiState.newsItems.count { it.aiAnalysis?.sentiment == NewsSentiment.NEGATIVE }
    val neutralCount = uiState.newsItems.count { it.aiAnalysis?.sentiment == NewsSentiment.NEUTRAL }

    val context = LocalContext.current
    val quickSymbols = remember(favoriteSymbols) {
        (favoriteSymbols.toList() + listOf("NVDA", "AAPL", "MSFT", "TSLA", "GOOGL", "AMZN")).distinct()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Quick Dark Mode & Low-Light Comfort Bar for News Reading
        item(key = "news_dark_mode_quick_bar") {
            DarkModeQuickControlBar(
                isDarkMode = AppThemeSettings.isDarkMode,
                isEyeCareMode = AppThemeSettings.isEyeCareNightMode,
                isReadingBoostEnabled = AppThemeSettings.isLowLightReadingBoost,
                onToggleDarkMode = { enabled ->
                    AppThemeSettings.setDarkMode(context, enabled)
                },
                onToggleEyeCareMode = { enabled ->
                    AppThemeSettings.setEyeCareNightMode(context, enabled)
                },
                onToggleReadingBoost = { enabled ->
                    AppThemeSettings.setLowLightReadingBoost(context, enabled)
                },
                contextLabel = "قراءة مريحة للأخبار وتقارير الذكاء الاصطناعي في ظروف الإضاءة المنخفضة"
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "رادار أخبار الشركات وتحليل الذكاء الاصطناعي",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "أخبار حقيقية من المصادر المعتمدة مع تصنيفها إلى إيجابية وسلبية ومحايدة.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MarketStatPill(
                            label = "إيجابية",
                            value = "$positiveCount",
                            color = BullishEmeraldLight,
                            modifier = Modifier.weight(1f)
                        )
                        MarketStatPill(
                            label = "سلبية",
                            value = "$negativeCount",
                            color = BearishCrimsonLight,
                            modifier = Modifier.weight(1f)
                        )
                        MarketStatPill(
                            label = "محايدة",
                            value = "$neutralCount",
                            color = NeutralAmberLight,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onBatchAnalyze,
                        enabled = !uiState.isBatchAnalyzing && uiState.newsItems.isNotEmpty(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldAccent,
                            contentColor = Color(0xFF231702)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("batch_analyze_news_button")
                    ) {
                        if (uiState.isBatchAnalyzing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF231702)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جارٍ تحليل وتصنيف الأخبار بواسطة Gemini...")
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تحليل وتصنيف أحدث الأخبار بالذكاء الاصطناعي",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = uiState.selectedNewsSymbolFilter == null,
                        onClick = { onSelectSymbolFilter(null) },
                        label = { Text("جميع الشركات") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan,
                            selectedLabelColor = Color(0xFF032329)
                        )
                    )
                }
                items(quickSymbols) { sym ->
                    FilterChip(
                        selected = uiState.selectedNewsSymbolFilter == sym,
                        onClick = { onSelectSymbolFilter(sym) },
                        label = {
                            Text(
                                text = sym,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricCyan,
                            selectedLabelColor = Color(0xFF032329)
                        )
                    )
                }
            }
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(SentimentFilter.entries) { filter ->
                    FilterChip(
                        selected = uiState.selectedSentimentFilter == filter,
                        onClick = { onSelectSentimentFilter(filter) },
                        label = { Text(filter.arabicLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = when (filter) {
                                SentimentFilter.ALL -> ObsidianCardElevated
                                SentimentFilter.POSITIVE -> BullishEmerald
                                SentimentFilter.NEGATIVE -> BearishCrimson
                                SentimentFilter.NEUTRAL -> NeutralAmber
                            },
                            selectedLabelColor = if (filter == SentimentFilter.ALL) TextPrimary else Color(0xFF041E16)
                        ),
                        modifier = Modifier.testTag("sentiment_filter_${filter.name}")
                    )
                }
            }
        }

        if (uiState.isLoadingNews && uiState.newsItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = ElectricCyan)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "جارٍ جلب أحدث أخبار الشركات من المصادر الرسمية...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else if (uiState.newsError != null && uiState.newsItems.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = uiState.newsError,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = onRetryNews) {
                            Text("إعادة المحاولة")
                        }
                    }
                }
            }
        } else if (filteredNews.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "لا توجد أخبار مطابقة لهذا التصنيف حالياً.",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "اضغط على «تحليل وتصنيف أحدث الأخبار بالذكاء الاصطناعي» لتصنيف الأخبار المعروضة إلى إيجابية وسلبية ومحايدة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            items(
                items = filteredNews,
                key = { it.id }
            ) { item ->
                NewsArticleCard(
                    newsItem = item,
                    isSavedInCloud = savedUrls.contains(item.url),
                    onAnalyzeClick = { onAnalyzeSingle(item.id) },
                    onSaveAnalysisClick = { onSaveAnalysis(item) },
                    onOpenSourceUrl = onOpenUrl
                )
            }
        }
    }
}

@Composable
private fun WatchlistTabContent(
    watchlistState: CloudUiState<List<WatchlistStock>>,
    priceAlertsState: CloudUiState<List<PriceAlert>>,
    quotes: Map<String, StockQuote>,
    fcmState: FcmSubscriptionState,
    onSyncFcm: () -> Unit,
    hasNotificationPermission: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onSelectStock: (String) -> Unit,
    onEditStock: (WatchlistStock) -> Unit,
    onCreateCustomAlertGeneral: () -> Unit,
    onCreateAlertForStock: (WatchlistStock) -> Unit,
    onEditAlert: (PriceAlert) -> Unit,
    onToggleAlertEnabled: (PriceAlert, Boolean) -> Unit,
    onDeleteAlert: (String) -> Unit,
    onRemoveStock: (WatchlistStock) -> Unit,
    onExploreStocks: () -> Unit
) {
    var performanceMode by rememberSaveable {
        mutableStateOf(WatchlistSortAndCategoryMode.AUTO_GROUPED)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Notification Permission Banner (if Android 13+ and not granted)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NeutralAmberSurface),
                    border = BorderStroke(1.dp, NeutralAmber.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تفعيل الإشعارات الفورية للأسعار",
                                style = MaterialTheme.typography.titleSmall,
                                color = NeutralAmberLight,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "اسمح للتطبيق بإرسال إشعارات على هاتفك فور وصول أسهمك المفضلة إلى السعر المستهدف.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = onRequestNotificationPermission,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeutralAmberLight,
                                contentColor = Color(0xFF231702)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("grant_notifications_button")
                        ) {
                            Text("تفعيل", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Firebase Cloud Messaging (FCM) Push Notification Status Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(
                    1.dp,
                    if (fcmState.isConnected) ElectricCyan.copy(alpha = 0.45f) else ObsidianBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("fcm_push_status_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "إشعارات Firebase Messaging الفورية",
                                tint = if (fcmState.isConnected) ElectricCyan else GoldAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "الإشعارات الفورية (Firebase Messaging - FCM)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = when {
                                        fcmState.isSyncing -> "جارٍ مزامنة اشتراكات قنوات FCM..."
                                        fcmState.isConnected -> "متصل • جاهز لاستقبال إشعارات الأسعار الفورية"
                                        else -> "جاهز للمزامنة مع خادم إشعارات Firebase"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (fcmState.isConnected) BullishEmeraldLight else TextSecondary
                                )
                            }
                        }

                        TextButton(
                            onClick = onSyncFcm,
                            modifier = Modifier.testTag("sync_fcm_button")
                        ) {
                            Text(
                                text = "مزامنة FCM",
                                color = ElectricCyan,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (fcmState.subscribedTopics.isEmpty()) {
                                "لا توجد قنوات أسهم مشتركة حالياً في FCM"
                            } else {
                                "قنوات FCM النشطة: ${fcmState.subscribedTopics.joinToString(" • ")}"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = ObsidianCardElevated,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "FCM: ${fcmState.tokenPreview}",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = ElectricCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        // Custom Price Alerts Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "تنبيهات الأسعار المخصصة",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                        Text(
                            text = "حفظ سحابي في Firestore مع إشعارات محلية وفورية عند تجاوز السعر أو انخفاضه عن الحد.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onCreateCustomAlertGeneral,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldAccent,
                        contentColor = Color(0xFF231702)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("add_custom_price_alert_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddAlert,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تنبيه جديد", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        when (priceAlertsState) {
            is CloudUiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = GoldAccent
                        )
                    }
                }
            }
            is CloudUiState.Error -> {
                item {
                    Surface(
                        color = BearishCrimsonSurface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = priceAlertsState.message,
                            color = BearishCrimsonLight,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
            is CloudUiState.Success -> {
                val alerts = priceAlertsState.data
                if (alerts.isEmpty()) {
                    item {
                        Surface(
                            color = ObsidianCard,
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, ObsidianBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsNone,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "لا توجد تنبيهات سعرية نشطة حالياً. يمكنك إنشاء تنبيه مخصص لأي سهم ليصلك إشعار محلي وفوري عند وصول السعر للهدف.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                                OutlinedButton(
                                    onClick = onCreateCustomAlertGeneral,
                                    border = BorderStroke(1.dp, GoldAccent),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .align(Alignment.End)
                                        .testTag("empty_alerts_create_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AddAlert,
                                        contentDescription = null,
                                        tint = GoldAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تعيين تنبيه سعري مخصص", color = GoldAccent)
                                }
                            }
                        }
                    }
                } else {
                    items(
                        items = alerts,
                        key = { "alert_${it.id}" }
                    ) { alert ->
                        PriceAlertCard(
                            alert = alert,
                            livePrice = quotes[alert.symbol]?.currentPrice,
                            onEdit = { onEditAlert(alert) },
                            onToggleEnabled = { enabled -> onToggleAlertEnabled(alert, enabled) },
                            onDelete = { onDeleteAlert(alert.id) }
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))
            Column {
                Text(
                    text = "قائمة الشركات المفضلة",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "محفوظة في حسابك السحابي مع متابعة فورية للأسعار والملاحظات والأهداف السعرية.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        when (watchlistState) {
            is CloudUiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = BullishEmerald)
                    }
                }
            }
            is CloudUiState.Error -> {
                item {
                    Surface(
                        color = BearishCrimsonSurface,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = watchlistState.message,
                            color = BearishCrimsonLight,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
            is CloudUiState.Success -> {
                val list = watchlistState.data
                if (list.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                            border = BorderStroke(1.dp, ObsidianBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.StarBorder,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "قائمة المفضلة فارغة حالياً",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "أضف شركاتك الأمريكية المفضلة من علامة النجمة بجانب أي سهم لمتابعة أسعارها وضبط تنبيهات الأسعار الفورية.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = onExploreStocks,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BullishEmerald,
                                        contentColor = Color(0xFF032219)
                                    )
                                ) {
                                    Text("استعراض الأسهم الأمريكية")
                                }
                            }
                        }
                    }
                } else {
                    val activeAlertsMap = (priceAlertsState as? CloudUiState.Success)?.data
                        ?.filter { it.isEnabled && !it.isTriggered }
                        ?.groupBy { it.symbol.uppercase() }
                        .orEmpty()

                    val perfSummary = evaluateWatchlistPerformance(list, quotes)

                    item(key = "watchlist_perf_overview") {
                        WatchlistPerformanceOverviewCard(
                            summary = perfSummary,
                            selectedMode = performanceMode,
                            onSelectMode = { performanceMode = it },
                            onSelectStock = onSelectStock
                        )
                    }

                    when (performanceMode) {
                        WatchlistSortAndCategoryMode.AUTO_GROUPED -> {
                            if (perfSummary.gainersGroup.isNotEmpty()) {
                                item(key = "watchlist_section_gainers_header") {
                                    WatchlistCategorySectionHeader(
                                        title = "الأعلى ارتفاعاً والأسهم الصاعدة",
                                        subtitle = "مرتبة تلقائياً من الأعلى نسبة ربح اليوم إلى الأقل",
                                        count = perfSummary.gainersGroup.size,
                                        isPositiveSection = true,
                                        testTag = "watchlist_gainers_section_header"
                                    )
                                }
                                items(
                                    items = perfSummary.gainersGroup,
                                    key = { "gainer_${it.stock.symbol}" }
                                ) { catItem ->
                                    WatchlistCategorizedStockItem(
                                        categorizedItem = catItem,
                                        activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                        onSelectStock = onSelectStock,
                                        onRemoveStock = onRemoveStock,
                                        onCreateAlertForStock = onCreateAlertForStock,
                                        onEditStock = onEditStock
                                    )
                                }
                            }

                            if (perfSummary.losersGroup.isNotEmpty()) {
                                item(key = "watchlist_section_losers_header") {
                                    WatchlistCategorySectionHeader(
                                        title = "الأكثر انخفاضاً والأسهم المتراجعة",
                                        subtitle = "مرتبة تلقائياً من الأكثر تراجعاً اليوم لتنبيهك سريعاً",
                                        count = perfSummary.losersGroup.size,
                                        isPositiveSection = false,
                                        testTag = "watchlist_losers_section_header"
                                    )
                                }
                                items(
                                    items = perfSummary.losersGroup,
                                    key = { "loser_${it.stock.symbol}" }
                                ) { catItem ->
                                    WatchlistCategorizedStockItem(
                                        categorizedItem = catItem,
                                        activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                        onSelectStock = onSelectStock,
                                        onRemoveStock = onRemoveStock,
                                        onCreateAlertForStock = onCreateAlertForStock,
                                        onEditStock = onEditStock
                                    )
                                }
                            }

                            if (perfSummary.flatOrPendingGroup.isNotEmpty()) {
                                item(key = "watchlist_section_flat_header") {
                                    WatchlistCategorySectionHeader(
                                        title = "أسهم مستقرة أو قيد التحديث",
                                        subtitle = "أسهم لم يتغير سعرها أو جارٍ تحديث بياناتها اللحظية",
                                        count = perfSummary.flatOrPendingGroup.size,
                                        isPositiveSection = null,
                                        testTag = "watchlist_flat_section_header"
                                    )
                                }
                                items(
                                    items = perfSummary.flatOrPendingGroup,
                                    key = { "flat_${it.stock.symbol}" }
                                ) { catItem ->
                                    WatchlistCategorizedStockItem(
                                        categorizedItem = catItem,
                                        activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                        onSelectStock = onSelectStock,
                                        onRemoveStock = onRemoveStock,
                                        onCreateAlertForStock = onCreateAlertForStock,
                                        onEditStock = onEditStock
                                    )
                                }
                            }
                        }

                        WatchlistSortAndCategoryMode.TOP_GAINERS_FIRST -> {
                            val sortedAll = perfSummary.gainersGroup +
                                perfSummary.flatOrPendingGroup +
                                perfSummary.losersGroup.sortedByDescending { it.quote?.changePercent ?: -999.0 }
                            items(
                                items = sortedAll,
                                key = { "top_gain_${it.stock.symbol}" }
                            ) { catItem ->
                                WatchlistCategorizedStockItem(
                                    categorizedItem = catItem,
                                    activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                    onSelectStock = onSelectStock,
                                    onRemoveStock = onRemoveStock,
                                    onCreateAlertForStock = onCreateAlertForStock,
                                    onEditStock = onEditStock
                                )
                            }
                        }

                        WatchlistSortAndCategoryMode.TOP_LOSERS_FIRST -> {
                            val sortedAll = perfSummary.losersGroup +
                                perfSummary.flatOrPendingGroup +
                                perfSummary.gainersGroup.sortedBy { it.quote?.changePercent ?: 999.0 }
                            items(
                                items = sortedAll,
                                key = { "top_lose_${it.stock.symbol}" }
                            ) { catItem ->
                                WatchlistCategorizedStockItem(
                                    categorizedItem = catItem,
                                    activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                    onSelectStock = onSelectStock,
                                    onRemoveStock = onRemoveStock,
                                    onCreateAlertForStock = onCreateAlertForStock,
                                    onEditStock = onEditStock
                                )
                            }
                        }

                        WatchlistSortAndCategoryMode.GAINERS_ONLY -> {
                            if (perfSummary.gainersGroup.isEmpty()) {
                                item(key = "no_gainers_empty") {
                                    Surface(
                                        color = ObsidianCard,
                                        shape = RoundedCornerShape(14.dp),
                                        border = BorderStroke(1.dp, ObsidianBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "لا توجد أسهم رابحة حالياً في قائمة المفضلة.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextSecondary,
                                            modifier = Modifier.padding(18.dp)
                                        )
                                    }
                                }
                            } else {
                                items(
                                    items = perfSummary.gainersGroup,
                                    key = { "only_gain_${it.stock.symbol}" }
                                ) { catItem ->
                                    WatchlistCategorizedStockItem(
                                        categorizedItem = catItem,
                                        activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                        onSelectStock = onSelectStock,
                                        onRemoveStock = onRemoveStock,
                                        onCreateAlertForStock = onCreateAlertForStock,
                                        onEditStock = onEditStock
                                    )
                                }
                            }
                        }

                        WatchlistSortAndCategoryMode.LOSERS_ONLY -> {
                            if (perfSummary.losersGroup.isEmpty()) {
                                item(key = "no_losers_empty") {
                                    Surface(
                                        color = ObsidianCard,
                                        shape = RoundedCornerShape(14.dp),
                                        border = BorderStroke(1.dp, ObsidianBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "لا توجد أسهم متراجعة حالياً في قائمة المفضلة.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextSecondary,
                                            modifier = Modifier.padding(18.dp)
                                        )
                                    }
                                }
                            } else {
                                items(
                                    items = perfSummary.losersGroup,
                                    key = { "only_lose_${it.stock.symbol}" }
                                ) { catItem ->
                                    WatchlistCategorizedStockItem(
                                        categorizedItem = catItem,
                                        activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                        onSelectStock = onSelectStock,
                                        onRemoveStock = onRemoveStock,
                                        onCreateAlertForStock = onCreateAlertForStock,
                                        onEditStock = onEditStock
                                    )
                                }
                            }
                        }

                        WatchlistSortAndCategoryMode.ALPHABETICAL -> {
                            val bySymbol = (perfSummary.gainersGroup + perfSummary.losersGroup + perfSummary.flatOrPendingGroup)
                                .sortedBy { it.stock.symbol }
                            items(
                                items = bySymbol,
                                key = { "alpha_${it.stock.symbol}" }
                            ) { catItem ->
                                WatchlistCategorizedStockItem(
                                    categorizedItem = catItem,
                                    activeAlerts = activeAlertsMap[catItem.stock.symbol.uppercase()].orEmpty(),
                                    onSelectStock = onSelectStock,
                                    onRemoveStock = onRemoveStock,
                                    onCreateAlertForStock = onCreateAlertForStock,
                                    onEditStock = onEditStock
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WatchlistCategorizedStockItem(
    categorizedItem: CategorizedWatchlistItem,
    activeAlerts: List<PriceAlert>,
    onSelectStock: (String) -> Unit,
    onRemoveStock: (WatchlistStock) -> Unit,
    onCreateAlertForStock: (WatchlistStock) -> Unit,
    onEditStock: (WatchlistStock) -> Unit
) {
    val item = categorizedItem.stock
    val quote = categorizedItem.quote
    Column {
        StockQuoteCard(
            symbol = item.symbol,
            companyName = item.companyName,
            arabicName = item.arabicName ?: item.companyName,
            sector = item.sector ?: "السوق الأمريكي",
            quote = quote,
            isFavorite = true,
            onToggleFavorite = { onRemoveStock(item) },
            onClick = { onSelectStock(item.symbol) },
            activeAlerts = activeAlerts,
            onCreateAlertClick = { onCreateAlertForStock(item) }
        )
        Surface(
            color = ObsidianCardElevated,
            shape = RoundedCornerShape(bottomStart = 14.dp, bottomEnd = 14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WatchlistPerformanceTierBadge(
                            tier = categorizedItem.tier,
                            rankInGroup = categorizedItem.rankInGroup
                        )
                        if (item.targetPrice != null && item.targetPrice > 0) {
                            Text(
                                text = "الهدف: ${formatUsdPrice(item.targetPrice)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = GoldAccent
                            )
                        }
                    }
                    Text(
                        text = item.notes?.takeIf { it.isNotBlank() }
                            ?: "لا توجد ملاحظات استثمارية مضافة",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = { onCreateAlertForStock(item) },
                        modifier = Modifier.testTag("add_price_alert_${item.symbol}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAlert,
                            contentDescription = "إضافة تنبيه سعري",
                            tint = GoldAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تنبيه سعري", color = GoldAccent)
                    }
                    TextButton(
                        onClick = { onEditStock(item) },
                        modifier = Modifier.testTag("edit_watchlist_${item.symbol}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "تعديل الملاحظات",
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ملاحظة", color = ElectricCyan)
                    }
                }
            }
        }
    }
}

@Composable
private fun PriceAlertCard(
    alert: PriceAlert,
    livePrice: Double?,
    onEdit: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    val isAbove = alert.conditionEnum == AlertCondition.ABOVE
    val statusColor = when {
        alert.isTriggered -> GoldAccent
        alert.isEnabled -> if (isAbove) BullishEmeraldLight else BearishCrimsonLight
        else -> TextMuted
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(
            width = 1.dp,
            color = if (alert.isTriggered) GoldAccent.copy(alpha = 0.6f) else ObsidianBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("price_alert_card_${alert.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = alert.symbol,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = ElectricCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = alert.arabicName ?: alert.companyName,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isAbove) {
                                    Icons.AutoMirrored.Filled.TrendingUp
                                } else {
                                    Icons.AutoMirrored.Filled.TrendingDown
                                },
                                contentDescription = null,
                                tint = statusColor,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${alert.conditionEnum.arabicLabel} ${formatUsdPrice(alert.targetPrice)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = statusColor,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = alert.isEnabled,
                        onCheckedChange = onToggleEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF032219),
                            checkedTrackColor = BullishEmerald
                        ),
                        modifier = Modifier.testTag("toggle_alert_${alert.id}")
                    )
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.testTag("edit_alert_${alert.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "تعديل الحد السعري للتنبيه",
                            tint = ElectricCyan
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_alert_${alert.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف التنبيه",
                            tint = BearishCrimsonLight
                        )
                    }
                }
            }

            if (!alert.note.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ملاحظة: ${alert.note}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when {
                            alert.isTriggered -> {
                                val trigPrice = alert.triggeredPrice?.let { formatUsdPrice(it) } ?: ""
                                "تم الوصول للهدف وإرسال إشعار محلي وفوري ($trigPrice)"
                            }
                            alert.isEnabled -> "نشط • إشعار محلي وفوري عند الوصول للهدف"
                            else -> "متوقف مؤقتاً (فعّل المفتاح لإعادة المراقبة)"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor
                    )
                    if (alert.isEnabled) {
                        Text(
                            text = "محفوظ في Firestore • قناة FCM: ${FcmPushManager.topicForSymbol(alert.symbol)}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = ElectricCyan.copy(alpha = 0.85f)
                        )
                    }
                }
                if (livePrice != null && livePrice > 0.0) {
                    val diffPct = ((alert.targetPrice - livePrice) / livePrice) * 100.0
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "السعر الآن: ${formatUsdPrice(livePrice)}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = String.format(
                                Locale.US,
                                "الفرق عن الهدف: %s%.2f%%",
                                if (diffPct >= 0.0) "+" else "",
                                diffPct
                            ),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedAnalysesTabContent(
    savedAnalysesState: CloudUiState<List<SavedNewsAnalysis>>,
    onDeleteAnalysis: (String) -> Unit,
    onOpenUrl: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 760.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "تحليلات الأخبار المحفوظة",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "أرشيفك السحابي للأخبار التي قمت بتحليلها وتصنيفها بالذكاء الاصطناعي.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        when (savedAnalysesState) {
            is CloudUiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = ElectricCyan)
                    }
                }
            }
            is CloudUiState.Error -> {
                item {
                    Surface(
                        color = BearishCrimsonSurface,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = savedAnalysesState.message,
                            color = BearishCrimsonLight,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
            is CloudUiState.Success -> {
                val list = savedAnalysesState.data
                if (list.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                            border = BorderStroke(1.dp, ObsidianBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bookmarks,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "لا توجد تحليلات محفوظة بعد",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "قم بتحليل أي خبر في تبويب «الأخبار و AI» ثم اضغط على «حفظ التحليل» للرجوع إليه في أي وقت.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                } else {
                    items(
                        items = list,
                        key = { it.id }
                    ) { item ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                            border = BorderStroke(1.dp, ObsidianBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = ObsidianCardElevated,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = item.symbol,
                                                fontFamily = JetBrainsMonoFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                color = ElectricCyan,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        SentimentBadge(
                                            sentiment = item.sentimentEnum,
                                            confidenceScore = item.confidenceScore.toInt()
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteAnalysis(item.id) },
                                        modifier = Modifier.testTag("delete_saved_analysis_${item.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "حذف التحليل",
                                            tint = BearishCrimsonLight
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = item.headline,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.arabicSummary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "الأثر المالي: ${item.marketImpact}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ElectricCyan
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "المصدر: ${item.source} • ${formatExactDateTime(item.publishedAtMillis)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                    TextButton(onClick = { onOpenUrl(item.articleUrl) }) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                            contentDescription = null,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("الخبر الأصلي")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StockDetailSheetContent(
    symbol: String,
    companyName: String,
    arabicName: String,
    sector: String,
    quote: StockQuote?,
    isFavorite: Boolean,
    hasPortfolioHolding: Boolean,
    relatedNews: List<CompanyNewsItem>,
    onToggleFavorite: () -> Unit,
    onCreatePriceAlert: () -> Unit,
    onAddOrEditPortfolioHolding: () -> Unit,
    onViewAllCompanyNews: () -> Unit,
    onOpenAiPrediction: () -> Unit,
    onAnalyzeNews: (String) -> Unit,
    onSaveAnalysis: (CompanyNewsItem) -> Unit,
    onOpenUrl: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = arabicName,
                                style = MaterialTheme.typography.headlineMedium,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = ObsidianCardElevated,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = symbol,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricCyan,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Text(
                            text = "$companyName • $sector",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onCreatePriceAlert,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, GoldAccent),
                            modifier = Modifier.testTag("sheet_create_alert_$symbol")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAlert,
                                contentDescription = "تنبيه سعري",
                                tint = GoldAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تنبيه", color = GoldAccent)
                        }

                        Button(
                            onClick = onToggleFavorite,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isFavorite) ObsidianCardElevated else GoldAccent,
                                contentColor = if (isFavorite) GoldAccent else Color(0xFF231702)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isFavorite) "بالمفضلة" else "مفضلة")
                        }
                    }
                }

                Button(
                    onClick = onOpenAiPrediction,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = Color(0xFF032329)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sheet_open_prediction_$symbol")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "توقع احتمالية صعود أو هبوط $symbol بـ AI (RSI, MACD, MA)",
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onAddOrEditPortfolioHolding,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BullishEmerald),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sheet_portfolio_action_$symbol")
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = BullishEmeraldLight,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (hasPortfolioHolding) {
                            "تعديل مركز $symbol في المحفظة الافتراضية"
                        } else {
                            "إضافة $symbol إلى المحفظة الافتراضية (تتبع الربح والخسارة)"
                        },
                        color = BullishEmeraldLight,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (quote != null) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = formatUsdPrice(quote.currentPrice),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 28.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = formatSignedChange(quote.change, quote.changePercent),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    color = if (quote.change >= 0) BullishEmeraldLight else BearishCrimsonLight
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "البورصة: ${quote.exchangeName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "المصدر: ${quote.dataSource}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ElectricCyan
                                )
                            }
                        }

                        if (quote.sparklinePoints.size >= 2) {
                            Spacer(modifier = Modifier.height(16.dp))
                            IntradaySparkline(
                                points = quote.sparklinePoints,
                                isPositive = quote.change >= 0.0,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            DetailMetricItem("الافتتاح", formatUsdPrice(quote.openPrice))
                            DetailMetricItem("الإغلاق السابق", formatUsdPrice(quote.previousClose))
                            DetailMetricItem("الأعلى اليوم", formatUsdPrice(quote.dayHigh))
                            DetailMetricItem("الأدنى اليوم", formatUsdPrice(quote.dayLow))
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "توقيت بيانات السعر: ${formatExactDateTime(quote.quoteTimestampMillis)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "أحدث أخبار $symbol",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                TextButton(onClick = onViewAllCompanyNews) {
                    Text("جلب وتحليل كافة أخبار $symbol", color = ElectricCyan)
                }
            }
        }

        if (relatedNews.isEmpty()) {
            item {
                OutlinedButton(
                    onClick = onViewAllCompanyNews,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("اضغط لجلب أحدث الأخبار الحية لشركة $arabicName ($symbol)")
                }
            }
        } else {
            items(relatedNews.take(3), key = { it.id }) { newsItem ->
                NewsArticleCard(
                    newsItem = newsItem,
                    isSavedInCloud = false,
                    onAnalyzeClick = { onAnalyzeNews(newsItem.id) },
                    onSaveAnalysisClick = { onSaveAnalysis(newsItem) },
                    onOpenSourceUrl = onOpenUrl
                )
            }
        }
    }
}

@Composable
private fun DetailMetricItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Text(
            text = value,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            color = TextPrimary
        )
    }
}

@Composable
private fun EditWatchlistDialog(
    stock: WatchlistStock,
    onDismiss: () -> Unit,
    onConfirm: (notes: String?, targetPrice: Double?) -> Unit
) {
    var notesText by remember(stock) { mutableStateOf(stock.notes.orEmpty()) }
    var targetPriceText by remember(stock) {
        mutableStateOf(stock.targetPrice?.takeIf { it > 0 }?.toString().orEmpty())
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianCard,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Text("تحديث بيانات ${stock.arabicName ?: stock.symbol} (${stock.symbol})")
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = targetPriceText,
                    onValueChange = { targetPriceText = it },
                    label = { Text("السعر المستهدف بالدولار (اختياري)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it.take(500) },
                    label = { Text("ملاحظاتك الاستثمارية حول السهم") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedPrice = targetPriceText.trim().toDoubleOrNull()
                    onConfirm(notesText.trim().ifEmpty { null }, parsedPrice)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullishEmerald,
                    contentColor = Color(0xFF032219)
                )
            ) {
                Text("حفظ في السحابة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondary)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreatePriceAlertDialog(
    initialSymbol: String,
    initialCompanyName: String,
    initialArabicName: String?,
    editingAlert: PriceAlert?,
    quotes: Map<String, StockQuote>,
    watchlistStocks: List<WatchlistStock>,
    onRequestQuoteForSymbol: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: (
        symbol: String,
        companyName: String,
        arabicName: String?,
        targetPrice: Double,
        condition: AlertCondition,
        note: String?
    ) -> Unit
) {
    val defaultSymbol = remember(initialSymbol, watchlistStocks) {
        initialSymbol.ifBlank {
            watchlistStocks.firstOrNull()?.symbol ?: UsStockCatalog.majorUsStocks.first().symbol
        }
    }
    var selectedSymbol by remember(defaultSymbol) { mutableStateOf(defaultSymbol) }
    val cleanSymbol = selectedSymbol.trim().uppercase()
    val curated = remember(cleanSymbol) { UsStockCatalog.findBySymbol(cleanSymbol) }
    val watchlistMatch = remember(cleanSymbol, watchlistStocks) {
        watchlistStocks.find { it.symbol.equals(cleanSymbol, ignoreCase = true) }
    }
    val liveQuote = quotes[cleanSymbol]
    val currentLivePrice = liveQuote?.currentPrice

    LaunchedEffect(cleanSymbol) {
        if (cleanSymbol.isNotBlank() && liveQuote == null) {
            onRequestQuoteForSymbol(cleanSymbol)
        }
    }

    var selectedCondition by remember(editingAlert) {
        mutableStateOf(editingAlert?.conditionEnum ?: AlertCondition.ABOVE)
    }
    var targetPriceText by remember(editingAlert, cleanSymbol) {
        val initial = when {
            editingAlert != null && editingAlert.targetPrice > 0 ->
                String.format(Locale.US, "%.2f", editingAlert.targetPrice)
            currentLivePrice != null && currentLivePrice > 0 ->
                String.format(Locale.US, "%.2f", currentLivePrice * 1.03)
            else -> ""
        }
        mutableStateOf(initial)
    }
    LaunchedEffect(currentLivePrice) {
        if (editingAlert == null && targetPriceText.isBlank() && currentLivePrice != null && currentLivePrice > 0) {
            val factor = if (selectedCondition == AlertCondition.ABOVE) 1.03 else 0.97
            targetPriceText = String.format(Locale.US, "%.2f", currentLivePrice * factor)
        }
    }

    var noteText by remember(editingAlert) {
        mutableStateOf(editingAlert?.note.orEmpty())
    }
    var validationError by remember { mutableStateOf<String?>(null) }

    val resolvedArabicName = initialArabicName?.takeIf { it.isNotBlank() && cleanSymbol == initialSymbol }
        ?: watchlistMatch?.arabicName
        ?: liveQuote?.arabicName
        ?: curated?.arabicName
    val resolvedCompanyName = initialCompanyName.takeIf { it.isNotBlank() && cleanSymbol == initialSymbol }
        ?: watchlistMatch?.companyName
        ?: liveQuote?.companyName
        ?: curated?.companyName
        ?: cleanSymbol

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianCard,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = GoldAccent
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (editingAlert != null) {
                        "تعديل تنبيه السعر • ${resolvedArabicName ?: cleanSymbol} ($cleanSymbol)"
                    } else if (cleanSymbol.isNotBlank()) {
                        "تنبيه سعري مخصص • ${resolvedArabicName ?: cleanSymbol} ($cleanSymbol)"
                    } else {
                        "تعيين تنبيه سعري مخصص"
                    }
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (initialSymbol.isBlank() && editingAlert == null) {
                    Text(
                        text = "اختر السهم المراد مراقبته:",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary
                    )
                    val stockChoices = remember(watchlistStocks) {
                        val favSymbols = watchlistStocks.map { it.symbol.uppercase() }.toSet()
                        val favCurated = watchlistStocks.map {
                            Triple(it.symbol, it.arabicName ?: it.companyName, true)
                        }
                        val majorOthers = UsStockCatalog.majorUsStocks
                            .filterNot { favSymbols.contains(it.symbol.uppercase()) }
                            .map { Triple(it.symbol, it.arabicName, false) }
                        favCurated + majorOthers
                    }
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(stockChoices, key = { it.first }) { (sym, arabLabel, isFav) ->
                            val isSelected = sym.equals(cleanSymbol, ignoreCase = true)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedSymbol = sym
                                    val price = quotes[sym]?.currentPrice
                                    if (price != null && price > 0) {
                                        val factor = if (selectedCondition == AlertCondition.ABOVE) 1.03 else 0.97
                                        targetPriceText = String.format(Locale.US, "%.2f", price * factor)
                                    } else {
                                        targetPriceText = ""
                                    }
                                    validationError = null
                                },
                                label = {
                                    Text(if (isFav) "★ $arabLabel ($sym)" else "$arabLabel ($sym)")
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldAccent,
                                    selectedLabelColor = Color(0xFF231702)
                                )
                            )
                        }
                    }
                }

                if (currentLivePrice != null && currentLivePrice > 0) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "السعر الفوري الحالي ($cleanSymbol):",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Text(
                                text = formatUsdPrice(currentLivePrice),
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = ElectricCyan
                            )
                        }
                    }
                }

                Text(
                    text = "شرط إرسال الإشعار المحلي والفوري:",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCondition == AlertCondition.ABOVE,
                        onClick = { selectedCondition = AlertCondition.ABOVE },
                        label = { Text("عند تجاوز السعر (≥)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BullishEmerald,
                            selectedLabelColor = Color(0xFF032219),
                            selectedLeadingIconColor = Color(0xFF032219)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("alert_condition_above")
                    )

                    FilterChip(
                        selected = selectedCondition == AlertCondition.BELOW,
                        onClick = { selectedCondition = AlertCondition.BELOW },
                        label = { Text("عند انخفاض السعر (≤)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.TrendingDown,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BearishCrimson,
                            selectedLabelColor = Color.White,
                            selectedLeadingIconColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("alert_condition_below")
                    )
                }

                if (currentLivePrice != null && currentLivePrice > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val presets = listOf(
                            "+2%" to (currentLivePrice * 1.02) to AlertCondition.ABOVE,
                            "+5%" to (currentLivePrice * 1.05) to AlertCondition.ABOVE,
                            "-2%" to (currentLivePrice * 0.98) to AlertCondition.BELOW,
                            "-5%" to (currentLivePrice * 0.95) to AlertCondition.BELOW
                        )
                        presets.forEach { (labelAndPrice, cond) ->
                            val (label, priceVal) = labelAndPrice
                            OutlinedButton(
                                onClick = {
                                    selectedCondition = cond
                                    targetPriceText = String.format(Locale.US, "%.2f", priceVal)
                                },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = label,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = ElectricCyan
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = targetPriceText,
                    onValueChange = {
                        targetPriceText = it
                        validationError = null
                    },
                    label = { Text("الحد السعري المستهدف بالدولار (USD)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("alert_target_price_input")
                )

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it.take(300) },
                    label = { Text("ملاحظة مرفقة بالإشعار (اختياري)") },
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("alert_note_input")
                )

                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = BearishCrimsonLight
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = targetPriceText.trim().toDoubleOrNull()
                    if (cleanSymbol.isBlank()) {
                        validationError = "يرجى اختيار السهم أولاً."
                    } else if (parsed == null || parsed <= 0.0) {
                        validationError = "يرجى إدخال سعر مستهدف صحيح أكبر من صفر."
                    } else {
                        onConfirm(
                            cleanSymbol,
                            resolvedCompanyName,
                            resolvedArabicName,
                            parsed,
                            selectedCondition,
                            noteText.trim().ifEmpty { null }
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldAccent,
                    contentColor = Color(0xFF231702)
                ),
                modifier = Modifier.testTag("confirm_create_alert_button")
            ) {
                Text(
                    text = if (editingAlert != null) "حفظ التعديلات" else "حفظ وتفعيل التنبيه",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun AppSettingsDialog(
    isDarkMode: Boolean,
    isEyeCareMode: Boolean,
    isReadingBoostEnabled: Boolean,
    userEmail: String?,
    fcmConnected: Boolean,
    onToggleDarkMode: (Boolean) -> Unit,
    onToggleEyeCareMode: (Boolean) -> Unit,
    onToggleReadingBoost: (Boolean) -> Unit,
    onOpenExportDialog: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianCard,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        modifier = Modifier.testTag("app_settings_dialog"),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = ElectricCyan
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إعدادات المظهر والوضع الليلي",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Dark Mode Switch Card
                Surface(
                    color = ObsidianCardElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isDarkMode) BullishEmerald.copy(alpha = 0.5f) else ObsidianBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = null,
                                tint = if (isDarkMode) GoldAccent else NeutralAmber,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "الوضع الليلي (Dark Mode)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "يقلل من إجهاد العين والسطوع العالي عند متابعة أسعار الأسهم والأخبار في الليل.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = onToggleDarkMode,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF032219),
                                checkedTrackColor = BullishEmerald
                            ),
                            modifier = Modifier.testTag("dark_mode_switch")
                        )
                    }
                }

                // Eye-Care Low Blue Light Filter Switch (when Dark Mode is active)
                Surface(
                    color = ObsidianCardElevated.copy(alpha = if (isDarkMode) 1f else 0.6f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RemoveRedEye,
                                contentDescription = null,
                                tint = if (isDarkMode && isEyeCareMode) ElectricCyan else TextMuted,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "فلتر راحة العين الليلي (Eye Care)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "تخفيف التباين الحاد والوهج الأزرق لحماية العين في ظروف الإضاءة المنخفضة.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = isDarkMode && isEyeCareMode,
                            onCheckedChange = { enabled ->
                                if (!isDarkMode && enabled) {
                                    onToggleDarkMode(true)
                                }
                                onToggleEyeCareMode(enabled)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF032329),
                                checkedTrackColor = ElectricCyan
                            ),
                            modifier = Modifier.testTag("eye_care_mode_switch")
                        )
                    }
                }

                // Night Reading Boost for News & Prices
                Surface(
                    color = ObsidianCardElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Newspaper,
                                contentDescription = null,
                                tint = if (isReadingBoostEnabled) GoldAccent else TextMuted,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "تحسين قراءة الأخبار والأسعار ليلاً",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "تكبير حجم خط الأسعار وعناوين الأخبار مع تباعد أسطر مريح للقراءة الليلية.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = isReadingBoostEnabled,
                            onCheckedChange = onToggleReadingBoost,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF231702),
                                checkedTrackColor = GoldAccent
                            ),
                            modifier = Modifier.testTag("reading_boost_switch")
                        )
                    }
                }

                // Export Data Button
                OutlinedButton(
                    onClick = onOpenExportDialog,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_export_dialog_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.IosShare,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تصدير بيانات المحفظة والمفضلة والتقارير (Export)",
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Current Theme & Account Summary
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ObsidianBorder.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (isDarkMode) {
                                if (isEyeCareMode) {
                                    "المظهر النشط: الوضع الليلي المريح للعين (منخفض الوهج)"
                                } else {
                                    "المظهر النشط: الوضع الليلي القياسي"
                                }
                            } else {
                                "المظهر النشط: الوضع النهاري الفاتح"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = BullishEmeraldLight,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "حالة إشعارات FCM: ${if (fcmConnected) "متصل ونشط" else "جاهز للمزامنة"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        if (!userEmail.isNullOrBlank()) {
                            Text(
                                text = "الحساب: $userEmail",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullishEmerald,
                    contentColor = Color(0xFF032219)
                ),
                modifier = Modifier.testTag("close_settings_button")
            ) {
                Text("تم", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun ExportDataDialog(
    portfolio: List<com.example.data.model.PortfolioHolding>,
    watchlist: List<WatchlistStock>,
    alerts: List<PriceAlert>,
    savedAnalyses: List<SavedNewsAnalysis>,
    quotes: Map<String, StockQuote>,
    onCopySuccess: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedFormat by rememberSaveable { mutableStateOf(ExportDataFormat.ARABIC_REPORT) }

    val exportedText = remember(selectedFormat, portfolio, watchlist, alerts, savedAnalyses, quotes) {
        DataExportHelper.buildExportContent(
            format = selectedFormat,
            portfolio = portfolio,
            watchlist = watchlist,
            alerts = alerts,
            savedAnalyses = savedAnalyses,
            quotes = quotes
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianCard,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        modifier = Modifier.testTag("export_data_dialog"),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.IosShare,
                    contentDescription = null,
                    tint = GoldAccent
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تصدير البيانات والتقارير (Export)",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "اختر صيغة التصدير لمشاركة أو نسخ بيانات محفظتك الافتراضية (${portfolio.size})، والمفضلة (${watchlist.size})، والتنبيهات السعرية (${alerts.size}):",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                ExportDataFormat.entries.forEach { format ->
                    val isSelected = selectedFormat == format
                    Surface(
                        onClick = { selectedFormat = format },
                        color = if (isSelected) BullishEmeraldSurface else ObsidianCardElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) BullishEmerald else ObsidianBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_format_${format.name}")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Text(
                                text = format.arabicTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = if (isSelected) BullishEmeraldLight else TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = format.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = exportedText.lines().take(8).joinToString("\n") +
                            if (exportedText.lines().size > 8) "\n..." else "",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextPrimary,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            DataExportHelper.copyToClipboard(
                                context = context,
                                text = exportedText,
                                label = selectedFormat.arabicTitle
                            )
                            onCopySuccess(selectedFormat.arabicTitle)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_export_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نسخ للحافظة", color = ElectricCyan)
                    }

                    Button(
                        onClick = {
                            DataExportHelper.shareExportText(
                                context = context,
                                content = exportedText,
                                format = selectedFormat
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldAccent,
                            contentColor = Color(0xFF231702)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_export_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مشاركة / تصدير", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_export_dialog_button")
            ) {
                Text("إغلاق", color = TextSecondary)
            }
        }
    )
}


