package com.example.ui.theme

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

object AppThemeSettings {
    private const val PREFS_NAME = "stockpulse_theme_prefs"
    private const val KEY_DARK_MODE = "dark_mode_enabled"
    private const val KEY_EYE_CARE_NIGHT = "eye_care_night_enabled"
    private const val KEY_LOW_LIGHT_READING_BOOST = "low_light_reading_boost"

    var isDarkMode by mutableStateOf(true)
        private set

    var isEyeCareNightMode by mutableStateOf(true)
        private set

    var isLowLightReadingBoost by mutableStateOf(false)
        private set

    fun initialize(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isDarkMode = prefs.getBoolean(KEY_DARK_MODE, true)
        isEyeCareNightMode = prefs.getBoolean(KEY_EYE_CARE_NIGHT, true)
        isLowLightReadingBoost = prefs.getBoolean(KEY_LOW_LIGHT_READING_BOOST, false)
    }

    fun setDarkMode(context: Context?, enabled: Boolean) {
        isDarkMode = enabled
        context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            ?.edit()
            ?.putBoolean(KEY_DARK_MODE, enabled)
            ?.apply()
    }

    fun toggleDarkMode(context: Context?) {
        setDarkMode(context, !isDarkMode)
    }

    fun setEyeCareNightMode(context: Context?, enabled: Boolean) {
        isEyeCareNightMode = enabled
        context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            ?.edit()
            ?.putBoolean(KEY_EYE_CARE_NIGHT, enabled)
            ?.apply()
    }

    fun setLowLightReadingBoost(context: Context?, enabled: Boolean) {
        isLowLightReadingBoost = enabled
        context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            ?.edit()
            ?.putBoolean(KEY_LOW_LIGHT_READING_BOOST, enabled)
            ?.apply()
    }
}

val ObsidianBackground: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFFF1F5F9)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF050B11)
        else -> Color(0xFF07111E)
    }

val ObsidianSurface: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFFFFFFFF)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF0A131D)
        else -> Color(0xFF0D1B2E)
    }

val ObsidianCard: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFFFFFFFF)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF0E1B28)
        else -> Color(0xFF13263E)
    }

val ObsidianCardElevated: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFFE2E8F0)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF142536)
        else -> Color(0xFF19314F)
    }

val ObsidianBorder: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFFCBD5E1)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF1C334B)
        else -> Color(0xFF233F63)
    }

val BullishEmerald: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFF10B981) else Color(0xFF059669)

val BullishEmeraldLight: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFF047857)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF2DD4BF)
        else -> Color(0xFF34D399)
    }

val BullishEmeraldSurface: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFF063229) else Color(0xFFD1FAE5)

val BearishCrimson: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFFF43F5E) else Color(0xFFE11D48)

val BearishCrimsonLight: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFFBE123C)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFFFB7185)
        else -> Color(0xFFFB7185)
    }

val BearishCrimsonSurface: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFF3B1020) else Color(0xFFFFE4E6)

val NeutralAmber: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFFF59E0B) else Color(0xFFD97706)

val NeutralAmberLight: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFFFBBF24) else Color(0xFFB45309)

val NeutralAmberSurface: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFF382609) else Color(0xFFFEF3C7)

val ElectricCyan: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFF0284C7)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF38BDF8)
        else -> Color(0xFF06B6D4)
    }

val GoldAccent: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFFFBBF24) else Color(0xFFD97706)

val TextPrimary: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFF0F172A)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFFE2E8F0)
        else -> Color(0xFFF8FAFC)
    }

val TextSecondary: Color
    get() = when {
        !AppThemeSettings.isDarkMode -> Color(0xFF475569)
        AppThemeSettings.isEyeCareNightMode -> Color(0xFF94A3B8)
        else -> Color(0xFF94A3B8)
    }

val TextMuted: Color
    get() = if (AppThemeSettings.isDarkMode) Color(0xFF64748B) else Color(0xFF64748B)
