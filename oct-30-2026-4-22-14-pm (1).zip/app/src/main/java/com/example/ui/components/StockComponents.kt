package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlertCondition
import com.example.data.model.CompanyNewsItem
import com.example.data.model.DailyWatchlistSummary
import com.example.data.model.NewsSentiment
import com.example.data.model.PriceAlert
import com.example.data.model.StockQuote
import com.example.ui.viewmodel.DailySummaryUiState
import com.example.ui.theme.AppThemeSettings
import com.example.ui.theme.BearishCrimson
import com.example.ui.theme.BearishCrimsonLight
import com.example.ui.theme.BearishCrimsonSurface
import com.example.ui.theme.BullishEmerald
import com.example.ui.theme.BullishEmeraldLight
import com.example.ui.theme.BullishEmeraldSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.NeutralAmberLight
import com.example.ui.theme.NeutralAmberSurface
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

fun formatUsdPrice(price: Double): String {
    return String.format(Locale.US, "$%,.2f", price)
}

fun formatSignedChange(change: Double, percent: Double): String {
    val sign = if (change > 0) "+" else if (change < 0) "-" else ""
    return String.format(
        Locale.US,
        "%s$%.2f (%s%.2f%%)",
        sign,
        abs(change),
        sign,
        abs(percent)
    )
}

fun formatExactDateTime(millis: Long): String {
    if (millis <= 0L) return "غير متوفر"
    val sdf = SimpleDateFormat("yyyy/MM/dd • HH:mm", Locale.US)
    return sdf.format(Date(millis))
}

fun formatRelativeAndExactTime(millis: Long): String {
    if (millis <= 0L) return "غير متوفر"
    val now = System.currentTimeMillis()
    val diff = (now - millis).coerceAtLeast(0L)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(diff)
    val hours = TimeUnit.MILLISECONDS.toHours(diff)
    val days = TimeUnit.MILLISECONDS.toDays(diff)

    val relative = when {
        minutes < 2 -> "الآن"
        minutes < 60 -> "منذ $minutes دقيقة"
        hours < 24 -> "منذ $hours ساعة"
        days == 1L -> "أمس"
        else -> "منذ $days يوم"
    }
    val exact = SimpleDateFormat("MM/dd HH:mm", Locale.US).format(Date(millis))
    return "$relative ($exact)"
}

@Composable
fun IntradaySparkline(
    points: List<Double>,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    val lineColor = if (isPositive) BullishEmeraldLight else BearishCrimsonLight
    val fillBrush = Brush.verticalGradient(
        colors = listOf(
            lineColor.copy(alpha = 0.32f),
            lineColor.copy(alpha = 0.0f)
        )
    )

    Canvas(modifier = modifier) {
        if (points.size < 2 || size.width <= 0f || size.height <= 0f) return@Canvas
        val minVal = points.minOrNull() ?: return@Canvas
        val maxVal = points.maxOrNull() ?: return@Canvas
        val range = (maxVal - minVal).takeIf { it > 0.0001 } ?: 1.0

        val stepX = size.width / (points.size - 1).coerceAtLeast(1)
        val strokePath = Path()
        val fillPath = Path()

        points.forEachIndexed { index, value ->
            val x = index * stepX
            val normalizedY = ((value - minVal) / range).toFloat()
            val y = size.height - (normalizedY * (size.height * 0.8f) + size.height * 0.1f)
            if (index == 0) {
                strokePath.moveTo(x, y)
                fillPath.moveTo(x, size.height)
                fillPath.lineTo(x, y)
            } else {
                strokePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(size.width, size.height)
        fillPath.close()

        drawPath(path = fillPath, brush = fillBrush)
        drawPath(
            path = strokePath,
            color = lineColor,
            style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun StockQuoteCard(
    symbol: String,
    companyName: String,
    arabicName: String,
    sector: String,
    quote: StockQuote?,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    activeAlerts: List<PriceAlert> = emptyList(),
    onCreateAlertClick: (() -> Unit)? = null
) {
    var showAlertDetails by remember(symbol, activeAlerts.size) { mutableStateOf(false) }
    val hasActiveAlerts = activeAlerts.isNotEmpty()
    val isBullish = (quote?.change ?: 0.0) >= 0.0
    val accentColor = when {
        quote == null -> TextSecondary
        quote.change > 0 -> BullishEmeraldLight
        quote.change < 0 -> BearishCrimsonLight
        else -> NeutralAmberLight
    }
    val badgeBg = when {
        quote == null -> ObsidianCardElevated
        quote.change > 0 -> BullishEmeraldSurface
        quote.change < 0 -> BearishCrimsonSurface
        else -> NeutralAmberSurface
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("stock_card_$symbol"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(
            width = 1.dp,
            color = if (hasActiveAlerts) GoldAccent.copy(alpha = 0.55f) else ObsidianBorder.copy(alpha = 0.7f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianCardElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = symbol.take(4),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = ElectricCyan
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = arabicName,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = symbol,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                        Text(
                            text = "$companyName • $sector",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (hasActiveAlerts) {
                        IconButton(
                            onClick = { showAlertDetails = !showAlertDetails },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("alert_bell_$symbol")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (showAlertDetails) {
                                            GoldAccent.copy(alpha = 0.28f)
                                        } else {
                                            NeutralAmberSurface
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "عرض قيمة تنبيه السعر المفعل لـ $symbol",
                                    tint = GoldAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    } else if (onCreateAlertClick != null) {
                        IconButton(
                            onClick = onCreateAlertClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("create_alert_button_$symbol")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAlert,
                                contentDescription = "إضافة تنبيه سعري مخصص لـ $symbol",
                                tint = TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("fav_button_$symbol")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = if (isFavorite) "إزالة من المفضلة" else "إضافة إلى المفضلة",
                            tint = if (isFavorite) GoldAccent else TextSecondary
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = hasActiveAlerts && showAlertDetails,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Surface(
                    color = NeutralAmberSurface.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.65f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .testTag("alert_details_popup_$symbol")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (activeAlerts.size == 1) {
                                        "تنبيه سعر مفعل:"
                                    } else {
                                        "تنبيهات الأسعار المفعلة (${activeAlerts.size}):"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(
                                onClick = { showAlertDetails = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق تفاصيل التنبيه",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        activeAlerts.forEach { alert ->
                            val isAbove = alert.conditionEnum == AlertCondition.ABOVE
                            val condColor = if (isAbove) BullishEmeraldLight else BearishCrimsonLight
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isAbove) {
                                            Icons.AutoMirrored.Filled.TrendingUp
                                        } else {
                                            Icons.AutoMirrored.Filled.TrendingDown
                                        },
                                        contentDescription = null,
                                        tint = condColor,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = alert.conditionEnum.arabicLabel,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimary
                                    )
                                }
                                Text(
                                    text = formatUsdPrice(alert.targetPrice),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = GoldAccent,
                                    modifier = Modifier.testTag("alert_bell_value_${alert.id}")
                                )
                            }
                            if (!alert.note.isNullOrBlank()) {
                                Text(
                                    text = "ملاحظة: ${alert.note}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        if (onCreateAlertClick != null) {
                            TextButton(
                                onClick = onCreateAlertClick,
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .testTag("popup_add_alert_$symbol")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddAlert,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "إضافة تنبيه سعري آخر",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = GoldAccent
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (quote != null) {
                val readingBoost = AppThemeSettings.isLowLightReadingBoost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = formatUsdPrice(quote.currentPrice),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (readingBoost) 25.sp else 22.sp,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = badgeBg,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when {
                                        quote.change > 0 -> Icons.AutoMirrored.Filled.TrendingUp
                                        quote.change < 0 -> Icons.AutoMirrored.Filled.TrendingDown
                                        else -> Icons.AutoMirrored.Filled.TrendingFlat
                                    },
                                    contentDescription = null,
                                    tint = accentColor,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = formatSignedChange(quote.change, quote.changePercent),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = accentColor
                                )
                            }
                        }
                    }

                    if (quote.sparklinePoints.size >= 2) {
                        IntradaySparkline(
                            points = quote.sparklinePoints,
                            isPositive = isBullish,
                            modifier = Modifier
                                .width(115.dp)
                                .height(46.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "أعلى: ${formatUsdPrice(quote.dayHigh)} • أدنى: ${formatUsdPrice(quote.dayLow)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "${quote.dataSource} • ${formatRelativeAndExactTime(quote.quoteTimestampMillis)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "اضغط لجلب السعر الفوري من السوق الأمريكي",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "بيانات حقيقية فقط",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan
                    )
                }
            }
        }
    }
}

@Composable
fun SentimentBadge(
    sentiment: NewsSentiment,
    confidenceScore: Int? = null,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, icon) = when (sentiment) {
        NewsSentiment.POSITIVE -> Triple(
            BullishEmeraldSurface,
            BullishEmeraldLight,
            Icons.AutoMirrored.Filled.TrendingUp
        )
        NewsSentiment.NEGATIVE -> Triple(
            BearishCrimsonSurface,
            BearishCrimsonLight,
            Icons.AutoMirrored.Filled.TrendingDown
        )
        NewsSentiment.NEUTRAL -> Triple(
            NeutralAmberSurface,
            NeutralAmberLight,
            Icons.AutoMirrored.Filled.TrendingFlat
        )
    }

    Surface(
        modifier = modifier,
        color = bgColor,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = buildString {
                    append("تصنيف AI: ")
                    append(sentiment.arabicLabel)
                    if (confidenceScore != null && confidenceScore > 0) {
                        append(" ($confidenceScore%)")
                    }
                },
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NewsArticleCard(
    newsItem: CompanyNewsItem,
    isSavedInCloud: Boolean,
    onAnalyzeClick: () -> Unit,
    onSaveAnalysisClick: () -> Unit,
    onOpenSourceUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("news_card_${newsItem.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(
            width = 1.dp,
            color = when (newsItem.aiAnalysis?.sentiment) {
                NewsSentiment.POSITIVE -> BullishEmerald.copy(alpha = 0.55f)
                NewsSentiment.NEGATIVE -> BearishCrimson.copy(alpha = 0.55f)
                NewsSentiment.NEUTRAL -> NeutralAmber.copy(alpha = 0.45f)
                null -> ObsidianBorder.copy(alpha = 0.7f)
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top bar: Stock Symbol + Verified News Source + Exact Timestamp
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = newsItem.symbol,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = ElectricCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "مصدر موثق",
                        tint = GoldAccent,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "المصدر: ${newsItem.source}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "وقت النشر",
                        tint = TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formatRelativeAndExactTime(newsItem.publishedAtMillis),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val readingBoost = AppThemeSettings.isLowLightReadingBoost

            // Original Headline
            Text(
                text = newsItem.headline,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = if (readingBoost) 18.sp else 16.sp,
                    lineHeight = if (readingBoost) 26.sp else 22.sp
                ),
                color = TextPrimary
            )

            if (newsItem.summary.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = newsItem.summary,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = if (readingBoost) 15.sp else 14.sp,
                        lineHeight = if (readingBoost) 24.sp else 20.sp
                    ),
                    color = TextSecondary,
                    maxLines = if (readingBoost) 5 else 3,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // AI Sentiment & Analysis Section
            val analysis = newsItem.aiAnalysis
            if (analysis != null) {
                SentimentBadge(
                    sentiment = analysis.sentiment,
                    confidenceScore = analysis.confidenceScore
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            AnimatedVisibility(
                visible = analysis != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                if (analysis != null) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تحليل الذكاء الاصطناعي (Gemini)",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = GoldAccent
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = analysis.arabicHeadline,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontSize = if (readingBoost) 16.sp else 14.sp,
                                    lineHeight = if (readingBoost) 24.sp else 20.sp
                                ),
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = analysis.arabicSummary,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = if (readingBoost) 15.sp else 14.sp,
                                    lineHeight = if (readingBoost) 24.sp else 20.sp
                                ),
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "الأثر المالي على السهم: ${analysis.marketImpact}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ElectricCyan
                            )
                            if (analysis.keyDrivers.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                analysis.keyDrivers.forEach { point ->
                                    Row(
                                        modifier = Modifier.padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 8.dp)
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(BullishEmeraldLight)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = point,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (newsItem.analysisError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = BearishCrimsonSurface,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = newsItem.analysisError,
                        style = MaterialTheme.typography.bodySmall,
                        color = BearishCrimsonLight,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (analysis == null) {
                    Button(
                        onClick = onAnalyzeClick,
                        enabled = !newsItem.isAnalyzing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BullishEmerald,
                            contentColor = Color(0xFF032219)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("analyze_news_btn_${newsItem.id}")
                    ) {
                        if (newsItem.isAnalyzing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF032219)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جارٍ تحليل الخبر...")
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تحليل وتصنيف بالذكاء الاصطناعي")
                        }
                    }
                } else {
                    OutlinedButton(
                        onClick = onSaveAnalysisClick,
                        enabled = !isSavedInCloud,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (isSavedInCloud) BullishEmerald else ElectricCyan),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_analysis_btn_${newsItem.id}")
                    ) {
                        Icon(
                            imageVector = if (isSavedInCloud) Icons.Default.BookmarkAdded else Icons.Default.BookmarkBorder,
                            contentDescription = null,
                            tint = if (isSavedInCloud) BullishEmeraldLight else ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSavedInCloud) "تم الحفظ في السحابة" else "حفظ التحليل",
                            color = if (isSavedInCloud) BullishEmeraldLight else ElectricCyan
                        )
                    }
                }

                OutlinedButton(
                    onClick = { onOpenSourceUrl(newsItem.url) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.testTag("open_source_btn_${newsItem.id}")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = "فتح المصدر الأصلي",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "المصدر",
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun DailySummaryWelcomeCard(
    dailySummaryState: DailySummaryUiState,
    isVisible: Boolean,
    onRefreshSummary: () -> Unit,
    onGenerateMarketFallback: () -> Unit,
    onDismiss: () -> Unit,
    onReopen: () -> Unit,
    onSelectStock: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isVisible) {
        Surface(
            color = ObsidianCard,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.45f)),
            modifier = modifier
                .fillMaxWidth()
                .clickable { onReopen() }
                .testTag("reopen_daily_summary_banner")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ملخص اليوم لأخبار مفضلتك (Gemini AI)",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "عرض البطاقة",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricCyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        return
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.55f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("daily_summary_welcome_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GoldAccent.copy(alpha = 0.08f),
                            ObsidianCard
                        )
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = GoldAccent.copy(alpha = 0.18f),
                        shape = CircleShape
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ملخص اليوم • Gemini AI",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = ObsidianCardElevated,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "ترحيبي",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "موجز ذكي لأهم أخبار الشركات في قائمتك المفضلة",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onRefreshSummary,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("refresh_daily_summary_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تحديث ملخص اليوم",
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("dismiss_daily_summary_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إخفاء بطاقة ملخص اليوم",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.6f))

            when (dailySummaryState) {
                is DailySummaryUiState.Idle,
                is DailySummaryUiState.EmptyWatchlist -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "مرحباً بك في نبض الأسهم! أضف شركاتك الأمريكية المفضلة (باستخدام نجمة التفضيل ⭐) ليقوم Gemini بتلخيص أهم أخبارها اليومية تلقائياً عند فتح التطبيق.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                        OutlinedButton(
                            onClick = onGenerateMarketFallback,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, GoldAccent),
                            modifier = Modifier.testTag("generate_market_daily_summary_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "توليد ملخص اليوم لأبرز الشركات الكبرى الآن",
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                is DailySummaryUiState.Loading -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp,
                            color = GoldAccent
                        )
                        Column {
                            Text(
                                text = "يقوم Gemini الآن بتحليل وتلخيص أهم أخبار اليوم...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "الشركات المشمولة: ${dailySummaryState.symbols.joinToString(" • ")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }

                is DailySummaryUiState.Error -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = dailySummaryState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = BearishCrimsonLight
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onRefreshSummary,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GoldAccent,
                                    contentColor = Color(0xFF231702)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("retry_daily_summary_button")
                            ) {
                                Text("إعادة المحاولة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                is DailySummaryUiState.Success -> {
                    val summary: DailyWatchlistSummary = dailySummaryState.summary
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = summary.welcomeHeadline,
                                style = MaterialTheme.typography.titleSmall,
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            SentimentBadge(sentiment = summary.overallSentiment)
                        }

                        Text(
                            text = summary.executiveSummary,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )

                        if (summary.keyMarketTakeaway.isNotBlank()) {
                            Surface(
                                color = ObsidianCardElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.35f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "الخلاصة: ${summary.keyMarketTakeaway}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        if (summary.companyHighlights.isNotEmpty()) {
                            Text(
                                text = "أبرز تطورات شركاتك المفضلة (${summary.articlesCount} أخبار موثقة):",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary,
                                fontWeight = FontWeight.Bold
                            )

                            summary.companyHighlights.forEach { item ->
                                Surface(
                                    color = ObsidianSurface,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, ObsidianBorder.copy(alpha = 0.6f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelectStock(item.symbol) }
                                        .testTag("daily_summary_highlight_${item.symbol}")
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(
                                                    color = ObsidianCardElevated,
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = item.symbol,
                                                        fontFamily = JetBrainsMonoFontFamily,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 11.sp,
                                                        color = ElectricCyan,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = item.arabicName,
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = TextPrimary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            SentimentBadge(sentiment = item.sentiment)
                                        }

                                        Text(
                                            text = item.summary,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextPrimary
                                        )

                                        Text(
                                            text = "المصدر: ${item.source} • تحديث: ${formatExactDateTime(summary.generatedAtMillis)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DarkModeQuickControlBar(
    isDarkMode: Boolean,
    isEyeCareMode: Boolean,
    isReadingBoostEnabled: Boolean,
    onToggleDarkMode: (Boolean) -> Unit,
    onToggleEyeCareMode: (Boolean) -> Unit,
    onToggleReadingBoost: (Boolean) -> Unit,
    contextLabel: String = "تصفح الأخبار والأسعار في الإضاءة المنخفضة",
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ui_dark_mode_control_bar"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(
            width = 1.dp,
            color = if (isDarkMode) BullishEmerald.copy(alpha = 0.45f) else ObsidianBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isDarkMode) BullishEmeraldSurface else NeutralAmberSurface
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                            contentDescription = "حالة الوضع الليلي",
                            tint = if (isDarkMode) GoldAccent else NeutralAmber,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isDarkMode) "الوضع الليلي مفعل (Dark Mode)" else "الوضع النهاري الفاتح",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (isDarkMode) BullishEmeraldSurface else NeutralAmberSurface,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = when {
                                        isDarkMode && isEyeCareMode -> "راحة العين"
                                        isDarkMode -> "ليلي قياسي"
                                        else -> "نهاري"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isDarkMode) BullishEmeraldLight else NeutralAmberLight,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = contextLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Switch(
                    checked = isDarkMode,
                    onCheckedChange = onToggleDarkMode,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF032219),
                        checkedTrackColor = BullishEmerald
                    ),
                    modifier = Modifier.testTag("ui_dark_mode_quick_switch")
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = isDarkMode && isEyeCareMode,
                    onClick = {
                        if (!isDarkMode) {
                            onToggleDarkMode(true)
                        }
                        onToggleEyeCareMode(true)
                    },
                    label = { Text("إضاءة منخفضة (راحة العين)") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.RemoveRedEye,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BullishEmeraldSurface,
                        selectedLabelColor = BullishEmeraldLight,
                        selectedLeadingIconColor = BullishEmeraldLight
                    ),
                    modifier = Modifier.testTag("quick_mode_eyecare_chip")
                )

                FilterChip(
                    selected = isDarkMode && !isEyeCareMode,
                    onClick = {
                        if (!isDarkMode) {
                            onToggleDarkMode(true)
                        }
                        onToggleEyeCareMode(false)
                    },
                    label = { Text("الوضع الليلي القياسي") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.DarkMode,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ObsidianCardElevated,
                        selectedLabelColor = GoldAccent,
                        selectedLeadingIconColor = GoldAccent
                    ),
                    modifier = Modifier.testTag("quick_mode_dark_chip")
                )

                FilterChip(
                    selected = !isDarkMode,
                    onClick = { onToggleDarkMode(false) },
                    label = { Text("الوضع النهاري") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.LightMode,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeutralAmberSurface,
                        selectedLabelColor = NeutralAmberLight,
                        selectedLeadingIconColor = NeutralAmberLight
                    ),
                    modifier = Modifier.testTag("quick_mode_light_chip")
                )

                FilterChip(
                    selected = isReadingBoostEnabled,
                    onClick = { onToggleReadingBoost(!isReadingBoostEnabled) },
                    label = { Text("تكبير خط الأخبار والأسعار") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ElectricCyan,
                        selectedLabelColor = Color(0xFF032329)
                    ),
                    modifier = Modifier.testTag("quick_mode_reading_boost_chip")
                )
            }
        }
    }
}


