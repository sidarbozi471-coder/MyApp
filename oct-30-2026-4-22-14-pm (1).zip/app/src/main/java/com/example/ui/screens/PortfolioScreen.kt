package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PortfolioHolding
import com.example.data.model.StockQuote
import com.example.data.model.UsStockCatalog
import com.example.ui.components.formatSignedChange
import com.example.ui.components.formatUsdPrice
import com.example.ui.theme.BearishCrimson
import com.example.ui.theme.BearishCrimsonLight
import com.example.ui.theme.BearishCrimsonSurface
import com.example.ui.theme.BullishEmerald
import com.example.ui.theme.BullishEmeraldLight
import com.example.ui.theme.BullishEmeraldSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState
import java.util.Locale
import kotlin.math.abs

data class PortfolioDialogDraft(
    val symbol: String = "",
    val companyName: String = "",
    val arabicName: String? = null,
    val sector: String? = null,
    val initialSharesCount: Double? = null,
    val initialBuyPrice: Double? = null,
    val initialNotes: String? = null,
    val isEditingExisting: Boolean = false
)

private data class PortfolioAggregateMetrics(
    val totalMarketValue: Double,
    val totalCostBasis: Double,
    val evaluatedCostBasis: Double,
    val totalProfitLossUsd: Double,
    val totalProfitLossPercent: Double,
    val totalDayChangeUsd: Double,
    val holdingsCount: Int,
    val pricedHoldingsCount: Int
)

private val AllocationPalette = listOf(
    Color(0xFF00E676),
    Color(0xFF38BDF8),
    Color(0xFFF59E0B),
    Color(0xFFA855F7),
    Color(0xFFEC4899),
    Color(0xFF14B8A6),
    Color(0xFFFB7185)
)

@Composable
fun PortfolioTabContent(
    portfolioState: CloudUiState<List<PortfolioHolding>>,
    quotes: Map<String, StockQuote>,
    isLoadingQuotes: Boolean,
    onAddHoldingClick: () -> Unit,
    onEditHoldingClick: (PortfolioHolding) -> Unit,
    onDeleteHoldingClick: (String) -> Unit,
    onSelectStock: (String) -> Unit,
    onCreateAlertForHolding: (PortfolioHolding) -> Unit,
    onRefreshQuotes: () -> Unit
) {
    val holdings = (portfolioState as? CloudUiState.Success)?.data.orEmpty()

    val metrics = remember(holdings, quotes) {
        var totalCost = 0.0
        var evaluatedCost = 0.0
        var totalMarket = 0.0
        var dayChangeUsd = 0.0
        var pricedCount = 0

        holdings.forEach { item ->
            val cost = item.totalCostBasis
            totalCost += cost
            val quote = quotes[item.symbol.uppercase()]
            if (quote != null && quote.currentPrice > 0.0) {
                val marketVal = item.sharesCount * quote.currentPrice
                totalMarket += marketVal
                evaluatedCost += cost
                dayChangeUsd += item.sharesCount * quote.change
                pricedCount++
            } else {
                // While waiting for live quote, preserve cost basis in total estimate
                totalMarket += cost
            }
        }

        val totalPnlUsd = totalMarket - totalCost
        val totalPnlPct = if (totalCost > 0.0) (totalPnlUsd / totalCost) * 100.0 else 0.0

        PortfolioAggregateMetrics(
            totalMarketValue = totalMarket,
            totalCostBasis = totalCost,
            evaluatedCostBasis = evaluatedCost,
            totalProfitLossUsd = totalPnlUsd,
            totalProfitLossPercent = totalPnlPct,
            totalDayChangeUsd = dayChangeUsd,
            holdingsCount = holdings.size,
            pricedHoldingsCount = pricedCount
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 920.dp)
            .padding(horizontal = 16.dp)
            .testTag("portfolio_tab_list"),
        contentPadding = PaddingValues(top = 14.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            PortfolioSummaryHeroCard(
                metrics = metrics,
                holdings = holdings,
                quotes = quotes,
                isLoadingQuotes = isLoadingQuotes,
                onAddHoldingClick = onAddHoldingClick,
                onRefreshQuotes = onRefreshQuotes
            )
        }

        when (portfolioState) {
            is CloudUiState.Loading -> {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                color = BullishEmerald,
                                modifier = Modifier.size(26.dp),
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "جاري مزامنة بيانات المحفظة الافتراضية من السحابة...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            is CloudUiState.Error -> {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = BearishCrimsonSurface.copy(alpha = 0.55f)),
                        border = BorderStroke(1.dp, BearishCrimson),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "تعذر تحميل المحفظة الافتراضية",
                                style = MaterialTheme.typography.titleMedium,
                                color = BearishCrimsonLight,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = portfolioState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            is CloudUiState.Success -> {
                if (holdings.isEmpty()) {
                    item {
                        EmptyPortfolioCard(onAddHoldingClick = onAddHoldingClick)
                    }
                } else {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PieChart,
                                    contentDescription = null,
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "مراكز المحفظة المفتوحة (${holdings.size})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            TextButton(
                                onClick = onAddHoldingClick,
                                modifier = Modifier.testTag("portfolio_header_add_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = BullishEmeraldLight,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("صفقة جديدة", color = BullishEmeraldLight)
                            }
                        }
                    }

                    items(holdings, key = { it.symbol }) { holding ->
                        val quote = quotes[holding.symbol.uppercase()]
                        val weightPercent = remember(holding, quote, metrics.totalMarketValue) {
                            if (metrics.totalMarketValue <= 0.0) 0.0
                            else {
                                val holdingValue = holding.marketValue(quote?.currentPrice) ?: holding.totalCostBasis
                                (holdingValue / metrics.totalMarketValue) * 100.0
                            }
                        }
                        PortfolioHoldingCard(
                            holding = holding,
                            quote = quote,
                            portfolioWeightPercent = weightPercent,
                            onCardClick = { onSelectStock(holding.symbol) },
                            onEditClick = { onEditHoldingClick(holding) },
                            onAlertClick = { onCreateAlertForHolding(holding) },
                            onDeleteClick = { onDeleteHoldingClick(holding.symbol) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PortfolioSummaryHeroCard(
    metrics: PortfolioAggregateMetrics,
    holdings: List<PortfolioHolding>,
    quotes: Map<String, StockQuote>,
    isLoadingQuotes: Boolean,
    onAddHoldingClick: () -> Unit,
    onRefreshQuotes: () -> Unit
) {
    val isProfit = metrics.totalProfitLossUsd >= 0.0
    val pnlAccent = if (isProfit) BullishEmeraldLight else BearishCrimsonLight
    val pnlSurface = if (isProfit) BullishEmeraldSurface else BearishCrimsonSurface
    val isDayPositive = metrics.totalDayChangeUsd >= 0.0

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("portfolio_summary_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ObsidianCardElevated.copy(alpha = 0.85f),
                            ObsidianCard
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = BullishEmeraldSurface,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = BullishEmeraldLight,
                            modifier = Modifier
                                .padding(10.dp)
                                .size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "المحفظة الافتراضية",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "تقييم فوري للأرباح والخسائر وفق أسعار السوق الحقيقية",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onRefreshQuotes,
                    modifier = Modifier.testTag("portfolio_refresh_quotes_btn")
                ) {
                    if (isLoadingQuotes) {
                        CircularProgressIndicator(
                            color = ElectricCyan,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تحديث أسعار المحفظة",
                            tint = ElectricCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Total Market Value Section
            Text(
                text = "إجمالي القيمة السوقية للمحفظة",
                style = MaterialTheme.typography.labelLarge,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = formatUsdPrice(metrics.totalMarketValue),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 30.sp,
                    color = TextPrimary,
                    modifier = Modifier.testTag("portfolio_total_market_value")
                )

                if (metrics.holdingsCount > 0) {
                    Surface(
                        color = pnlSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, pnlAccent.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isProfit) {
                                    Icons.AutoMirrored.Filled.TrendingUp
                                } else {
                                    Icons.AutoMirrored.Filled.TrendingDown
                                },
                                contentDescription = null,
                                tint = pnlAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = formatSignedUsdAndPercent(
                                    metrics.totalProfitLossUsd,
                                    metrics.totalProfitLossPercent
                                ),
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = pnlAccent,
                                modifier = Modifier.testTag("portfolio_total_pnl_badge")
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(14.dp))

            // Key Metrics Grid (Cost Basis, Total P&L, Day's P&L)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PortfolioMetricColumn(
                    label = "إجمالي تكلفة الشراء",
                    value = formatUsdPrice(metrics.totalCostBasis),
                    valueColor = TextPrimary,
                    testTag = "portfolio_total_cost_basis"
                )

                PortfolioMetricColumn(
                    label = "صافي الربح / الخسارة",
                    value = formatSignedUsd(metrics.totalProfitLossUsd),
                    subValue = String.format(
                        Locale.US,
                        "%s%.2f%%",
                        if (metrics.totalProfitLossPercent >= 0.0) "+" else "",
                        metrics.totalProfitLossPercent
                    ),
                    valueColor = pnlAccent,
                    testTag = "portfolio_net_pnl_value"
                )

                PortfolioMetricColumn(
                    label = "تغير اليوم (الجلسة)",
                    value = formatSignedUsd(metrics.totalDayChangeUsd),
                    valueColor = if (isDayPositive) BullishEmeraldLight else BearishCrimsonLight,
                    testTag = "portfolio_day_pnl_value"
                )
            }

            // Portfolio Allocation Distribution Bar
            if (holdings.isNotEmpty() && metrics.totalMarketValue > 0.0) {
                Spacer(modifier = Modifier.height(16.dp))
                PortfolioAllocationSection(
                    holdings = holdings,
                    quotes = quotes,
                    totalPortfolioValue = metrics.totalMarketValue
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onAddHoldingClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullishEmerald,
                    contentColor = Color(0xFF032219)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("add_portfolio_holding_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إضافة سهم أو تحديث مركز في المحفظة",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PortfolioMetricColumn(
    label: String,
    value: String,
    subValue: String? = null,
    valueColor: Color,
    testTag: String
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = valueColor,
                modifier = Modifier.testTag(testTag)
            )
            if (!subValue.isNullOrBlank()) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "($subValue)",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = valueColor
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PortfolioAllocationSection(
    holdings: List<PortfolioHolding>,
    quotes: Map<String, StockQuote>,
    totalPortfolioValue: Double
) {
    val slices = remember(holdings, quotes, totalPortfolioValue) {
        holdings.mapIndexed { index, item ->
            val quote = quotes[item.symbol.uppercase()]
            val valUsd = item.marketValue(quote?.currentPrice) ?: item.totalCostBasis
            val pct = if (totalPortfolioValue > 0.0) (valUsd / totalPortfolioValue) * 100.0 else 0.0
            Triple(item.symbol, pct.coerceIn(0.0, 100.0), AllocationPalette[index % AllocationPalette.size])
        }.sortedByDescending { it.second }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "توزيع أوزان المحفظة حسب القيمة السوقية:",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(ObsidianSurface)
        ) {
            slices.forEach { (_, pct, color) ->
                val weightVal = (pct / 100.0).toFloat().coerceAtLeast(0.02f)
                Box(
                    modifier = Modifier
                        .weight(weightVal)
                        .fillMaxHeight()
                        .background(color)
                )
            }
        }

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            slices.forEach { (symbol, pct, color) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(color)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$symbol ${String.format(Locale.US, "%.1f%%", pct)}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PortfolioHoldingCard(
    holding: PortfolioHolding,
    quote: StockQuote?,
    portfolioWeightPercent: Double,
    onCardClick: () -> Unit,
    onEditClick: () -> Unit,
    onAlertClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val livePrice = quote?.currentPrice
    val marketVal = holding.marketValue(livePrice)
    val pnlUsd = holding.profitLossUsd(livePrice)
    val pnlPct = holding.profitLossPercent(livePrice)
    val isProfit = (pnlUsd ?: 0.0) >= 0.0
    val pnlColor = if (isProfit) BullishEmeraldLight else BearishCrimsonLight
    val pnlBg = if (isProfit) BullishEmeraldSurface else BearishCrimsonSurface

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(
            1.dp,
            if (pnlUsd != null) pnlColor.copy(alpha = 0.35f) else ObsidianBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("portfolio_holding_card_${holding.symbol}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Stock Identity + Live P&L Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = ObsidianCardElevated,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, ObsidianBorder)
                        ) {
                            Text(
                                text = holding.symbol,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = ElectricCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = holding.arabicName ?: holding.companyName,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = ObsidianSurface,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = String.format(Locale.US, "%.1f%% من المحفظة", portfolioWeightPercent),
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${holding.companyName}${holding.sector?.let { " • $it" } ?: ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Position Market Value & Unrealized P&L
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (marketVal != null) formatUsdPrice(marketVal) else formatUsdPrice(holding.totalCostBasis),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = TextPrimary,
                        modifier = Modifier.testTag("holding_market_value_${holding.symbol}")
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    if (pnlUsd != null && pnlPct != null) {
                        Surface(
                            color = pnlBg,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = formatSignedUsdAndPercent(pnlUsd, pnlPct),
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = pnlColor,
                                modifier = Modifier
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                    .testTag("holding_pnl_badge_${holding.symbol}")
                            )
                        }
                    } else {
                        Text(
                            text = "جاري جلب السعر الفوري...",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeutralAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            // Position Breakdown: Shares Count, Buy Price, Current Live Price, Total Cost Basis
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HoldingDetailStat(
                    label = "عدد الأسهم",
                    value = formatSharesCount(holding.sharesCount)
                )
                HoldingDetailStat(
                    label = "سعر الشراء للسهم",
                    value = formatUsdPrice(holding.buyPrice)
                )
                HoldingDetailStat(
                    label = "السعر الحالي",
                    value = if (livePrice != null) formatUsdPrice(livePrice) else "—",
                    valueColor = if (quote != null) {
                        if (quote.change >= 0.0) BullishEmeraldLight else BearishCrimsonLight
                    } else {
                        TextSecondary
                    }
                )
                HoldingDetailStat(
                    label = "تكلفة الشراء الكلية",
                    value = formatUsdPrice(holding.totalCostBasis)
                )
            }

            if (!holding.notes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ملاحظة الصفقة: ${holding.notes}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (quote != null) {
                    Text(
                        text = "تغير السهم اليوم: ${formatSignedChange(quote.change, quote.changePercent)}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = if (quote.change >= 0.0) BullishEmeraldLight else BearishCrimsonLight
                    )
                } else {
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onAlertClick,
                        modifier = Modifier.testTag("alert_portfolio_holding_${holding.symbol}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAlert,
                            contentDescription = "إنشاء تنبيه سعري للسهم",
                            tint = GoldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier.testTag("edit_portfolio_holding_${holding.symbol}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "تعديل عدد الأسهم أو سعر الشراء",
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_portfolio_holding_${holding.symbol}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف الصفقة من المحفظة",
                            tint = BearishCrimsonLight,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HoldingDetailStat(
    label: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Text(
            text = value,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            color = valueColor
        )
    }
}

@Composable
private fun EmptyPortfolioCard(
    onAddHoldingClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("empty_portfolio_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                color = BullishEmeraldSurface,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = BullishEmeraldLight,
                    modifier = Modifier
                        .padding(16.dp)
                        .size(34.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "محفظتك الافتراضية فارغة حالياً",
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "أضف الأسهم التي اشتريتها أو ترغب بمحاكاة شرائها مع تحديد عدد الأسهم وسعر الشراء، وسيقوم التطبيق بحساب إجمالي قيمة المحفظة ونسبة الربح أو الخسارة لحظة بلحظة بالاعتماد على الأسعار الفورية للسوق الأمريكي.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onAddHoldingClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullishEmerald,
                    contentColor = Color(0xFF032219)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("empty_portfolio_add_btn")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة أول صفقة للمحفظة", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrEditPortfolioHoldingDialog(
    draft: PortfolioDialogDraft,
    quotes: Map<String, StockQuote>,
    onRequestQuoteForSymbol: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: (
        symbol: String,
        companyName: String,
        arabicName: String?,
        sector: String?,
        sharesCount: Double,
        buyPrice: Double,
        notes: String?
    ) -> Unit
) {
    var symbolText by remember(draft) {
        mutableStateOf(
            draft.symbol.ifBlank { UsStockCatalog.majorUsStocks.first().symbol }
        )
    }
    val cleanSymbol = symbolText.trim().uppercase()
    val matchedCurated = remember(cleanSymbol) { UsStockCatalog.findBySymbol(cleanSymbol) }
    val liveQuote = quotes[cleanSymbol]

    LaunchedEffect(cleanSymbol) {
        if (cleanSymbol.isNotBlank() && liveQuote == null) {
            onRequestQuoteForSymbol(cleanSymbol)
        }
    }

    var sharesText by remember(draft) {
        mutableStateOf(
            draft.initialSharesCount?.takeIf { it > 0.0 }?.let { formatSharesInput(it) } ?: "10"
        )
    }
    var buyPriceText by remember(draft) {
        val initialPrice = draft.initialBuyPrice?.takeIf { it > 0.0 }
            ?: liveQuote?.currentPrice?.takeIf { it > 0.0 }
        mutableStateOf(
            initialPrice?.let { String.format(Locale.US, "%.2f", it) }.orEmpty()
        )
    }
    var notesText by remember(draft) {
        mutableStateOf(draft.initialNotes.orEmpty())
    }
    var validationError by remember { mutableStateOf<String?>(null) }

    // Auto-fill buy price when live quote arrives if user hasn't typed one yet
    LaunchedEffect(liveQuote?.currentPrice) {
        val price = liveQuote?.currentPrice
        if (buyPriceText.isBlank() && price != null && price > 0.0) {
            buyPriceText = String.format(Locale.US, "%.2f", price)
        }
    }

    val parsedShares = sharesText.trim().toDoubleOrNull() ?: 0.0
    val parsedBuyPrice = buyPriceText.trim().toDoubleOrNull() ?: 0.0
    val previewCostBasis = if (parsedShares > 0.0 && parsedBuyPrice > 0.0) {
        parsedShares * parsedBuyPrice
    } else {
        0.0
    }
    val previewMarketValue = if (parsedShares > 0.0 && liveQuote != null && liveQuote.currentPrice > 0.0) {
        parsedShares * liveQuote.currentPrice
    } else {
        null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianCard,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        modifier = Modifier.testTag("portfolio_holding_dialog"),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = BullishEmeraldLight
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (draft.isEditingExisting) {
                        "تعديل مركز $cleanSymbol في المحفظة"
                    } else {
                        "إضافة صفقة للمحفظة الافتراضية"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (!draft.isEditingExisting) {
                    Text(
                        text = "اختر السهم الأمريكي:",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(UsStockCatalog.majorUsStocks, key = { it.symbol }) { stock ->
                            val selected = stock.symbol.equals(cleanSymbol, ignoreCase = true)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    symbolText = stock.symbol
                                    val qPrice = quotes[stock.symbol]?.currentPrice
                                    if (qPrice != null && qPrice > 0.0) {
                                        buyPriceText = String.format(Locale.US, "%.2f", qPrice)
                                    }
                                    validationError = null
                                },
                                label = {
                                    Text("${stock.arabicName} (${stock.symbol})")
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BullishEmerald,
                                    selectedLabelColor = Color(0xFF032219)
                                ),
                                modifier = Modifier.testTag("portfolio_chip_${stock.symbol}")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = symbolText,
                        onValueChange = {
                            symbolText = it.uppercase().take(12)
                            validationError = null
                        },
                        label = { Text("رمز السهم (Ticker Symbol)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("portfolio_symbol_input")
                    )
                }

                // Live Market Price Indicator + Quick Fill
                if (liveQuote != null && liveQuote.currentPrice > 0.0) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "السعر الفوري (${liveQuote.arabicName}):",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = formatUsdPrice(liveQuote.currentPrice),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricCyan
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    buyPriceText = String.format(Locale.US, "%.2f", liveQuote.currentPrice)
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("use_live_price_button")
                            ) {
                                Text("اعتماد السعر الحالي", fontSize = 11.sp, color = ElectricCyan)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = sharesText,
                    onValueChange = {
                        sharesText = it
                        validationError = null
                    },
                    label = { Text("عدد الأسهم المشتراة") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("portfolio_shares_input")
                )

                OutlinedTextField(
                    value = buyPriceText,
                    onValueChange = {
                        buyPriceText = it
                        validationError = null
                    },
                    label = { Text("سعر الشراء للسهم بالدولار (USD)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("portfolio_buy_price_input")
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it.take(500) },
                    label = { Text("ملاحظات الصفقة (اختياري)") },
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("portfolio_notes_input")
                )

                // Instant Cost Basis & Live P&L Preview
                if (previewCostBasis > 0.0) {
                    Surface(
                        color = ObsidianSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "إجمالي تكلفة الشراء:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = formatUsdPrice(previewCostBasis),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                            if (previewMarketValue != null) {
                                val diffUsd = previewMarketValue - previewCostBasis
                                val diffPct = (diffUsd / previewCostBasis) * 100.0
                                val isPos = diffUsd >= 0.0
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "الربح / الخسارة مقابل السعر الفوري:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = formatSignedUsdAndPercent(diffUsd, diffPct),
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isPos) BullishEmeraldLight else BearishCrimsonLight
                                    )
                                }
                            }
                        }
                    }
                }

                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = BearishCrimsonLight
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val shares = sharesText.trim().toDoubleOrNull()
                    val buyPrice = buyPriceText.trim().toDoubleOrNull()
                    when {
                        cleanSymbol.isBlank() || !cleanSymbol.matches(Regex("^[A-Z0-9.\\-]+$")) -> {
                            validationError = "يرجى إدخال رمز سهم أمريكي صحيح بالأحرف الإنجليزية (مثل NVDA أو AAPL)."
                        }
                        shares == null || shares <= 0.0 -> {
                            validationError = "يرجى إدخال عدد أسهم صحيح أكبر من صفر."
                        }
                        buyPrice == null || buyPrice <= 0.0 -> {
                            validationError = "يرجى إدخال سعر شراء صحيح أكبر من صفر."
                        }
                        else -> {
                            val resolvedCompany = draft.companyName.ifBlank {
                                liveQuote?.companyName ?: matchedCurated?.companyName ?: cleanSymbol
                            }
                            val resolvedArabic = draft.arabicName?.takeIf { it.isNotBlank() }
                                ?: liveQuote?.arabicName
                                ?: matchedCurated?.arabicName
                            val resolvedSector = draft.sector?.takeIf { it.isNotBlank() }
                                ?: liveQuote?.sector
                                ?: matchedCurated?.sector

                            onConfirm(
                                cleanSymbol,
                                resolvedCompany,
                                resolvedArabic,
                                resolvedSector,
                                shares,
                                buyPrice,
                                notesText.trim().ifEmpty { null }
                            )
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullishEmerald,
                    contentColor = Color(0xFF032219)
                ),
                modifier = Modifier.testTag("confirm_save_portfolio_button")
            ) {
                Text("حفظ في المحفظة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondary)
            }
        }
    )
}

private fun formatSignedUsd(amount: Double): String {
    val sign = if (amount >= 0.0) "+" else "-"
    return String.format(Locale.US, "%s$%,.2f", sign, abs(amount))
}

private fun formatSignedUsdAndPercent(amountUsd: Double, percent: Double): String {
    val sign = if (amountUsd >= 0.0) "+" else "-"
    return String.format(
        Locale.US,
        "%s$%,.2f (%s%.2f%%)",
        sign,
        abs(amountUsd),
        sign,
        abs(percent)
    )
}

private fun formatSharesCount(shares: Double): String {
    return if (shares % 1.0 == 0.0) {
        String.format(Locale.US, "%,.0f سهم", shares)
    } else {
        String.format(Locale.US, "%,.4f سهم", shares).trimEnd('0').trimEnd('.')
    }
}

private fun formatSharesInput(shares: Double): String {
    return if (shares % 1.0 == 0.0) {
        String.format(Locale.US, "%.0f", shares)
    } else {
        shares.toString()
    }
}
