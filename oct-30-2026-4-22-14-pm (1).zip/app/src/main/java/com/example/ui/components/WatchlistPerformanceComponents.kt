package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StockQuote
import com.example.data.model.WatchlistStock
import com.example.ui.theme.BearishCrimson
import com.example.ui.theme.BearishCrimsonLight
import com.example.ui.theme.BearishCrimsonSurface
import com.example.ui.theme.BullishEmerald
import com.example.ui.theme.BullishEmeraldLight
import com.example.ui.theme.BullishEmeraldSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.NeutralAmberLight
import com.example.ui.theme.NeutralAmberSurface
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

enum class WatchlistSortAndCategoryMode(
    val arabicLabel: String,
    val testTag: String
) {
    AUTO_GROUPED("تصنيف تلقائي للأداء", "watchlist_mode_auto_grouped"),
    TOP_GAINERS_FIRST("الأعلى ارتفاعاً", "watchlist_mode_top_gainers"),
    TOP_LOSERS_FIRST("الأكثر انخفاضاً", "watchlist_mode_top_losers"),
    GAINERS_ONLY("الرابحة فقط ↑", "watchlist_mode_gainers_only"),
    LOSERS_ONLY("المتراجعة فقط ↓", "watchlist_mode_losers_only"),
    ALPHABETICAL("أبجدياً A-Z", "watchlist_mode_alphabetical")
}

enum class StockPerformanceTier(
    val arabicTitle: String,
    val badgeLabel: String
) {
    TOP_GAINER("الأعلى ارتفاعاً", "الأعلى ارتفاعاً اليوم"),
    RISING("أسهم صاعدة", "أداء إيجابي صاعد"),
    TOP_LOSER("الأكثر انخفاضاً", "الأكثر انخفاضاً اليوم"),
    DECLINING("أسهم منخفضة", "أداء سلبي متراجع"),
    FLAT("أداء مستقر", "مستقر دون تغير")
}

data class CategorizedWatchlistItem(
    val stock: WatchlistStock,
    val quote: StockQuote?,
    val tier: StockPerformanceTier,
    val rankInGroup: Int
)

data class WatchlistPerformanceSummary(
    val topGainer: Pair<WatchlistStock, StockQuote>?,
    val topLoser: Pair<WatchlistStock, StockQuote>?,
    val gainersCount: Int,
    val losersCount: Int,
    val flatCount: Int,
    val averageChangePercent: Double,
    val gainersGroup: List<CategorizedWatchlistItem>,
    val losersGroup: List<CategorizedWatchlistItem>,
    val flatOrPendingGroup: List<CategorizedWatchlistItem>
)

fun evaluateWatchlistPerformance(
    stocks: List<WatchlistStock>,
    quotes: Map<String, StockQuote>
): WatchlistPerformanceSummary {
    val withQuotes = stocks.map { stock ->
        stock to quotes[stock.symbol.uppercase()]
    }

    val gainersRaw = withQuotes
        .filter { (_, q) -> q != null && q.changePercent > 0.0 }
        .sortedByDescending { (_, q) -> q?.changePercent ?: 0.0 }

    val losersRaw = withQuotes
        .filter { (_, q) -> q != null && q.changePercent < 0.0 }
        .sortedBy { (_, q) -> q?.changePercent ?: 0.0 } // Most negative first

    val flatOrPendingRaw = withQuotes
        .filter { (_, q) -> q == null || q.changePercent == 0.0 }
        .sortedBy { (s, _) -> s.symbol }

    val topGainer = gainersRaw.firstOrNull()?.let { (s, q) -> s to q!! }
    val topLoser = losersRaw.firstOrNull()?.let { (s, q) -> s to q!! }

    val pricedQuotes = withQuotes.mapNotNull { it.second }
    val avgChangePct = if (pricedQuotes.isNotEmpty()) {
        pricedQuotes.sumOf { it.changePercent } / pricedQuotes.size
    } else {
        0.0
    }

    val gainersGroup = gainersRaw.mapIndexed { index, (stock, quote) ->
        CategorizedWatchlistItem(
            stock = stock,
            quote = quote,
            tier = if (index == 0) StockPerformanceTier.TOP_GAINER else StockPerformanceTier.RISING,
            rankInGroup = index + 1
        )
    }

    val losersGroup = losersRaw.mapIndexed { index, (stock, quote) ->
        CategorizedWatchlistItem(
            stock = stock,
            quote = quote,
            tier = if (index == 0) StockPerformanceTier.TOP_LOSER else StockPerformanceTier.DECLINING,
            rankInGroup = index + 1
        )
    }

    val flatGroup = flatOrPendingRaw.mapIndexed { index, (stock, quote) ->
        CategorizedWatchlistItem(
            stock = stock,
            quote = quote,
            tier = StockPerformanceTier.FLAT,
            rankInGroup = index + 1
        )
    }

    return WatchlistPerformanceSummary(
        topGainer = topGainer,
        topLoser = topLoser,
        gainersCount = gainersGroup.size,
        losersCount = losersGroup.size,
        flatCount = flatGroup.size,
        averageChangePercent = avgChangePct,
        gainersGroup = gainersGroup,
        losersGroup = losersGroup,
        flatOrPendingGroup = flatGroup
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WatchlistPerformanceOverviewCard(
    summary: WatchlistPerformanceSummary,
    selectedMode: WatchlistSortAndCategoryMode,
    onSelectMode: (WatchlistSortAndCategoryMode) -> Unit,
    onSelectStock: (String) -> Unit
) {
    val isAvgPositive = summary.averageChangePercent >= 0.0

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("watchlist_performance_overview_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ObsidianCardElevated.copy(alpha = 0.8f),
                            ObsidianCard
                        )
                    )
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoGraph,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "التصنيف التلقائي لأداء المفضلة",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "نظرة فورية على الأسهم الأعلى ارتفاعاً والأكثر انخفاضاً اليوم",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    color = if (isAvgPositive) BullishEmeraldSurface else BearishCrimsonSurface,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = String.format(
                            Locale.US,
                            "متوسط المفضلة: %s%.2f%%",
                            if (isAvgPositive) "+" else "",
                            summary.averageChangePercent
                        ),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (isAvgPositive) BullishEmeraldLight else BearishCrimsonLight,
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("watchlist_avg_change_badge")
                    )
                }
            }

            // Top Gainer & Top Loser Spotlight Cards
            if (summary.topGainer != null || summary.topLoser != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val gainer = summary.topGainer
                    if (gainer != null) {
                        PerformanceSpotlightBox(
                            title = "الأعلى ارتفاعاً ↑",
                            stock = gainer.first,
                            quote = gainer.second,
                            isPositive = true,
                            onClick = { onSelectStock(gainer.first.symbol) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("watchlist_top_gainer_spotlight")
                        )
                    }

                    val loser = summary.topLoser
                    if (loser != null) {
                        PerformanceSpotlightBox(
                            title = "الأكثر انخفاضاً ↓",
                            stock = loser.first,
                            quote = loser.second,
                            isPositive = false,
                            onClick = { onSelectStock(loser.first.symbol) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("watchlist_top_loser_spotlight")
                        )
                    }
                }
            }

            // Summary Counts Bar
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(BullishEmeraldLight)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "أسهم مرتفعة: ${summary.gainersCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = BullishEmeraldLight,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(BearishCrimsonLight)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "أسهم منخفضة: ${summary.losersCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = BearishCrimsonLight,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (summary.flatCount > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(NeutralAmberLight)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "مستقرة: ${summary.flatCount}",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }
            }

            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))

            // Sort & Automatic Category Filter Chips
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Sort,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ترتيب وتصنيف القائمة المفضلة حسب الأداء:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(WatchlistSortAndCategoryMode.entries, key = { it.name }) { mode ->
                        val selected = selectedMode == mode
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectMode(mode) },
                            label = {
                                Text(
                                    text = mode.arabicLabel,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = when (mode) {
                                    WatchlistSortAndCategoryMode.TOP_GAINERS_FIRST,
                                    WatchlistSortAndCategoryMode.GAINERS_ONLY -> BullishEmerald
                                    WatchlistSortAndCategoryMode.TOP_LOSERS_FIRST,
                                    WatchlistSortAndCategoryMode.LOSERS_ONLY -> BearishCrimson
                                    else -> ElectricCyan
                                },
                                selectedLabelColor = when (mode) {
                                    WatchlistSortAndCategoryMode.TOP_LOSERS_FIRST,
                                    WatchlistSortAndCategoryMode.LOSERS_ONLY -> Color.White
                                    else -> Color(0xFF032219)
                                }
                            ),
                            modifier = Modifier.testTag(mode.testTag)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PerformanceSpotlightBox(
    title: String,
    stock: WatchlistStock,
    quote: StockQuote,
    isPositive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = if (isPositive) BullishEmeraldLight else BearishCrimsonLight
    val surfaceColor = if (isPositive) BullishEmeraldSurface.copy(alpha = 0.65f) else BearishCrimsonSurface.copy(alpha = 0.65f)

    Surface(
        color = surfaceColor,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = accent,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = if (isPositive) {
                        Icons.AutoMirrored.Filled.TrendingUp
                    } else {
                        Icons.AutoMirrored.Filled.TrendingDown
                    },
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stock.arabicName ?: stock.symbol,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = stock.symbol,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = formatUsdPrice(quote.currentPrice),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )
                Text(
                    text = String.format(
                        Locale.US,
                        "%s%.2f%%",
                        if (quote.changePercent >= 0.0) "+" else "",
                        quote.changePercent
                    ),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = accent
                )
            }
        }
    }
}

@Composable
fun WatchlistCategorySectionHeader(
    title: String,
    subtitle: String,
    count: Int,
    isPositiveSection: Boolean?,
    testTag: String
) {
    val accentColor = when (isPositiveSection) {
        true -> BullishEmeraldLight
        false -> BearishCrimsonLight
        null -> NeutralAmberLight
    }
    val surfaceColor = when (isPositiveSection) {
        true -> BullishEmeraldSurface
        false -> BearishCrimsonSurface
        null -> NeutralAmberSurface
    }
    val icon = when (isPositiveSection) {
        true -> Icons.AutoMirrored.Filled.TrendingUp
        false -> Icons.AutoMirrored.Filled.TrendingDown
        null -> Icons.AutoMirrored.Filled.TrendingFlat
    }

    Surface(
        color = ObsidianSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = surfaceColor,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier
                            .padding(6.dp)
                            .size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Surface(
                color = surfaceColor,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "$count أسهم",
                    style = MaterialTheme.typography.labelMedium,
                    color = accentColor,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun WatchlistPerformanceTierBadge(
    tier: StockPerformanceTier,
    rankInGroup: Int
) {
    val (bgColor, textColor, label) = remember(tier, rankInGroup) {
        when (tier) {
            StockPerformanceTier.TOP_GAINER -> Triple(
                BullishEmeraldSurface,
                BullishEmeraldLight,
                "الأعلى ارتفاعاً #1"
            )
            StockPerformanceTier.RISING -> Triple(
                BullishEmeraldSurface.copy(alpha = 0.7f),
                BullishEmeraldLight,
                "صاعد #$rankInGroup"
            )
            StockPerformanceTier.TOP_LOSER -> Triple(
                BearishCrimsonSurface,
                BearishCrimsonLight,
                "الأكثر انخفاضاً #1"
            )
            StockPerformanceTier.DECLINING -> Triple(
                BearishCrimsonSurface.copy(alpha = 0.7f),
                BearishCrimsonLight,
                "منخفض #$rankInGroup"
            )
            StockPerformanceTier.FLAT -> Triple(
                NeutralAmberSurface,
                NeutralAmberLight,
                "مستقر"
            )
        }
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(0.8.dp, textColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (tier == StockPerformanceTier.TOP_GAINER) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = textColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
