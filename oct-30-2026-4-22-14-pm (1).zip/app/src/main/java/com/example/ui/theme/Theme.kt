package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = AppThemeSettings.isDarkMode,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = BullishEmerald,
            onPrimary = Color(0xFF032219),
            primaryContainer = BullishEmeraldSurface,
            onPrimaryContainer = BullishEmeraldLight,
            secondary = ElectricCyan,
            onSecondary = Color(0xFF032329),
            secondaryContainer = Color(0xFF0A3642),
            onSecondaryContainer = Color(0xFF67E8F9),
            tertiary = GoldAccent,
            onTertiary = Color(0xFF2B1E02),
            tertiaryContainer = NeutralAmberSurface,
            onTertiaryContainer = NeutralAmberLight,
            background = ObsidianBackground,
            onBackground = TextPrimary,
            surface = ObsidianSurface,
            onSurface = TextPrimary,
            surfaceVariant = ObsidianCard,
            onSurfaceVariant = TextSecondary,
            outline = ObsidianBorder,
            error = BearishCrimson,
            onError = Color.White,
            errorContainer = BearishCrimsonSurface,
            onErrorContainer = BearishCrimsonLight
        )
    } else {
        lightColorScheme(
            primary = BullishEmerald,
            onPrimary = Color.White,
            primaryContainer = BullishEmeraldSurface,
            onPrimaryContainer = BullishEmeraldLight,
            secondary = ElectricCyan,
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFE0F2FE),
            onSecondaryContainer = Color(0xFF0369A1),
            tertiary = GoldAccent,
            onTertiary = Color.White,
            tertiaryContainer = NeutralAmberSurface,
            onTertiaryContainer = NeutralAmberLight,
            background = ObsidianBackground,
            onBackground = TextPrimary,
            surface = ObsidianSurface,
            onSurface = TextPrimary,
            surfaceVariant = ObsidianCardElevated,
            onSurfaceVariant = TextSecondary,
            outline = ObsidianBorder,
            error = BearishCrimson,
            onError = Color.White,
            errorContainer = BearishCrimsonSurface,
            onErrorContainer = BearishCrimsonLight
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
