package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.InsufficientHistoricalDataException
import com.example.data.ai.NewsAiAnalyzer
import com.example.data.ai.StockPredictionEngine
import com.example.data.model.AlertCondition
import com.example.data.model.CompanyNewsItem
import com.example.data.model.CuratedUsStock
import com.example.data.model.DailyWatchlistSummary
import com.example.data.model.HistoricalCandle
import com.example.data.model.PortfolioHolding
import com.example.data.model.PredictionHorizon
import com.example.data.model.PriceAlert
import com.example.data.model.SavedNewsAnalysis
import com.example.data.model.StockPredictionUiState
import com.example.data.model.StockQuote
import com.example.data.model.UsStockCatalog
import com.example.data.model.WatchlistStock
import com.example.data.remote.MarketDataRepository
import com.example.data.repository.WatchlistRepository
import com.example.notifications.FcmPushManager
import com.example.notifications.FcmSubscriptionState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

private const val TAG = "StockPulseViewModel"

sealed interface CloudUiState<out T> {
    data object Loading : CloudUiState<Nothing>
    data class Success<T>(val data: T) : CloudUiState<T>
    data class Error(val message: String) : CloudUiState<Nothing>
}

enum class SentimentFilter(val arabicLabel: String) {
    ALL("جميع الأخبار"),
    POSITIVE("إيجابية"),
    NEGATIVE("سلبية"),
    NEUTRAL("محايدة")
}

data class TriggeredAlertNotificationEvent(
    val eventId: String,
    val alert: PriceAlert,
    val currentPrice: Double
)

sealed interface DailySummaryUiState {
    data object Idle : DailySummaryUiState
    data object EmptyWatchlist : DailySummaryUiState
    data class Loading(val symbols: List<String>) : DailySummaryUiState
    data class Success(val summary: DailyWatchlistSummary) : DailySummaryUiState
    data class Error(val message: String, val symbols: List<String>) : DailySummaryUiState
}

data class MarketUiState(
    val quotes: Map<String, StockQuote> = emptyMap(),
    val isLoadingQuotes: Boolean = false,
    val quotesError: String? = null,
    val lastQuotesRefreshMillis: Long = 0L,
    val searchQuery: String = "",
    val searchResults: List<CuratedUsStock> = UsStockCatalog.majorUsStocks,
    val isSearching: Boolean = false,
    val selectedStockSymbol: String? = null,
    val selectedNewsSymbolFilter: String? = null,
    val selectedSentimentFilter: SentimentFilter = SentimentFilter.ALL,
    val newsItems: List<CompanyNewsItem> = emptyList(),
    val isLoadingNews: Boolean = false,
    val newsError: String? = null,
    val lastNewsRefreshMillis: Long = 0L,
    val isBatchAnalyzing: Boolean = false,
    val dailySummaryState: DailySummaryUiState = DailySummaryUiState.Idle,
    val isDailySummaryVisible: Boolean = true,
    val predictionSymbol: String = "NVDA",
    val predictionHorizon: PredictionHorizon = PredictionHorizon.DAYS_7,
    val predictionState: StockPredictionUiState = StockPredictionUiState.Idle,
    val pendingAlertNotifications: List<TriggeredAlertNotificationEvent> = emptyList(),
    val snackbarMessage: String? = null
)

class StockPulseViewModel(
    private val watchlistRepository: WatchlistRepository,
    private val marketDataRepository: MarketDataRepository,
    private val newsAiAnalyzer: NewsAiAnalyzer,
    private val currentUserId: String,
    private val stockPredictionEngine: StockPredictionEngine = StockPredictionEngine()
) : ViewModel() {

    private val _uiState = MutableStateFlow(MarketUiState())
    val uiState: StateFlow<MarketUiState> = _uiState.asStateFlow()

    val fcmState: StateFlow<FcmSubscriptionState> = FcmPushManager.state

    val watchlistState: StateFlow<CloudUiState<List<WatchlistStock>>> =
        watchlistRepository.observeWatchlist(currentUserId)
            .map<List<WatchlistStock>, CloudUiState<List<WatchlistStock>>> {
                CloudUiState.Success(it)
            }
            .catch { error ->
                Log.w(TAG, "Error observing watchlist", error)
                emit(CloudUiState.Error(error.localizedMessage ?: "تعذر مزامنة قائمة الشركات المفضلة"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = CloudUiState.Loading
            )

    val priceAlertsState: StateFlow<CloudUiState<List<PriceAlert>>> =
        watchlistRepository.observePriceAlerts(currentUserId)
            .map<List<PriceAlert>, CloudUiState<List<PriceAlert>>> {
                CloudUiState.Success(it)
            }
            .catch { error ->
                Log.w(TAG, "Error observing price alerts", error)
                emit(CloudUiState.Error(error.localizedMessage ?: "تعذر مزامنة تنبيهات الأسعار"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = CloudUiState.Loading
            )

    val savedAnalysesState: StateFlow<CloudUiState<List<SavedNewsAnalysis>>> =
        watchlistRepository.observeSavedAnalyses(currentUserId)
            .map<List<SavedNewsAnalysis>, CloudUiState<List<SavedNewsAnalysis>>> {
                CloudUiState.Success(it)
            }
            .catch { error ->
                Log.w(TAG, "Error observing saved analyses", error)
                emit(CloudUiState.Error(error.localizedMessage ?: "تعذر تحميل التحليلات المحفوظة"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = CloudUiState.Loading
            )

    val portfolioState: StateFlow<CloudUiState<List<PortfolioHolding>>> =
        watchlistRepository.observePortfolioHoldings(currentUserId)
            .map<List<PortfolioHolding>, CloudUiState<List<PortfolioHolding>>> {
                CloudUiState.Success(it)
            }
            .catch { error ->
                Log.w(TAG, "Error observing portfolio holdings", error)
                emit(CloudUiState.Error(error.localizedMessage ?: "تعذر مزامنة المحفظة الافتراضية"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = CloudUiState.Loading
            )

    private val locallyDispatchedAlertIds = mutableSetOf<String>()
    private val historicalCandlesCache = mutableMapOf<String, List<HistoricalCandle>>()
    private var lastSummarizedWatchlistSignature: String? = null
    private var searchJob: Job? = null
    private var autoRefreshJob: Job? = null
    private var dailySummaryJob: Job? = null
    private var predictionJob: Job? = null

    init {
        viewModelScope.launch {
            FcmPushManager.initializeAndFetchToken()
        }
        refreshMarketQuotes()
        refreshCompanyNews()
        startPeriodicQuoteRefresh()
        observeAlertsAgainstCurrentQuotes()
        observePortfolioHoldingsQuotes()
        observeWatchlistForDailySummary()
        runStockPrediction(symbol = "NVDA", horizon = PredictionHorizon.DAYS_7)
    }

    private fun observePortfolioHoldingsQuotes() {
        viewModelScope.launch {
            portfolioState.collect { state ->
                if (state is CloudUiState.Success) {
                    val missingSymbols = state.data
                        .map { it.symbol.trim().uppercase() }
                        .filter { it.isNotBlank() && !_uiState.value.quotes.containsKey(it) }
                        .distinct()
                    if (missingSymbols.isNotEmpty()) {
                        marketDataRepository.fetchQuotesForSymbols(missingSymbols)
                            .onSuccess { newQuotes ->
                                val updatedMap = _uiState.value.quotes + newQuotes.associateBy { it.symbol }
                                _uiState.update {
                                    it.copy(
                                        quotes = updatedMap,
                                        lastQuotesRefreshMillis = System.currentTimeMillis()
                                    )
                                }
                            }
                    }
                }
            }
        }
    }

    private fun observeWatchlistForDailySummary() {
        viewModelScope.launch {
            watchlistState.collect { state ->
                if (state is CloudUiState.Success) {
                    val watchlistSymbols = state.data
                        .map { it.symbol.trim().uppercase() }
                        .filter { it.isNotBlank() }
                        .distinct()

                    if (watchlistSymbols.isEmpty()) {
                        lastSummarizedWatchlistSignature = ""
                        if (_uiState.value.dailySummaryState is DailySummaryUiState.Idle) {
                            _uiState.update {
                                it.copy(dailySummaryState = DailySummaryUiState.EmptyWatchlist)
                            }
                        }
                    } else {
                        val signature = watchlistSymbols.sorted().joinToString(",")
                        if (signature != lastSummarizedWatchlistSignature) {
                            lastSummarizedWatchlistSignature = signature
                            generateDailySummary(useMajorMarketFallback = false)
                        }
                    }
                }
            }
        }
    }

    fun generateDailySummary(useMajorMarketFallback: Boolean = false) {
        dailySummaryJob?.cancel()
        dailySummaryJob = viewModelScope.launch {
            val watchlistSymbols = (watchlistState.value as? CloudUiState.Success)
                ?.data
                ?.map { it.symbol.trim().uppercase() }
                ?.filter { it.isNotBlank() }
                ?.distinct()
                .orEmpty()

            val targetSymbols = if (watchlistSymbols.isNotEmpty()) {
                watchlistSymbols.take(6)
            } else if (useMajorMarketFallback) {
                listOf("NVDA", "AAPL", "MSFT", "TSLA", "GOOGL")
            } else {
                _uiState.update {
                    it.copy(
                        dailySummaryState = DailySummaryUiState.EmptyWatchlist,
                        isDailySummaryVisible = true
                    )
                }
                return@launch
            }

            _uiState.update {
                it.copy(
                    dailySummaryState = DailySummaryUiState.Loading(targetSymbols),
                    isDailySummaryVisible = true
                )
            }

            // Ensure we have live quotes & company news for the target watchlist symbols
            val missingQuotes = targetSymbols.filter { !_uiState.value.quotes.containsKey(it) }
            if (missingQuotes.isNotEmpty()) {
                marketDataRepository.fetchQuotesForSymbols(missingQuotes).onSuccess { newQuotes ->
                    _uiState.update { st ->
                        st.copy(quotes = st.quotes + newQuotes.associateBy { q -> q.symbol })
                    }
                }
            }

            val existingTargetNews = _uiState.value.newsItems.filter {
                targetSymbols.contains(it.symbol.uppercase())
            }
            val articlesForSummary = if (existingTargetNews.size >= 2) {
                existingTargetNews
            } else {
                val fetched = marketDataRepository.fetchCompanyNews(targetSymbols).getOrNull().orEmpty()
                if (fetched.isNotEmpty()) {
                    val existingById = _uiState.value.newsItems.associateBy { it.id }
                    val mergedAll = (fetched.map { item ->
                        val prev = existingById[item.id]
                        if (prev?.aiAnalysis != null) item.copy(aiAnalysis = prev.aiAnalysis) else item
                    } + _uiState.value.newsItems).distinctBy { it.id }
                        .sortedByDescending { it.publishedAtMillis }
                    _uiState.update { st -> st.copy(newsItems = mergedAll) }
                    fetched
                } else {
                    existingTargetNews
                }
            }

            if (articlesForSummary.isEmpty()) {
                _uiState.update {
                    it.copy(
                        dailySummaryState = DailySummaryUiState.Error(
                            message = "لا تتوفر أخبار منشورة حالياً من المصادر المعتمدة للشركات المفضلة (${targetSymbols.joinToString(", ")}).",
                            symbols = targetSymbols
                        )
                    )
                }
                return@launch
            }

            val result = newsAiAnalyzer.generateDailyWatchlistSummary(
                targetSymbols = targetSymbols,
                newsItems = articlesForSummary,
                quotes = _uiState.value.quotes
            )

            result.fold(
                onSuccess = { summary ->
                    _uiState.update {
                        it.copy(
                            dailySummaryState = DailySummaryUiState.Success(summary),
                            isDailySummaryVisible = true
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            dailySummaryState = DailySummaryUiState.Error(
                                message = error.localizedMessage
                                    ?: "تعذر تلخيص أخبار اليوم باستخدام Gemini حالياً.",
                                symbols = targetSymbols
                            )
                        )
                    }
                }
            )
        }
    }

    fun dismissDailySummaryCard() {
        _uiState.update { it.copy(isDailySummaryVisible = false) }
    }

    fun showDailySummaryCard() {
        _uiState.update { it.copy(isDailySummaryVisible = true) }
    }

    private fun observeAlertsAgainstCurrentQuotes() {
        viewModelScope.launch {
            priceAlertsState.collect { state ->
                if (state is CloudUiState.Success) {
                    val activeAlerts = state.data.filter { it.isEnabled && !it.isTriggered }
                    val activeSymbolsSet = activeAlerts.map { it.symbol.uppercase() }.toSet()
                    launch {
                        FcmPushManager.syncStockAlertTopics(activeSymbolsSet)
                    }
                    // Fetch quotes for any alert symbol not yet loaded
                    val missingSymbols = activeSymbolsSet
                        .filter { !_uiState.value.quotes.containsKey(it) }
                    if (missingSymbols.isNotEmpty()) {
                        marketDataRepository.fetchQuotesForSymbols(missingSymbols)
                            .onSuccess { newQuotes ->
                                val updatedMap = _uiState.value.quotes + newQuotes.associateBy { it.symbol }
                                _uiState.update { it.copy(quotes = updatedMap) }
                                evaluatePriceAlerts(updatedMap, state.data)
                            }
                    } else {
                        evaluatePriceAlerts(_uiState.value.quotes, state.data)
                    }
                }
            }
        }
    }

    fun syncFcmPushSubscriptions() {
        viewModelScope.launch {
            FcmPushManager.initializeAndFetchToken()
            val activeSymbols = (priceAlertsState.value as? CloudUiState.Success)?.data
                ?.filter { it.isEnabled && !it.isTriggered }
                ?.map { it.symbol.uppercase() }
                ?.toSet()
                .orEmpty()
            FcmPushManager.syncStockAlertTopics(activeSymbols)
            showSnackbar("تمت مزامنة اشتراكات الإشعارات الفورية (Firebase Messaging) بنجاح")
        }
    }

    private fun startPeriodicQuoteRefresh() {
        autoRefreshJob?.cancel()
        autoRefreshJob = viewModelScope.launch {
            while (isActive) {
                delay(45_000L)
                refreshMarketQuotes(silent = true)
            }
        }
    }

    fun refreshMarketQuotes(silent: Boolean = false) {
        viewModelScope.launch {
            if (!silent) {
                _uiState.update { it.copy(isLoadingQuotes = true, quotesError = null) }
            }
            val watchlistSymbols = (watchlistState.value as? CloudUiState.Success)
                ?.data?.map { it.symbol }.orEmpty()
            val portfolioSymbols = (portfolioState.value as? CloudUiState.Success)
                ?.data?.map { it.symbol }.orEmpty()
            val alertSymbols = (priceAlertsState.value as? CloudUiState.Success)
                ?.data?.filter { it.isEnabled && !it.isTriggered }
                ?.map { it.symbol }.orEmpty()
            val defaultSymbols = UsStockCatalog.majorUsStocks.take(10).map { it.symbol }
            val symbolsToFetch = (watchlistSymbols + portfolioSymbols + alertSymbols + defaultSymbols).distinct()

            val result = marketDataRepository.fetchQuotesForSymbols(symbolsToFetch)
            result.fold(
                onSuccess = { quoteList ->
                    val quoteMap = _uiState.value.quotes + quoteList.associateBy { it.symbol }
                    _uiState.update { state ->
                        state.copy(
                            quotes = quoteMap,
                            isLoadingQuotes = false,
                            quotesError = null,
                            lastQuotesRefreshMillis = System.currentTimeMillis()
                        )
                    }
                    val currentAlerts = (priceAlertsState.value as? CloudUiState.Success)?.data.orEmpty()
                    evaluatePriceAlerts(quoteMap, currentAlerts)
                },
                onFailure = { error ->
                    _uiState.update { state ->
                        state.copy(
                            isLoadingQuotes = false,
                            quotesError = error.localizedMessage
                                ?: "تعذر جلب أسعار الأسهم الحية حالياً."
                        )
                    }
                }
            )
        }
    }

    private fun evaluatePriceAlerts(
        quoteMap: Map<String, StockQuote>,
        alerts: List<PriceAlert>
    ) {
        if (alerts.isEmpty() || quoteMap.isEmpty()) return
        for (alert in alerts) {
            if (alert.id.isBlank() || locallyDispatchedAlertIds.contains(alert.id)) continue
            val quote = quoteMap[alert.symbol.uppercase()] ?: continue
            if (alert.shouldTrigger(quote.currentPrice)) {
                locallyDispatchedAlertIds.add(alert.id)
                viewModelScope.launch {
                    watchlistRepository.markPriceAlertTriggered(alert.id, quote.currentPrice)
                    val formattedTarget = String.format(Locale.US, "$%,.2f", alert.targetPrice)
                    val formattedCurrent = String.format(Locale.US, "$%,.2f", quote.currentPrice)
                    val event = TriggeredAlertNotificationEvent(
                        eventId = "${alert.id}_${System.currentTimeMillis()}",
                        alert = alert,
                        currentPrice = quote.currentPrice
                    )
                    _uiState.update { state ->
                        state.copy(
                            pendingAlertNotifications = state.pendingAlertNotifications + event,
                            snackbarMessage = "تنبيه سعري: وصل سهم ${alert.symbol} إلى $formattedCurrent (الحد المستهدف: ${alert.conditionEnum.shortArabicSymbol} $formattedTarget)"
                        )
                    }
                }
            }
        }
    }

    fun consumeAlertNotificationEvent(eventId: String) {
        _uiState.update { state ->
            state.copy(
                pendingAlertNotifications = state.pendingAlertNotifications.filterNot { it.eventId == eventId }
            )
        }
    }

    fun fetchQuoteForSingleSymbol(symbol: String) {
        val clean = symbol.trim().uppercase()
        if (clean.isBlank()) return
        viewModelScope.launch {
            marketDataRepository.fetchSingleQuote(clean).onSuccess { quote ->
                val updatedMap = _uiState.value.quotes + (quote.symbol to quote)
                _uiState.update { state ->
                    state.copy(
                        quotes = updatedMap,
                        lastQuotesRefreshMillis = System.currentTimeMillis()
                    )
                }
                val currentAlerts = (priceAlertsState.value as? CloudUiState.Success)?.data.orEmpty()
                evaluatePriceAlerts(updatedMap, currentAlerts)
            }
        }
    }

    fun createPriceAlert(
        symbol: String,
        companyName: String,
        arabicName: String?,
        targetPrice: Double,
        condition: AlertCondition,
        note: String?
    ) {
        val cleanSymbol = symbol.trim().uppercase()
        if (cleanSymbol.isBlank() || targetPrice <= 0.0) {
            showSnackbar("يرجى إدخال سعر مستهدف صحيح أكبر من صفر.")
            return
        }
        val curated = UsStockCatalog.findBySymbol(cleanSymbol)
        val resolvedCompany = companyName.ifBlank { curated?.companyName ?: cleanSymbol }
        val resolvedArabic = arabicName?.takeIf { it.isNotBlank() } ?: curated?.arabicName

        viewModelScope.launch {
            val alert = PriceAlert(
                symbol = cleanSymbol,
                companyName = resolvedCompany,
                arabicName = resolvedArabic,
                targetPrice = targetPrice,
                condition = condition.englishCode,
                note = note?.trim()?.takeIf { it.isNotEmpty() },
                isEnabled = true,
                isTriggered = false
            )
            val res = watchlistRepository.createPriceAlert(alert)
            res.fold(
                onSuccess = { createdId ->
                    val formattedTarget = String.format(Locale.US, "$%,.2f", targetPrice)
                    showSnackbar("تم تفعيل تنبيه السعر لسهم $cleanSymbol (${condition.shortArabicSymbol} $formattedTarget)")
                    val savedAlert = alert.copy(id = createdId)
                    evaluatePriceAlerts(_uiState.value.quotes, listOf(savedAlert))
                    fetchQuoteForSingleSymbol(cleanSymbol)
                },
                onFailure = { err ->
                    showSnackbar(err.localizedMessage ?: "تعذر حفظ تنبيه السعر في السحابة")
                }
            )
        }
    }

    fun updatePriceAlert(
        alert: PriceAlert,
        targetPrice: Double,
        condition: AlertCondition,
        note: String?
    ) {
        if (targetPrice <= 0.0) {
            showSnackbar("يرجى إدخال سعر مستهدف صحيح أكبر من صفر.")
            return
        }
        viewModelScope.launch {
            locallyDispatchedAlertIds.remove(alert.id)
            val res = watchlistRepository.updatePriceAlert(
                alertId = alert.id,
                targetPrice = targetPrice,
                conditionCode = condition.englishCode,
                note = note
            )
            res.fold(
                onSuccess = {
                    val formattedTarget = String.format(Locale.US, "$%,.2f", targetPrice)
                    showSnackbar("تم تحديث الحد السعري لسهم ${alert.symbol} (${condition.shortArabicSymbol} $formattedTarget)")
                    val updatedAlert = alert.copy(
                        targetPrice = targetPrice,
                        condition = condition.englishCode,
                        note = note,
                        isEnabled = true,
                        isTriggered = false,
                        triggeredPrice = null
                    )
                    evaluatePriceAlerts(_uiState.value.quotes, listOf(updatedAlert))
                    fetchQuoteForSingleSymbol(alert.symbol)
                },
                onFailure = { err ->
                    showSnackbar(err.localizedMessage ?: "تعذر تحديث التنبيه السعري")
                }
            )
        }
    }

    fun togglePriceAlertEnabled(alert: PriceAlert, isEnabled: Boolean) {
        viewModelScope.launch {
            if (isEnabled) {
                locallyDispatchedAlertIds.remove(alert.id)
            }
            val resetTriggered = isEnabled && alert.isTriggered
            val res = watchlistRepository.setPriceAlertEnabled(
                alertId = alert.id,
                isEnabled = isEnabled,
                resetTriggered = resetTriggered
            )
            if (res.isFailure) {
                showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر تحديث حالة التنبيه")
            } else if (isEnabled) {
                showSnackbar("تم تفعيل مراقبة التنبيه لسهم ${alert.symbol}")
            }
        }
    }

    fun deletePriceAlert(alertId: String) {
        viewModelScope.launch {
            locallyDispatchedAlertIds.remove(alertId)
            val res = watchlistRepository.deletePriceAlert(alertId)
            if (res.isSuccess) {
                showSnackbar("تم حذف تنبيه السعر")
            } else {
                showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر حذف التنبيه")
            }
        }
    }

    fun refreshCompanyNews(symbolFilter: String? = _uiState.value.selectedNewsSymbolFilter) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoadingNews = true,
                    newsError = null,
                    selectedNewsSymbolFilter = symbolFilter
                )
            }

            val symbols = if (!symbolFilter.isNullOrBlank()) {
                listOf(symbolFilter)
            } else {
                val watchlistSymbols = (watchlistState.value as? CloudUiState.Success)
                    ?.data?.map { it.symbol }.orEmpty()
                (watchlistSymbols + listOf("NVDA", "AAPL", "MSFT", "TSLA", "GOOGL", "AMZN"))
                    .distinct()
                    .take(6)
            }

            val existingAnalysesById = _uiState.value.newsItems
                .filter { it.aiAnalysis != null }
                .associate { it.id to it.aiAnalysis }

            val result = marketDataRepository.fetchCompanyNews(symbols)
            result.fold(
                onSuccess = { articles ->
                    val merged = articles.map { item ->
                        val prevAnalysis = existingAnalysesById[item.id]
                        if (prevAnalysis != null) item.copy(aiAnalysis = prevAnalysis) else item
                    }
                    _uiState.update {
                        it.copy(
                            newsItems = merged,
                            isLoadingNews = false,
                            newsError = null,
                            lastNewsRefreshMillis = System.currentTimeMillis()
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isLoadingNews = false,
                            newsError = error.localizedMessage
                                ?: "لا تتوفر أخبار حية حالياً من المصدر."
                        )
                    }
                }
            )
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            if (query.isBlank()) {
                _uiState.update {
                    it.copy(
                        searchResults = UsStockCatalog.majorUsStocks,
                        isSearching = false
                    )
                }
                return@launch
            }
            delay(300L)
            _uiState.update { it.copy(isSearching = true) }
            val result = marketDataRepository.searchUsStocks(query)
            result.onSuccess { matches ->
                _uiState.update { it.copy(searchResults = matches, isSearching = false) }
                val missingSymbols = matches.take(5).map { it.symbol }
                    .filter { !_uiState.value.quotes.containsKey(it) }
                if (missingSymbols.isNotEmpty()) {
                    marketDataRepository.fetchQuotesForSymbols(missingSymbols).onSuccess { newQuotes ->
                        _uiState.update { state ->
                            state.copy(quotes = state.quotes + newQuotes.associateBy { q -> q.symbol })
                        }
                    }
                }
            }.onFailure {
                _uiState.update { it.copy(isSearching = false) }
            }
        }
    }

    fun selectStockForDetails(symbol: String?) {
        _uiState.update { it.copy(selectedStockSymbol = symbol) }
        if (!symbol.isNullOrBlank()) {
            fetchQuoteForSingleSymbol(symbol)
        }
    }

    fun setSentimentFilter(filter: SentimentFilter) {
        _uiState.update { it.copy(selectedSentimentFilter = filter) }
    }

    fun analyzeSingleNews(newsId: String) {
        val targetItem = _uiState.value.newsItems.find { it.id == newsId } ?: return
        if (targetItem.isAnalyzing) return

        viewModelScope.launch {
            _uiState.update { state ->
                state.copy(
                    newsItems = state.newsItems.map {
                        if (it.id == newsId) it.copy(isAnalyzing = true, analysisError = null) else it
                    }
                )
            }

            val result = newsAiAnalyzer.analyzeNewsItem(targetItem)
            result.fold(
                onSuccess = { analysis ->
                    _uiState.update { state ->
                        state.copy(
                            newsItems = state.newsItems.map {
                                if (it.id == newsId) {
                                    it.copy(
                                        aiAnalysis = analysis,
                                        isAnalyzing = false,
                                        analysisError = null
                                    )
                                } else {
                                    it
                                }
                            }
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update { state ->
                        state.copy(
                            newsItems = state.newsItems.map {
                                if (it.id == newsId) {
                                    it.copy(
                                        isAnalyzing = false,
                                        analysisError = error.localizedMessage
                                            ?: "فشل تحليل الخبر بالذكاء الاصطناعي"
                                    )
                                } else {
                                    it
                                }
                            }
                        )
                    }
                }
            )
        }
    }

    fun analyzeTopUnanalyzedNews() {
        if (_uiState.value.isBatchAnalyzing) return
        val unanalyzed = _uiState.value.newsItems
            .filter { it.aiAnalysis == null && !it.isAnalyzing }
            .take(4)

        if (unanalyzed.isEmpty()) {
            showSnackbar("جميع الأخبار المعروضة تم تحليلها بالفعل.")
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isBatchAnalyzing = true) }
            try {
                for (item in unanalyzed) {
                    _uiState.update { state ->
                        state.copy(
                            newsItems = state.newsItems.map {
                                if (it.id == item.id) it.copy(isAnalyzing = true, analysisError = null) else it
                            }
                        )
                    }
                    val res = newsAiAnalyzer.analyzeNewsItem(item)
                    res.fold(
                        onSuccess = { analysis ->
                            _uiState.update { state ->
                                state.copy(
                                    newsItems = state.newsItems.map {
                                        if (it.id == item.id) {
                                            it.copy(aiAnalysis = analysis, isAnalyzing = false, analysisError = null)
                                        } else {
                                            it
                                        }
                                    }
                                )
                            }
                        },
                        onFailure = { err ->
                            _uiState.update { state ->
                                state.copy(
                                    newsItems = state.newsItems.map {
                                        if (it.id == item.id) {
                                            it.copy(
                                                isAnalyzing = false,
                                                analysisError = err.localizedMessage ?: "تعذر التحليل"
                                            )
                                        } else {
                                            it
                                        }
                                    }
                                )
                            }
                        }
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                _uiState.update { it.copy(isBatchAnalyzing = false) }
            }
        }
    }

    fun toggleWatchlistStock(
        symbol: String,
        companyName: String,
        arabicName: String? = null,
        sector: String? = null
    ) {
        val cleanSymbol = symbol.trim().uppercase()
        val currentList = (watchlistState.value as? CloudUiState.Success)?.data.orEmpty()
        val exists = currentList.any { it.symbol.equals(cleanSymbol, ignoreCase = true) }

        viewModelScope.launch {
            if (exists) {
                val res = watchlistRepository.removeWatchlistStock(cleanSymbol)
                if (res.isSuccess) {
                    showSnackbar("تمت إزالة $cleanSymbol من قائمة المفضلة")
                } else {
                    showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر الحذف من المفضلة")
                }
            } else {
                val curated = UsStockCatalog.findBySymbol(cleanSymbol)
                val stock = WatchlistStock(
                    symbol = cleanSymbol,
                    companyName = companyName.ifBlank { curated?.companyName ?: cleanSymbol },
                    arabicName = arabicName ?: curated?.arabicName,
                    sector = sector ?: curated?.sector
                )
                val res = watchlistRepository.addOrUpdateWatchlistStock(stock)
                if (res.isSuccess) {
                    showSnackbar("تمت إضافة $cleanSymbol إلى قائمة المفضلة")
                    fetchQuoteForSingleSymbol(cleanSymbol)
                } else {
                    showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر الإضافة إلى المفضلة")
                }
            }
        }
    }

    fun updateWatchlistNotesAndTarget(
        symbol: String,
        notes: String?,
        targetPrice: Double?
    ) {
        viewModelScope.launch {
            val res = watchlistRepository.updateWatchlistNotesAndTarget(symbol, notes, targetPrice)
            if (res.isSuccess) {
                showSnackbar("تم حفظ الملاحظات والسعر المستهدف لسهم $symbol")
            } else {
                showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر تحديث بيانات السهم")
            }
        }
    }

    fun saveNewsAnalysisToCloud(newsItem: CompanyNewsItem) {
        val analysis = newsItem.aiAnalysis ?: return
        viewModelScope.launch {
            val savedModel = SavedNewsAnalysis(
                symbol = newsItem.symbol,
                headline = newsItem.headline,
                source = newsItem.source,
                publishedAtMillis = newsItem.publishedAtMillis,
                articleUrl = newsItem.url,
                sentiment = analysis.sentiment.englishCode,
                confidenceScore = analysis.confidenceScore.toLong(),
                arabicSummary = analysis.arabicSummary,
                marketImpact = analysis.marketImpact
            )
            val res = watchlistRepository.saveNewsAnalysis(savedModel)
            if (res.isSuccess) {
                showSnackbar("تم حفظ تحليل الخبر في حسابك السحابي")
            } else {
                showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر حفظ التحليل")
            }
        }
    }

    fun deleteSavedAnalysis(analysisId: String) {
        viewModelScope.launch {
            val res = watchlistRepository.deleteSavedAnalysis(analysisId)
            if (res.isSuccess) {
                showSnackbar("تم حذف التحليل المحفوظ")
            } else {
                showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر حذف التحليل")
            }
        }
    }

    fun savePortfolioPosition(
        symbol: String,
        companyName: String,
        arabicName: String?,
        sector: String?,
        sharesCount: Double,
        buyPrice: Double,
        notes: String?
    ) {
        val cleanSymbol = symbol.trim().uppercase()
        if (cleanSymbol.isBlank()) {
            showSnackbar("يرجى اختيار رمز سهم أمريكي صحيح")
            return
        }
        if (sharesCount <= 0.0 || buyPrice <= 0.0) {
            showSnackbar("يرجى إدخال عدد أسهم وسعر شراء أكبر من صفر")
            return
        }
        val curated = UsStockCatalog.findBySymbol(cleanSymbol)
        val quote = _uiState.value.quotes[cleanSymbol]
        val resolvedCompany = companyName.ifBlank {
            quote?.companyName ?: curated?.companyName ?: cleanSymbol
        }
        val resolvedArabic = arabicName?.takeIf { it.isNotBlank() }
            ?: quote?.arabicName
            ?: curated?.arabicName
        val resolvedSector = sector?.takeIf { it.isNotBlank() }
            ?: quote?.sector
            ?: curated?.sector

        viewModelScope.launch {
            val holding = PortfolioHolding(
                symbol = cleanSymbol,
                companyName = resolvedCompany,
                arabicName = resolvedArabic,
                sector = resolvedSector,
                sharesCount = sharesCount,
                buyPrice = buyPrice,
                notes = notes?.trim()?.takeIf { it.isNotEmpty() }
            )
            val res = watchlistRepository.savePortfolioHolding(holding)
            res.fold(
                onSuccess = {
                    val formattedCost = String.format(Locale.US, "$%,.2f", sharesCount * buyPrice)
                    showSnackbar("تم حفظ صفقة $cleanSymbol في المحفظة الافتراضية (التكلفة: $formattedCost)")
                    fetchQuoteForSingleSymbol(cleanSymbol)
                },
                onFailure = { err ->
                    showSnackbar(err.localizedMessage ?: "تعذر حفظ الصفقة في المحفظة الافتراضية")
                }
            )
        }
    }

    fun deletePortfolioPosition(symbol: String) {
        val cleanSymbol = symbol.trim().uppercase()
        viewModelScope.launch {
            val res = watchlistRepository.removePortfolioHolding(cleanSymbol)
            if (res.isSuccess) {
                showSnackbar("تمت إزالة صفقة $cleanSymbol من المحفظة الافتراضية")
            } else {
                showSnackbar(res.exceptionOrNull()?.localizedMessage ?: "تعذر حذف الصفقة من المحفظة")
            }
        }
    }

    fun selectStockForPrediction(symbol: String) {
        val clean = symbol.trim().uppercase()
        if (clean.isBlank()) return
        runStockPrediction(
            symbol = clean,
            horizon = _uiState.value.predictionHorizon,
            forceRefresh = false
        )
    }

    fun changePredictionHorizon(horizon: PredictionHorizon) {
        runStockPrediction(
            symbol = _uiState.value.predictionSymbol,
            horizon = horizon,
            forceRefresh = false
        )
    }

    fun runStockPrediction(
        symbol: String = _uiState.value.predictionSymbol,
        horizon: PredictionHorizon = _uiState.value.predictionHorizon,
        forceRefresh: Boolean = false
    ) {
        val cleanSymbol = symbol.trim().uppercase()
        if (cleanSymbol.isBlank()) return

        predictionJob?.cancel()
        predictionJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    predictionSymbol = cleanSymbol,
                    predictionHorizon = horizon,
                    predictionState = StockPredictionUiState.Loading(cleanSymbol, horizon)
                )
            }

            try {
                // 1. Ensure we have a live quote for this symbol
                val currentQuote = _uiState.value.quotes[cleanSymbol]
                    ?: marketDataRepository.fetchSingleQuote(cleanSymbol).getOrNull()?.also { fetched ->
                        _uiState.update { state ->
                            state.copy(
                                quotes = state.quotes + (fetched.symbol to fetched),
                                lastQuotesRefreshMillis = System.currentTimeMillis()
                            )
                        }
                    }

                // 2. Fetch or reuse real 1-year historical daily OHLCV candles
                val candlesResult = if (!forceRefresh && historicalCandlesCache.containsKey(cleanSymbol)) {
                    Result.success(historicalCandlesCache.getValue(cleanSymbol))
                } else {
                    marketDataRepository.fetchHistoricalDailyCandles(cleanSymbol, range = "1y")
                        .onSuccess { list ->
                            historicalCandlesCache[cleanSymbol] = list
                        }
                }

                if (candlesResult.isFailure) {
                    val err = candlesResult.exceptionOrNull()
                    _uiState.update {
                        it.copy(
                            predictionState = StockPredictionUiState.Error(
                                symbol = cleanSymbol,
                                messageArabic = err?.localizedMessage
                                    ?: "تعذر جلب البيانات التاريخية للسهم $cleanSymbol من المصدر الموثوق."
                            )
                        )
                    }
                    return@launch
                }

                val candles = candlesResult.getOrThrow()

                // 3. Gather real company news (fetch if not already present in uiState.newsItems)
                val existingNews = _uiState.value.newsItems.filter {
                    it.symbol.equals(cleanSymbol, ignoreCase = true)
                }
                val companyNews = if (existingNews.isNotEmpty() && !forceRefresh) {
                    existingNews
                } else {
                    marketDataRepository.fetchCompanyNews(listOf(cleanSymbol)).getOrNull().orEmpty()
                }

                // 4. Run Quantitative + Out-of-Sample Backtest + Gemini AI Prediction Engine
                val predictionResult = stockPredictionEngine.generatePrediction(
                    symbol = cleanSymbol,
                    quote = currentQuote,
                    candles = candles,
                    companyNews = companyNews,
                    horizon = horizon
                )

                predictionResult.fold(
                    onSuccess = { report ->
                        _uiState.update {
                            it.copy(
                                predictionState = StockPredictionUiState.Success(report)
                            )
                        }
                    },
                    onFailure = { error ->
                        when (error) {
                            is InsufficientHistoricalDataException -> {
                                _uiState.update {
                                    it.copy(
                                        predictionState = StockPredictionUiState.InsufficientData(
                                            symbol = cleanSymbol,
                                            reasonArabic = error.message,
                                            availableCandles = error.availableCandles,
                                            requiredCandles = error.requiredCandles
                                        )
                                    )
                                }
                            }
                            else -> {
                                _uiState.update {
                                    it.copy(
                                        predictionState = StockPredictionUiState.Error(
                                            symbol = cleanSymbol,
                                            messageArabic = error.localizedMessage
                                                ?: "حدث خطأ أثناء حساب توقعات السهم $cleanSymbol."
                                        )
                                    )
                                }
                            }
                        }
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error in runStockPrediction for $cleanSymbol", e)
                _uiState.update {
                    it.copy(
                        predictionState = StockPredictionUiState.Error(
                            symbol = cleanSymbol,
                            messageArabic = e.localizedMessage
                                ?: "تعذر إكمال التحليل التنبؤي للسهم $cleanSymbol."
                        )
                    )
                }
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }
}
