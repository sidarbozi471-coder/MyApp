package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IndicatorSignalDirection
import com.example.data.model.NewsPredictionSection
import com.example.data.model.OutOfSampleBacktestReport
import com.example.data.model.PredictionHorizon
import com.example.data.model.StockPredictionReport
import com.example.data.model.StockPredictionUiState
import com.example.data.model.TechnicalIndicatorFactor
import com.example.data.model.TechnicalPredictionSection
import com.example.data.model.UsStockCatalog
import com.example.ui.components.SentimentBadge
import com.example.ui.components.formatExactDateTime
import com.example.ui.components.formatUsdPrice
import com.example.ui.theme.BearishCrimson
import com.example.ui.theme.BearishCrimsonLight
import com.example.ui.theme.BearishCrimsonSurface
import com.example.ui.theme.BullishEmerald
import com.example.ui.theme.BullishEmeraldLight
import com.example.ui.theme.BullishEmeraldSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.NeutralAmberLight
import com.example.ui.theme.NeutralAmberSurface
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun StockPredictionTabContent(
    selectedSymbol: String,
    selectedHorizon: PredictionHorizon,
    predictionState: StockPredictionUiState,
    favoriteSymbols: Set<String>,
    onSelectSymbol: (String) -> Unit,
    onSelectHorizon: (PredictionHorizon) -> Unit,
    onRefreshPrediction: () -> Unit,
    onOpenStockDetails: (String) -> Unit,
    onOpenNewsUrl: (String) -> Unit
) {
    var customTickerInput by rememberSaveable { mutableStateOf("") }

    val quickSymbols = remember(favoriteSymbols) {
        val base = favoriteSymbols.toList() + UsStockCatalog.majorUsStocks.map { it.symbol }
        base.map { it.uppercase() }.distinct()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 760.dp)
            .testTag("ai_prediction_tab_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header & Stock / Horizon Selector Card
        item(key = "prediction_header_controls") {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(BullishEmeraldSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "توقعات الأسهم بالذكاء الاصطناعي (AI Prediction)",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "تحليل كمي للمؤشرات الفنية (RSI, MACD, MA) والسيولة مع تحليل الأخبار الحقيقية",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }

                        IconButton(
                            onClick = onRefreshPrediction,
                            modifier = Modifier.testTag("refresh_prediction_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث التوقع",
                                tint = ElectricCyan
                            )
                        }
                    }

                    // Stock Selector Chips
                    Text(
                        text = "اختر السهم للتحليل التنبؤي:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(quickSymbols) { sym ->
                            val curated = UsStockCatalog.findBySymbol(sym)
                            val isSelected = selectedSymbol.equals(sym, ignoreCase = true)
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectSymbol(sym) },
                                label = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = sym,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (curated != null) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "• ${curated.arabicName}",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BullishEmerald,
                                    selectedLabelColor = Color(0xFF032219)
                                ),
                                modifier = Modifier.testTag("prediction_stock_chip_$sym")
                            )
                        }
                    }

                    // Custom Ticker Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = customTickerInput,
                            onValueChange = { customTickerInput = it.uppercase() },
                            placeholder = {
                                Text(
                                    text = "أو أدخل رمز أي سهم أمريكي (مثل: PLTR, AMD, COIN)...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = ObsidianSurface,
                                unfocusedContainerColor = ObsidianSurface,
                                focusedBorderColor = ElectricCyan,
                                unfocusedBorderColor = ObsidianBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("prediction_custom_symbol_input")
                        )

                        Button(
                            onClick = {
                                val cleaned = customTickerInput.trim().uppercase()
                                if (cleaned.isNotBlank()) {
                                    onSelectSymbol(cleaned)
                                    customTickerInput = ""
                                }
                            },
                            enabled = customTickerInput.trim().isNotBlank(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricCyan,
                                contentColor = Color(0xFF032329)
                            ),
                            modifier = Modifier.testTag("prediction_analyze_custom_symbol_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تحليل", fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))

                    // Time Horizon Selector (24h, 7d, 30d)
                    Text(
                        text = "المدة الزمنية للتوقع:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PredictionHorizon.entries.forEach { horizon ->
                            val isSelected = selectedHorizon == horizon
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectHorizon(horizon) },
                                label = {
                                    Text(
                                        text = horizon.arabicLabel,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldAccent,
                                    selectedLabelColor = Color(0xFF231702)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("prediction_horizon_${horizon.name}")
                            )
                        }
                    }
                }
            }
        }

        // 2. Prediction Content based on State
        when (predictionState) {
            is StockPredictionUiState.Idle,
            is StockPredictionUiState.Loading -> {
                item(key = "prediction_loading") {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                        border = BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("prediction_loading_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = BullishEmeraldLight)
                            Text(
                                text = "جارٍ تحليل البيانات التاريخية وحجم التداول والمؤشرات الفنية (RSI, MACD, MA) وأخبار الشركة لسهم $selectedSymbol...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "يتم أيضاً اختبار دقة النموذج على فترات تاريخية خارج العينة (${selectedHorizon.arabicLabel})",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            is StockPredictionUiState.InsufficientData -> {
                item(key = "prediction_insufficient_data") {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = NeutralAmberSurface),
                        border = BorderStroke(1.dp, NeutralAmber),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("prediction_insufficient_data_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = null,
                                    tint = NeutralAmberLight,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "البيانات التاريخية غير كافية لإصدار توقع موثوق",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NeutralAmberLight,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = predictionState.reasonArabic,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "البيانات المتوفرة: ${predictionState.availableCandles} جلسة تداول • الحد الأدنى المطلوب: ${predictionState.requiredCandles} جلسة تداول (لضمان عدم اختلاق أو تقدير أي مؤشرات عشوائية).",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Button(
                                onClick = onRefreshPrediction,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeutralAmberLight,
                                    contentColor = Color(0xFF231702)
                                )
                            ) {
                                Text("إعادة المحاولة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            is StockPredictionUiState.Error -> {
                item(key = "prediction_error") {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = BearishCrimsonSurface),
                        border = BorderStroke(1.dp, BearishCrimson),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("prediction_error_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "تعذر إتمام التحليل التنبؤي لسهم ${predictionState.symbol}",
                                style = MaterialTheme.typography.titleMedium,
                                color = BearishCrimsonLight,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = predictionState.messageArabic,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                            Button(
                                onClick = onRefreshPrediction,
                                colors = ButtonDefaults.buttonColors(containerColor = BearishCrimson)
                            ) {
                                Text("إعادة المحاولة")
                            }
                        }
                    }
                }
            }

            is StockPredictionUiState.Success -> {
                val report = predictionState.report

                // A. Main Bullish vs Bearish Probability Card (Sum = 100%)
                item(key = "prediction_main_prob_card") {
                    PredictionHeroProbabilityCard(
                        report = report,
                        onOpenStockDetails = { onOpenStockDetails(report.symbol) }
                    )
                }

                // B. Key Reasons for Prediction + Influential Indicators Summary
                item(key = "prediction_reasons_card") {
                    PredictionReasonsAndInfluentialIndicatorsCard(report = report)
                }

                // C. Explicitly Separated Section 1: Quantitative Technical Analysis (RSI, MACD, Moving Averages, Volume)
                item(key = "prediction_technical_section") {
                    SeparatedTechnicalAnalysisCard(
                        tech = report.technicalSection,
                        currentPrice = report.currentPrice,
                        candlesCount = report.historicalCandlesCount,
                        horizon = report.horizon
                    )
                }

                // D. Explicitly Separated Section 2: Economic & Company News Analysis
                item(key = "prediction_news_section") {
                    SeparatedNewsAnalysisCard(
                        symbol = report.symbol,
                        newsSection = report.newsSection,
                        onOpenNewsUrl = onOpenNewsUrl
                    )
                }

                // E. Out-of-Sample Historical Backtest Validation Card
                item(key = "prediction_backtest_section") {
                    OutOfSampleBacktestValidationCard(
                        symbol = report.symbol,
                        horizon = report.horizon,
                        backtest = report.backtestReport
                    )
                }

                // F. Non-Certainty & Real Data Disclaimer Card
                item(key = "prediction_disclaimer") {
                    PredictionDisclaimerCard(
                        dataSource = report.dataSource,
                        generatedAtMillis = report.generatedAtMillis
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PredictionHeroProbabilityCard(
    report: StockPredictionReport,
    onOpenStockDetails: () -> Unit
) {
    val isBullishDominant = report.bullishProbabilityPercent >= report.bearishProbabilityPercent
    val dominantAccent = if (isBullishDominant) BullishEmerald else BearishCrimson

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.5.dp, dominantAccent.copy(alpha = 0.65f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("prediction_probability_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Stock Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onOpenStockDetails() }
                ) {
                    Surface(
                        color = ObsidianCardElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Text(
                            text = report.symbol,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = ElectricCyan,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${report.arabicName} (${report.companyName})",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "المدة الزمنية: ${report.horizon.arabicLabel} • ${report.horizon.arabicSubtitle}",
                            style = MaterialTheme.typography.bodySmall,
                            color = GoldAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatUsdPrice(report.currentPrice),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        color = TextPrimary
                    )
                    val chgSign = if (report.priceChangePercent >= 0) "+" else ""
                    Text(
                        text = String.format(Locale.US, "%s%.2f%%", chgSign, report.priceChangePercent),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (report.priceChangePercent >= 0) BullishEmeraldLight else BearishCrimsonLight
                    )
                }
            }

            // Main Bullish vs Bearish Probabilities (Exact match to prompt format: 📈 احتمالية الصعود: X% 📉 احتمالية الهبوط: Y%)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Bullish Box
                Surface(
                    color = BullishEmeraldSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = if (isBullishDominant) 1.5.dp else 1.dp,
                        color = BullishEmerald.copy(alpha = if (isBullishDominant) 0.85f else 0.4f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("bullish_probability_box")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                                contentDescription = null,
                                tint = BullishEmeraldLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "📈 احتمالية الصعود",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${report.bullishProbabilityPercent}%",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 28.sp,
                            color = BullishEmeraldLight,
                            modifier = Modifier.testTag("bullish_probability_text")
                        )
                    }
                }

                // Bearish Box
                Surface(
                    color = BearishCrimsonSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = if (!isBullishDominant) 1.5.dp else 1.dp,
                        color = BearishCrimson.copy(alpha = if (!isBullishDominant) 0.85f else 0.4f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("bearish_probability_box")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.TrendingDown,
                                contentDescription = null,
                                tint = BearishCrimsonLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "📉 احتمالية الهبوط",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${report.bearishProbabilityPercent}%",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 28.sp,
                            color = BearishCrimsonLight,
                            modifier = Modifier.testTag("bearish_probability_text")
                        )
                    }
                }
            }

            // Split Probability Visual Bar (100% total)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                ) {
                    val bullWeight = report.bullishProbabilityPercent.coerceIn(1, 99).toFloat()
                    val bearWeight = report.bearishProbabilityPercent.coerceIn(1, 99).toFloat()
                    Box(
                        modifier = Modifier
                            .weight(bullWeight)
                            .fillMaxHeight()
                            .background(BullishEmerald)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Box(
                        modifier = Modifier
                            .weight(bearWeight)
                            .fillMaxHeight()
                            .background(BearishCrimson)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "مجموع الاحتمالات الكلي: ${report.bullishProbabilityPercent + report.bearishProbabilityPercent}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                    Text(
                        text = "النطاق السعري المتوقع (${report.horizon.arabicLabel}): ${formatUsdPrice(report.expectedPriceRangeLow)} – ${formatUsdPrice(report.expectedPriceRangeHigh)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))

            // Confidence Level & Last Updated Timestamp
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = ObsidianCardElevated,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("prediction_confidence_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "مستوى الثقة في التوقع: ${report.confidenceLabelArabic}",
                            style = MaterialTheme.typography.labelMedium,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "تاريخ ووقت آخر تحديث: ${formatExactDateTime(report.generatedAtMillis)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        modifier = Modifier.testTag("prediction_last_updated_text")
                    )
                    Text(
                        text = "المصدر: ${report.dataSource} (${report.historicalCandlesCount} جلسة تاريخية)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun PredictionReasonsAndInfluentialIndicatorsCard(
    report: StockPredictionReport
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("prediction_reasons_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "أسباب التوقع وأهم المؤشرات المؤثرة",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            // Executive Summary Box
            Surface(
                color = ObsidianCardElevated,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Text(
                    text = report.aiExecutiveVerdictArabic,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    modifier = Modifier.padding(12.dp)
                )
            }

            // Key Reasons Bullet Points
            Text(
                text = "أسباب التوقع الرئيسية:",
                style = MaterialTheme.typography.labelLarge,
                color = ElectricCyan,
                fontWeight = FontWeight.Bold
            )

            report.aiSynthesizedReasons.forEach { reason ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 7.dp)
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(GoldAccent)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = reason,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }
            }

            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))

            // Most Influential Indicators List
            Text(
                text = "أهم المؤشرات المؤثرة ووزنها في النموذج (${report.horizon.arabicLabel}):",
                style = MaterialTheme.typography.labelLarge,
                color = GoldAccent,
                fontWeight = FontWeight.Bold
            )

            report.technicalSection.influentialIndicators.forEach { factor ->
                InfluentialIndicatorRow(factor = factor)
            }
        }
    }
}

@Composable
private fun InfluentialIndicatorRow(factor: TechnicalIndicatorFactor) {
    val (sigColor, sigBg, sigIcon) = when (factor.signal) {
        IndicatorSignalDirection.BULLISH -> Triple(
            BullishEmeraldLight,
            BullishEmeraldSurface,
            Icons.AutoMirrored.Filled.TrendingUp
        )
        IndicatorSignalDirection.BEARISH -> Triple(
            BearishCrimsonLight,
            BearishCrimsonSurface,
            Icons.AutoMirrored.Filled.TrendingDown
        )
        IndicatorSignalDirection.NEUTRAL -> Triple(
            NeutralAmberLight,
            NeutralAmberSurface,
            Icons.AutoMirrored.Filled.TrendingFlat
        )
    }

    Surface(
        color = ObsidianSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ObsidianBorder.copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = factor.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "القراءة الحالية: ${factor.formattedValue} • الوزن الترجيحي: ${factor.impactWeightPercent}%",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Surface(
                    color = sigBg,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, sigColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = sigIcon,
                            contentDescription = null,
                            tint = sigColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = factor.signal.arabicLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = sigColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            LinearProgressIndicator(
                progress = { (factor.impactWeightPercent / 100f).coerceIn(0.05f, 1f) },
                color = sigColor,
                trackColor = ObsidianCardElevated,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
            )

            Text(
                text = factor.arabicInterpretation,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun SeparatedTechnicalAnalysisCard(
    tech: TechnicalPredictionSection,
    currentPrice: Double,
    candlesCount: Int,
    horizon: PredictionHorizon
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("technical_analysis_section_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ShowChart,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "أولاً: التحليل الفني الكمي وحركة السيولة",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "منفصل عن الأخبار • محسوب من $candlesCount جلسة تداول تاريخية حقيقية",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    color = ObsidianCardElevated,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = String.format(Locale.US, "قوة فنية: %.0f%%", tech.technicalBullishScore),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = ElectricCyan,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Text(
                text = tech.technicalSummaryArabic,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )

            // Technical Indicators Numerical Grid (RSI, MACD, Moving Averages, Volume)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TechnicalMetricMiniCard(
                    title = "مؤشر RSI (14)",
                    value = String.format(Locale.US, "%.2f", tech.rsi14),
                    subLabel = when {
                        tech.rsi14 > 70 -> "تشبع شرائي"
                        tech.rsi14 < 30 -> "تشبع بيعي"
                        else -> "نطاق متوازن"
                    },
                    accentColor = when {
                        tech.rsi14 in 50.0..68.0 || tech.rsi14 < 30.0 -> BullishEmeraldLight
                        tech.rsi14 > 72.0 -> BearishCrimsonLight
                        else -> NeutralAmberLight
                    },
                    modifier = Modifier.weight(1f)
                )

                TechnicalMetricMiniCard(
                    title = "MACD (12,26,9)",
                    value = String.format(Locale.US, "%+.2f", tech.macdHistogram),
                    subLabel = String.format(Locale.US, "M: %.2f | S: %.2f", tech.macdLine, tech.macdSignal),
                    accentColor = if (tech.macdHistogram >= 0) BullishEmeraldLight else BearishCrimsonLight,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TechnicalMetricMiniCard(
                    title = "SMA 20 / SMA 50",
                    value = "${formatUsdPrice(tech.sma20)} / ${formatUsdPrice(tech.sma50)}",
                    subLabel = "EMA 20: ${formatUsdPrice(tech.ema20)}",
                    accentColor = if (currentPrice >= tech.sma20) BullishEmeraldLight else BearishCrimsonLight,
                    modifier = Modifier.weight(1f)
                )

                TechnicalMetricMiniCard(
                    title = "حجم التداول والزخم",
                    value = String.format(Locale.US, "%.2fx المتوسط", tech.volumeRatio),
                    subLabel = String.format(
                        Locale.US,
                        "5أيام: %+.1f%% | 20يوم: %+.1f%%",
                        tech.return5dPercent,
                        tech.return20dPercent
                    ),
                    accentColor = if (tech.return5dPercent >= 0) BullishEmeraldLight else BearishCrimsonLight,
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))

            Text(
                text = "تفاصيل القراءة الفنية (${horizon.arabicLabel}):",
                style = MaterialTheme.typography.labelLarge,
                color = ElectricCyan,
                fontWeight = FontWeight.Bold
            )

            tech.technicalReasons.forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 7.dp)
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun TechnicalMetricMiniCard(
    title: String,
    value: String,
    subLabel: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ObsidianSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Text(
                text = value,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subLabel,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SeparatedNewsAnalysisCard(
    symbol: String,
    newsSection: NewsPredictionSection,
    onOpenNewsUrl: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("news_analysis_section_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Newspaper,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "ثانياً: تحليل الأخبار الاقتصادية وأخبار الشركة",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "منفصل عن التحليل الفني • يعتمد حصرياً على الأخبار الموثقة لسهم $symbol",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                SentimentBadge(sentiment = newsSection.overallNewsSentiment)
            }

            Text(
                text = newsSection.companyAndEconomicNewsSummaryArabic,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )

            // News Sentiment Counts Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TechnicalMetricMiniCard(
                    title = "إيجابية",
                    value = "${newsSection.positiveArticlesCount}",
                    subLabel = "أخبار داعمة",
                    accentColor = BullishEmeraldLight,
                    modifier = Modifier.weight(1f)
                )
                TechnicalMetricMiniCard(
                    title = "سلبية",
                    value = "${newsSection.negativeArticlesCount}",
                    subLabel = "أخبار ضاغطة",
                    accentColor = BearishCrimsonLight,
                    modifier = Modifier.weight(1f)
                )
                TechnicalMetricMiniCard(
                    title = "محايدة",
                    value = "${newsSection.neutralArticlesCount}",
                    subLabel = "تأثير متوازن",
                    accentColor = NeutralAmberLight,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "أبرز المحركات الإخبارية والأساسية:",
                style = MaterialTheme.typography.labelLarge,
                color = GoldAccent,
                fontWeight = FontWeight.Bold
            )

            newsSection.newsReasons.forEach { reason ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 7.dp)
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(GoldAccent)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = reason,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                }
            }

            if (newsSection.topReferencedHeadlines.isNotEmpty()) {
                HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))
                Text(
                    text = "المصادر الإخبارية المرجعية الموثقة (اضغط لفتح المصدر):",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )

                newsSection.topReferencedHeadlines.forEach { article ->
                    Surface(
                        color = ObsidianSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, ObsidianBorder.copy(alpha = 0.7f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenNewsUrl(article.url) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = article.headline,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${article.source} • ${formatExactDateTime(article.publishedAtMillis)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = "فتح المصدر",
                                tint = ElectricCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OutOfSampleBacktestValidationCard(
    symbol: String,
    horizon: PredictionHorizon,
    backtest: OutOfSampleBacktestReport
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, BullishEmerald.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("out_of_sample_backtest_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.HistoryEdu,
                    contentDescription = null,
                    tint = BullishEmeraldLight,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "اختبار دقة النموذج على بيانات تاريخية خارج العينة (Backtest)",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "التحقق من دقة المؤشرات الفنية على بيانات تاريخية لم تدخل في تدريب أو معايرة الأوزان",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TechnicalMetricMiniCard(
                    title = "دقة الاتجاه خارج العينة",
                    value = String.format(Locale.US, "%.1f%%", backtest.directionalAccuracyPercent),
                    subLabel = "${backtest.correctPredictionsCount} من ${backtest.outOfSampleTestCount} اختبار",
                    accentColor = if (backtest.directionalAccuracyPercent >= 52.0) BullishEmeraldLight else NeutralAmberLight,
                    modifier = Modifier.weight(1f)
                )
                TechnicalMetricMiniCard(
                    title = "جلسات الاختبار المستقلة",
                    value = "${backtest.outOfSampleTestCount} نافذة",
                    subLabel = "تدريب سابق: ${backtest.trainingCandlesCount} جلسة",
                    accentColor = ElectricCyan,
                    modifier = Modifier.weight(1f)
                )
                TechnicalMetricMiniCard(
                    title = "متوسط الحركة الفعلية",
                    value = String.format(Locale.US, "±%.2f%%", backtest.avgRealizedMovePercent),
                    subLabel = "خلال ${horizon.arabicLabel}",
                    accentColor = GoldAccent,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = backtest.methodologyNoteArabic,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun PredictionDisclaimerCard(
    dataSource: String,
    generatedAtMillis: Long
) {
    Surface(
        color = ObsidianSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, ObsidianBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("prediction_disclaimer_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = NeutralAmberLight,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "تنبيه مهم حول التوقعات الاحتمالية",
                    style = MaterialTheme.typography.labelLarge,
                    color = NeutralAmberLight,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "هذه التوقعات مبنية على نماذج كمية للمؤشرات الفنية (RSI, MACD, Moving Averages) وتحليل الأخبار الحقيقية من ($dataSource)، وهي تقديرات احتمالية وليست حقيقة مؤكدة أو نصيحة استثمارية مباشرة. أسواق الأسهم تنطوي على مخاطر وتقلبات غير متوقعة.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Text(
                    text = "آخر تحديث للتحليل: ${formatExactDateTime(generatedAtMillis)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
    }
}
